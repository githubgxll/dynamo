# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Pipeline registry and factory for vllm-omni.

``OMNI_PIPELINES`` maps each ``model_type`` to either a ``PipelineConfig``
instance or a resolver callable that accepts an optional HF config and returns
a ``PipelineConfig``.

To add a new pipeline:
    1. Define the ``PipelineConfig`` instance as a module-level variable in
       ``vllm_omni/.../pipeline.py``.
    2. If the model needs to support several configurations, e.g., because some
       stages are optional, implement a resolver that consumes the HF config
       and returns a ``PipelineConfig``.
    3. Update the registry to map the key to the new config object (in the case
       of new keys) or to the resolver func. Keep ``OMNI_PIPELINES`` sorted
       alphabetically by key.

Out of tree pipeline configs or resolvers can also be registered with register_pipeline.

NOTE: Generic single-stage diffusion is selected by ``config.resolver`` when
no registered Omni pipeline matches.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeAlias

from transformers import PretrainedConfig
from vllm.logger import init_logger

from vllm_omni.config.stage_config import (
    PipelineConfig,
)
from vllm_omni.diffusion.models.mossimage_pipeline_config import MOSS_IMAGE_PIPELINE
from vllm_omni.diffusion.models.physis.h3.pipeline_config import PHYSIS_H3_PIPELINE
from vllm_omni.diffusion.models.physis.ltx.pipeline_config import PHYSIS_LTX_PIPELINE
from vllm_omni.diffusion.models.physis.wan.pipeline_config import PHYSIS_WAN_PIPELINE
from vllm_omni.diffusion.models.pi0_pipeline_config import PI0_PIPELINE
from vllm_omni.diffusion.models.pi05_pipeline_config import PI05_PIPELINE
from vllm_omni.model_executor.models.abot_world.pipeline import ABOT_WORLD_PIPELINE
from vllm_omni.model_executor.models.alpamayo2_super.pipeline import ALPAMAYO2_SUPER_PIPELINE
from vllm_omni.model_executor.models.audex.pipeline import (
    AUDEX_S2S_PIPELINE,
    AUDEX_THINKER_ONLY_PIPELINE,
    AUDEX_TTA_PIPELINE,
    AUDEX_TTS_PIPELINE,
)
from vllm_omni.model_executor.models.audio8_tts.pipeline import AUDIO8_TTS_PIPELINE
from vllm_omni.model_executor.models.auk.pipeline import AUK_PIPELINE
from vllm_omni.model_executor.models.aura_omni.pipeline import AURA_OMNI_PIPELINE
from vllm_omni.model_executor.models.bagel.pipeline import (
    BAGEL_PIPELINE,
    BAGEL_SINGLE_STAGE_PIPELINE,
    BAGEL_THINK_PIPELINE,
)
from vllm_omni.model_executor.models.breeze_tts_2.pipeline import BREEZE_TTS_2_PIPELINE
from vllm_omni.model_executor.models.causvid_wan.pipeline import CAUSVID_WAN_PIPELINE
from vllm_omni.model_executor.models.cosmos3.pipeline import (
    COSMOS3_OMNI_DEPLOY_PIPELINE,
    COSMOS3_POLICY_PIPELINE,
)
from vllm_omni.model_executor.models.cosyvoice3.pipeline import resolve_cosyvoice3_pipeline
from vllm_omni.model_executor.models.covo_audio.pipeline import COVO_AUDIO_PIPELINE
from vllm_omni.model_executor.models.dreamzero.pipeline import DREAMZERO_PIPELINE
from vllm_omni.model_executor.models.fish_omni.pipeline import FISH_OMNI_PIPELINE
from vllm_omni.model_executor.models.fish_speech.pipeline import FISH_SPEECH_PIPELINE
from vllm_omni.model_executor.models.gepard.pipeline import GEPARD_PIPELINE
from vllm_omni.model_executor.models.glm_image.pipeline import GLM_IMAGE_PIPELINE
from vllm_omni.model_executor.models.glm_tts.pipeline import GLM_TTS_PIPELINE
from vllm_omni.model_executor.models.gr00t.pipeline import GR00T_N1D7_PIPELINE
from vllm_omni.model_executor.models.haru.pipeline import HARU_PIPELINE
from vllm_omni.model_executor.models.higgs_audio_v2.pipeline import HIGGS_AUDIO_V2_PIPELINE
from vllm_omni.model_executor.models.higgs_audio_v3.pipeline import HIGGS_AUDIO_V3_PIPELINE
from vllm_omni.model_executor.models.hunyuan_image3.pipeline import (
    HUNYUAN_IMAGE3_AR_PIPELINE,
    HUNYUAN_IMAGE3_DIT_PIPELINE,
    HUNYUAN_IMAGE3_PIPELINE,
)
from vllm_omni.model_executor.models.hunyuan_video.pipeline import HUNYUAN_VIDEO_15_PIPELINE
from vllm_omni.model_executor.models.indextts2.pipeline import (
    INDEXTTS2_PIPELINE,
    INDEXTTS25_PIPELINE,
)
from vllm_omni.model_executor.models.joyai_vl_interaction.pipeline import (
    JOYAI_VL_INTERACTION_ASR_PIPELINE,
    JOYAI_VL_INTERACTION_PIPELINE,
)
from vllm_omni.model_executor.models.lance.pipeline import LANCE_PIPELINE
from vllm_omni.model_executor.models.lfm3_audio.pipeline import LFM3_AUDIO_PIPELINE, LFM3_AUDIO_TEXT_PIPELINE
from vllm_omni.model_executor.models.lfm3_omni.pipeline import LFM3_OMNI_PIPELINE, LFM3_OMNI_TEXT_PIPELINE
from vllm_omni.model_executor.models.lingbot_world.pipeline import LINGBOT_WORLD_PIPELINE
from vllm_omni.model_executor.models.mammoth_moda2.pipeline import (
    MAMMOTH_MODA2_AR_PIPELINE,
    MAMMOTH_MODA2_PIPELINE,
)
from vllm_omni.model_executor.models.mimo_audio.pipeline import MIMO_AUDIO_PIPELINE
from vllm_omni.model_executor.models.ming3_audio.pipeline import (
    MING3_AUDIO_FLASH_PIPELINE,
    MING3_AUDIO_FLASH_THINKER_ONLY_PIPELINE,
    MING3_AUDIO_TTS_PIPELINE,
)
from vllm_omni.model_executor.models.ming3_tts.pipeline import MING3_TTS_PIPELINE
from vllm_omni.model_executor.models.ming_flash_omni.pipeline import (
    MING_FLASH_OMNI_IMAGE_PIPELINE,
    MING_FLASH_OMNI_PIPELINE,
    MING_FLASH_OMNI_THINKER_ONLY_PIPELINE,
    MING_FLASH_OMNI_TTS_PIPELINE,
)
from vllm_omni.model_executor.models.ming_image.pipeline import MING_IMAGE_PIPELINE
from vllm_omni.model_executor.models.ming_tts.pipeline import (
    MING_TTS_MOE_PIPELINE,
    MING_TTS_PIPELINE,
)
from vllm_omni.model_executor.models.minicpmo_4_5.pipeline import MINICPMO_4_5_PIPELINE
from vllm_omni.model_executor.models.minimax_h3.pipeline import MINIMAX_H3_DECODE_PIPELINE, MINIMAX_H3_PIPELINE
from vllm_omni.model_executor.models.minimax_music3.pipeline import MINIMAX_MUSIC3_PIPELINE
from vllm_omni.model_executor.models.moss_tts.pipeline import (
    MOSS_TTS_LOCAL_PIPELINE,
    MOSS_TTS_PIPELINE,
    MOSS_TTS_REALTIME_PIPELINE,
)
from vllm_omni.model_executor.models.moss_tts_nano.pipeline import MOSS_TTS_NANO_PIPELINE
from vllm_omni.model_executor.models.nemotron_voicechat.pipeline import (
    NEMOTRON_VOICECHAT_PIPELINE,
)
from vllm_omni.model_executor.models.omnivoice.pipeline import OMNIVOICE_PIPELINE
from vllm_omni.model_executor.models.personaplex.pipeline import PERSONAPLEX_PIPELINE
from vllm_omni.model_executor.models.qwen2_5_omni.pipeline import (
    QWEN2_5_OMNI_PIPELINE,
    QWEN2_5_OMNI_THINKER_ONLY_PIPELINE,
)
from vllm_omni.model_executor.models.qwen3_omni.pipeline import (
    QWEN3_OMNI_THINKER_ONLY_PIPELINE,
    resolve_qwen3_omni_pipeline,
)
from vllm_omni.model_executor.models.qwen3_tts.pipeline import QWEN3_TTS_FUSED_PIPELINE, QWEN3_TTS_PIPELINE
from vllm_omni.model_executor.models.step_audio2.pipeline import (
    STEP_AUDIO2_ASR_PIPELINE,
    STEP_AUDIO2_PIPELINE,
)
from vllm_omni.model_executor.models.taomate_h3.pipeline import TAOMATE_H3_PIPELINE
from vllm_omni.model_executor.models.vibevoice.pipeline import VIBEVOICE_PIPELINE
from vllm_omni.model_executor.models.voxcpm2.pipeline import VOXCPM2_PIPELINE
from vllm_omni.model_executor.models.voxtral_tts.pipeline import VOXTRAL_TTS_PIPELINE
from vllm_omni.model_executor.models.wan2_2.pipeline import (
    WAN2_2_EG_PIPELINE,
    WAN2_2_EGD_PIPELINE,
    WAN2_2_PIPELINE,
    WAN2_2_TI2V_PIPELINE,
)
from vllm_omni.model_executor.models.yue2.pipeline import YUE2_PIPELINE

logger = init_logger(__name__)

PipelineResolverFunc: TypeAlias = Callable[[PretrainedConfig | None], PipelineConfig | None]

# --- Multi-stage omni pipelines (LLM-centric; audio / video I/O) ---
OMNI_PIPELINES: dict[str, PipelineConfig | PipelineResolverFunc] = {
    "abot_world": ABOT_WORLD_PIPELINE,
    "alpamayo2_super": ALPAMAYO2_SUPER_PIPELINE,
    "arktts": AUDIO8_TTS_PIPELINE,
    "audex_s2s": AUDEX_S2S_PIPELINE,
    "audex_thinker_only": AUDEX_THINKER_ONLY_PIPELINE,
    "audex_tta": AUDEX_TTA_PIPELINE,
    "audex_tts": AUDEX_TTS_PIPELINE,
    "auk": AUK_PIPELINE,
    "aura_omni": AURA_OMNI_PIPELINE,
    "bagel": BAGEL_PIPELINE,
    "bagel_single_stage": BAGEL_SINGLE_STAGE_PIPELINE,
    "bagel_think": BAGEL_THINK_PIPELINE,
    "bailing_moe_v3_audio": MING3_AUDIO_FLASH_PIPELINE,
    "bailing_moe_v3_audio_thinker_only": MING3_AUDIO_FLASH_THINKER_ONLY_PIPELINE,
    "breeze": BREEZE_TTS_2_PIPELINE,
    "causvid_wan": CAUSVID_WAN_PIPELINE,
    # Cosmos3 policy / omni-deploy topologies share HF metadata with video
    # Cosmos3 checkpoints (which stay on the single-stage diffusion fallback),
    # so these entries are only reachable through a deploy yaml's ``pipeline:``
    # key (see deploy/cosmos3_policy_droid.yaml and deploy/cosmos3_omni.yaml).
    "cosmos3_omni_deploy": COSMOS3_OMNI_DEPLOY_PIPELINE,
    "cosmos3_policy": COSMOS3_POLICY_PIPELINE,
    "cosyvoice3": resolve_cosyvoice3_pipeline,
    "covo_audio": COVO_AUDIO_PIPELINE,
    "dreamzero": DREAMZERO_PIPELINE,
    "fish_omni": FISH_OMNI_PIPELINE,
    "fish_qwen3_omni": FISH_SPEECH_PIPELINE,
    "gepard": GEPARD_PIPELINE,
    "glm_image": GLM_IMAGE_PIPELINE,
    "glm_tts": GLM_TTS_PIPELINE,
    "Gr00tN1d7": GR00T_N1D7_PIPELINE,
    "haru": HARU_PIPELINE,
    "higgs_audio_v2": HIGGS_AUDIO_V2_PIPELINE,
    "higgs_multimodal_qwen3": HIGGS_AUDIO_V3_PIPELINE,
    "hunyuan_image3_ar": HUNYUAN_IMAGE3_AR_PIPELINE,
    "hunyuan_image3_dit": HUNYUAN_IMAGE3_DIT_PIPELINE,
    "hunyuan_image_3_moe": HUNYUAN_IMAGE3_PIPELINE,
    "hunyuan_video_15": HUNYUAN_VIDEO_15_PIPELINE,
    "indextts2": INDEXTTS2_PIPELINE,
    "indextts2_5": INDEXTTS25_PIPELINE,
    "joyai_vl_interaction": JOYAI_VL_INTERACTION_PIPELINE,
    "joyai_vl_interaction_asr": JOYAI_VL_INTERACTION_ASR_PIPELINE,
    "lance": LANCE_PIPELINE,
    "lfm3_audio": LFM3_AUDIO_PIPELINE,
    "lfm3_audio_text": LFM3_AUDIO_TEXT_PIPELINE,
    "lfm3_omni": LFM3_OMNI_PIPELINE,
    "lfm3_omni_text": LFM3_OMNI_TEXT_PIPELINE,
    "lingbot_world": LINGBOT_WORLD_PIPELINE,
    # Public Ming-3.0-tts-tiny still serializes the former config name.
    "lingv3_tts": MING3_TTS_PIPELINE,
    "mammoth_moda2": MAMMOTH_MODA2_PIPELINE,
    "mammoth_moda2_ar": MAMMOTH_MODA2_AR_PIPELINE,
    "mimo_audio": MIMO_AUDIO_PIPELINE,
    "ming3_audio_tts": MING3_AUDIO_TTS_PIPELINE,
    "ming3_tts": MING3_TTS_PIPELINE,
    "ming_flash_omni": MING_FLASH_OMNI_PIPELINE,
    "ming_flash_omni_image": MING_FLASH_OMNI_IMAGE_PIPELINE,
    "ming_flash_omni_thinker_only": MING_FLASH_OMNI_THINKER_ONLY_PIPELINE,
    "ming_flash_omni_tts": MING_FLASH_OMNI_TTS_PIPELINE,
    "ming_image": MING_IMAGE_PIPELINE,
    "ming_tts": MING_TTS_PIPELINE,
    "ming_tts_moe": MING_TTS_MOE_PIPELINE,
    "minicpmo_4_5": MINICPMO_4_5_PIPELINE,
    "minimax_h3_disaggregated": MINIMAX_H3_PIPELINE,
    "minimax_h3_disaggregated_decode": MINIMAX_H3_DECODE_PIPELINE,
    "minimax_music3": MINIMAX_MUSIC3_PIPELINE,
    "moss_image": MOSS_IMAGE_PIPELINE,
    "moss_tts_delay": MOSS_TTS_PIPELINE,
    "moss_tts_local": MOSS_TTS_LOCAL_PIPELINE,
    "moss_tts_nano": MOSS_TTS_NANO_PIPELINE,
    "moss_tts_realtime": MOSS_TTS_REALTIME_PIPELINE,
    # Alias: the Nemotron-Labs-Audex-2B repo-root config.json reports
    # ``model_type: nemotron_labs_audex``; bare ``vllm-omni serve <repo>``
    # auto-detects through it and must land on the default (TTS) pipeline.
    "nemotron_labs_audex": AUDEX_TTS_PIPELINE,
    # Alias: lets bare `vllm-omni serve <NVIDIA-NemotronLabs-VoiceChat-11B dir>`
    # auto-detect through the path-basename fallback (the checkpoint config.json
    # has no model_type key).
    "nemotron_labs_voicechat": NEMOTRON_VOICECHAT_PIPELINE,
    "nemotron_voicechat": NEMOTRON_VOICECHAT_PIPELINE,
    "omnivoice": OMNIVOICE_PIPELINE,
    "personaplex": PERSONAPLEX_PIPELINE,
    "physis_h3": PHYSIS_H3_PIPELINE,
    "physis_ltx": PHYSIS_LTX_PIPELINE,
    "physis_wan": PHYSIS_WAN_PIPELINE,
    "pi0": PI0_PIPELINE,
    "pi05": PI05_PIPELINE,
    "qwen2_5_omni": QWEN2_5_OMNI_PIPELINE,
    "qwen2_5_omni_thinker_only": QWEN2_5_OMNI_THINKER_ONLY_PIPELINE,
    "qwen3_omni_moe": resolve_qwen3_omni_pipeline,
    "qwen3_omni_moe_thinker_only": QWEN3_OMNI_THINKER_ONLY_PIPELINE,
    "qwen3_tts": QWEN3_TTS_PIPELINE,
    "qwen3_tts_fused": QWEN3_TTS_FUSED_PIPELINE,
    "step_audio_2": STEP_AUDIO2_PIPELINE,
    "step_audio_2_asr": STEP_AUDIO2_ASR_PIPELINE,
    "taomate_h3": TAOMATE_H3_PIPELINE,
    "vibevoice": VIBEVOICE_PIPELINE,
    "voxcpm2": VOXCPM2_PIPELINE,
    "voxtral_tts": VOXTRAL_TTS_PIPELINE,
    "wan2_2": WAN2_2_PIPELINE,
    # Disaggregated diffusion variant (opt-in): Wan Encode/Generation split.
    "wan2_2_eg": WAN2_2_EG_PIPELINE,
    "wan2_2_egd": WAN2_2_EGD_PIPELINE,
    "wan2_2_ti2v": WAN2_2_TI2V_PIPELINE,
    "yue2": YUE2_PIPELINE,
}


def register_pipeline(pipeline: PipelineConfig | PipelineResolverFunc, model_type: str | None = None):
    """Register an out of tree pipeline or PipelineResolverFunc to a model_type key.
    If a PipelineConfig is provided, model_type is optional, and pipeline.model_type
    will be used by default. If a callable is provided, model_type must be provided,
    since resolvers can return multiple different PipelineConfigs depending on the
    consumed config.
    """
    if isinstance(pipeline, PipelineConfig):
        model_type = model_type if model_type is not None else pipeline.model_type
    elif model_type is None:
        raise ValueError("Model type must be explicitly provided when registering a pipeline resolver")

    if model_type in OMNI_PIPELINES:
        logger.warning(f"Model type {model_type} is already registered; the old mapping will be clobbered")
    OMNI_PIPELINES[model_type] = pipeline


def resolve_pipeline_config(
    model_type: str,
    hf_config: PretrainedConfig | None = None,
) -> PipelineConfig | None:
    """Resolve a registry key to a concrete pipeline config."""
    if model_type not in OMNI_PIPELINES:
        logger.warning("Model type %s is not registered to OMNI_PIPELINES", model_type)
        return None
    pipeline = OMNI_PIPELINES[model_type]
    return pipeline(hf_config) if callable(pipeline) else pipeline
