# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Stage configuration system for vLLM-Omni."""

from __future__ import annotations

import functools
import math
import re
import warnings
from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass, field, fields
from enum import Enum
from pathlib import Path
from typing import Any, Literal, NamedTuple

from transformers import PretrainedConfig
from vllm.config import KernelConfig
from vllm.logger import init_logger
from vllm.v1.core.sched.scheduler import Scheduler as VLLMScheduler

from vllm_omni.config.endpoint_policy import EndpointRestriction
from vllm_omni.config.speech_cache import SpeechCacheConfig
from vllm_omni.config.weight_sharing import WeightSharingConfig, parse_weight_sharing
from vllm_omni.config.yaml_util import create_config, load_yaml_config, to_dict
from vllm_omni.core.sched.omni_ar_scheduler import OmniARAsyncScheduler, OmniARScheduler
from vllm_omni.core.sched.omni_generation_scheduler import OmniGenerationScheduler

logger = init_logger(__name__)

_DEPLOY_DIR = Path(__file__).resolve().parent.parent / "deploy"

_STAGE_OVERRIDE_PATTERN = re.compile(r"^stage_(\d+)_(.+)$")

_RUNTIME_ONLY_OVERRIDE_FIELDS = frozenset(
    {
        "devices",
        "max_batch_size",
        "num_replicas",
    }
)

_TOPOLOGY_OWNED_ENGINE_FIELDS = frozenset(
    {
        "requires_full_payload_input",
        "scheduling_metadata_adapter",
    }
)

SKIP_STREAMING_UPDATES_ATTR = "_omni_skip_streaming_updates"


def skip_on_streaming_updates(func: Callable[..., Any]) -> Callable[..., Any]:
    """Mark a ``prompt_transform_func`` to run only when a request is first submitted.

    The engine then does not call it on streaming-input updates, which carry
    the later chunks of a request that already passed the transform.
    """
    setattr(func, SKIP_STREAMING_UPDATES_ATTR, True)
    return func


def _normalize_stage_backend_fields(stage: StageDeployConfig) -> None:
    """Normalize promoted backends and enforce their precedence over extras."""
    kernels = {
        name: getattr(stage, name) for name in ("moe_backend", "linear_backend") if getattr(stage, name) is not None
    }
    normalized = KernelConfig(**kernels)
    for name in kernels:
        setattr(stage, name, getattr(normalized, name))

    # Only backend selections gain this precedence rule; unrelated extras keep
    # their existing merge behavior. Never retain a duplicate legacy key.
    stage.engine_extras = dict(stage.engine_extras)
    for name in ("attention_backend", "moe_backend", "linear_backend"):
        value = getattr(stage, name)
        if value is not None and name in stage.engine_extras:
            extra = stage.engine_extras.pop(name)
            comparable_extra = extra
            if name in ("moe_backend", "linear_backend"):
                # First-class fields have already gone through KernelConfig,
                # while legacy extras may still use mixed case or hyphens.
                # Compare the same canonical spelling before warning.
                try:
                    comparable_extra = getattr(KernelConfig(**{name: extra}), name)
                except (TypeError, ValueError):
                    # An invalid shadowed extra is still discarded, as before.
                    comparable_extra = extra
            if value != comparable_extra:
                warnings.warn(
                    f"stage {stage.stage_id}: {name}={value!r} overrides engine_extras[{name!r}]={extra!r}.",
                    UserWarning,
                    stacklevel=3,
                )


def pipeline_cfg_resolver(config_type: type[PretrainedConfig]):
    """Wraps a resolver such that we return None if a hf_config of the wrong type is provided."""

    def resolver_builder(func):
        @functools.wraps(func)
        def wrapper(hf_config: PretrainedConfig | None):
            if hf_config is None or not isinstance(hf_config, config_type):
                return None
            return func(hf_config)

        return wrapper

    return resolver_builder


def build_stage_runtime_overrides(
    stage_id: int,
    cli_overrides: dict[str, Any],
    *,
    internal_keys: set[str] | frozenset[str] | None = None,
) -> dict[str, Any]:
    """Build per-stage runtime overrides from global and ``stage_<id>_*`` kwargs.

    ``internal_keys`` defaults to the union of
    ``arg_utils.internal_blacklist_keys()`` and ``arg_utils.SHARED_FIELDS``
    so that neither orchestrator-only fields nor shared-pipeline fields
    (``model`` / ``log_stats`` / ``stage_id``) leak
    into a stage's per-stage runtime overrides — the orchestrator sets those
    uniformly for every stage, they are not per-stage knobs. Callers can
    pass an explicit set for tests or specialized flows.
    """
    if internal_keys is None:
        from vllm_omni.engine.arg_utils import SHARED_FIELDS, internal_blacklist_keys

        # Some fields are modeled as orchestrator-owned for top-level CLI
        # parsing, but are also legitimate deploy-time stage overrides. Keep
        # the default blacklist for true orchestrator/shared fields while
        # allowing any field explicitly represented by the deploy schema to
        # continue flowing into per-stage overrides.
        internal_keys = (internal_blacklist_keys() | SHARED_FIELDS) - deploy_runtime_override_keys()

    result: dict[str, Any] = {}
    stage_overrides: dict[str, Any] = {}

    for key, value in cli_overrides.items():
        if value is None or key in internal_keys:
            continue

        match = _STAGE_OVERRIDE_PATTERN.match(key)
        if match is not None:
            override_stage_id = int(match.group(1))
            param_name = match.group(2)
            if override_stage_id == stage_id and param_name not in internal_keys:
                stage_overrides[param_name] = value
            continue

        result[key] = value

    # Stage-scoped inputs take precedence regardless of their insertion order.
    result.update(stage_overrides)
    return result


def normalize_pipeline_cli_overrides(
    pipeline: PipelineConfig,
    cli_overrides: dict[str, Any],
) -> dict[str, Any]:
    """Translate pipeline-owned global CLI aliases into stage-scoped overrides."""
    normalized = dict(cli_overrides)
    for source, (stage_id, target) in pipeline.stage_cli_aliases.items():
        invalid_stage_keys = [
            key
            for key, value in normalized.items()
            if value is not None
            and (match := _STAGE_OVERRIDE_PATTERN.match(key)) is not None
            and match.group(2) == source
            and int(match.group(1)) != stage_id
        ]
        if invalid_stage_keys:
            invalid = ", ".join(sorted(invalid_stage_keys))
            raise ValueError(
                f"{invalid} cannot be set for pipeline {pipeline.model_type!r}; "
                f"{source} belongs to stage {stage_id} as {target}."
            )
        value = normalized.pop(source, None)
        if value is None:
            continue
        stage_key = f"stage_{stage_id}_{target}"
        stage_value = normalized.get(stage_key)
        if stage_value is not None and stage_value != value:
            warnings.warn(
                f"Ignoring {source}={value!r} because {stage_key}={stage_value!r} takes precedence.",
                UserWarning,
                stacklevel=2,
            )
            continue
        normalized[stage_key] = value
    return normalized


def _apply_diffusion_parallel_runtime_overrides(
    engine_args: dict[str, Any],
    runtime_overrides: dict[str, Any],
) -> None:
    """Move diffusion parallel overrides into nested ``parallel_config``."""
    from vllm_omni.diffusion.data import DiffusionParallelConfig

    parallel_fields = frozenset(f.name for f in fields(DiffusionParallelConfig))
    parallel_config = engine_args.get("parallel_config")
    parallel_config_dict = dict(parallel_config) if parallel_config is not None else None
    degree_overridden = False
    sequence_parallel_explicit = runtime_overrides.get("sequence_parallel_size") is not None

    for key in list(runtime_overrides.keys()):
        value = runtime_overrides.get(key)
        if value is None or key not in parallel_fields:
            continue
        if parallel_config_dict is None:
            parallel_config_dict = {}
        if key in ("ulysses_degree", "ring_degree", "allgather_degree"):
            degree_overridden = True
        parallel_config_dict[key] = runtime_overrides.pop(key)

    if parallel_config_dict is not None and degree_overridden and not sequence_parallel_explicit:
        ulysses_degree = parallel_config_dict.get("ulysses_degree") or 1
        ring_degree = parallel_config_dict.get("ring_degree") or 1
        allgather_degree = parallel_config_dict.get("allgather_degree") or 1
        parallel_config_dict["sequence_parallel_size"] = ulysses_degree * ring_degree * allgather_degree

    if parallel_config_dict is not None:
        engine_args["parallel_config"] = parallel_config_dict


def reconcile_diffusion_attention_overrides(
    engine_args: dict[str, Any],
    runtime_overrides: Mapping[str, Any],
) -> None:
    """Apply CLI precedence across the two diffusion attention representations.

    ``diffusion_attention_backend`` and ``diffusion_attention_config.default``
    express the same setting and are rejected downstream when both are set, so
    a CLI value in one form replaces the YAML value in the other.
    """
    if runtime_overrides.get("diffusion_attention_backend") is not None:
        yaml_config = engine_args.get("diffusion_attention_config")
        if isinstance(yaml_config, Mapping) and yaml_config.get("default") is not None:
            remaining = {k: v for k, v in yaml_config.items() if k != "default"}
            if remaining:
                engine_args["diffusion_attention_config"] = remaining
            else:
                engine_args.pop("diffusion_attention_config")
    if runtime_overrides.get("diffusion_attention_config") is not None:
        engine_args.pop("diffusion_attention_backend", None)


class StageType(str, Enum):
    """Type of processing stage in the Omni pipeline."""

    # TODO(@lishunyang12): remove once all models migrate to StageExecutionType
    LLM = "llm"
    DIFFUSION = "diffusion"


class StageExecutionType(str, Enum):
    """Merged StageType + WorkerType — 3 combinations today."""

    LLM_AR = "llm_ar"
    LLM_GENERATION = "llm_generation"
    DIFFUSION = "diffusion"


class DiffusionStageRole(str, Enum):
    """Role of a diffusion stage within a (possibly disaggregated) pipeline.

    ``execution_type`` answers *which engine* runs a stage; ``stage_role`` is an
    orthogonal axis that answers *which slice of a diffusion model* the stage
    runs. Splitting a single diffusion model across stages by role lets many
    DiT-style models become disaggregatable through configuration alone, with no
    per-model source changes:

    - ``FULL``:    run the whole pipeline (encode + denoise + decode) in one
                   stage. This is the default / single-stage behavior.
    - ``ENCODE``:  run only the (text/image) encoder(s) and emit conditioning
                   embeddings for a downstream stage.
    - ``DENOISE``: run only the DiT denoise loop consuming upstream embeddings
                   and emit latents for a downstream decode stage.
    - ``DENOISE_DECODE``: run the DiT denoise loop and VAE decode together (the
                          generation stage of E/G disaggregation).
    - ``DECODE``:  run only the VAE decode on upstream latents (the trailing
                   stage of a 3-way E/G/D split).
    """

    FULL = "full"
    ENCODE = "encode"
    DENOISE = "denoise"
    DENOISE_DECODE = "denoise_decode"
    DECODE = "decode"


# Legacy ``model_stage`` strings -> ``DiffusionStageRole``. ``model_stage`` was
# a free-form string ("text_encode"/"dit") before roles existed; keep the map so
# older stage configs and deploy YAML keep working.
_MODEL_STAGE_TO_ROLE: dict[str, DiffusionStageRole] = {
    "text_encode": DiffusionStageRole.ENCODE,
    "encode": DiffusionStageRole.ENCODE,
    # Legacy single-stage configs (e.g. wan2_2_ti2v) use "dit" for the whole
    # pipeline; disaggregated topologies set ``stage_role`` explicitly.
    "dit": DiffusionStageRole.FULL,
    "denoise": DiffusionStageRole.DENOISE,
    "denoise_decode": DiffusionStageRole.DENOISE_DECODE,
    "decode": DiffusionStageRole.DECODE,
    "vae_decode": DiffusionStageRole.DECODE,
    "diffusion": DiffusionStageRole.FULL,
    "full": DiffusionStageRole.FULL,
}


def resolve_diffusion_stage_role(
    stage_role: DiffusionStageRole | str | None,
    model_stage: str | None = None,
) -> DiffusionStageRole:
    """Resolve the effective diffusion stage role.

    Prefers an explicit ``stage_role`` and otherwise falls back to the legacy
    free-form ``model_stage`` string. Unknown values resolve to ``FULL`` so a
    plain single-stage diffusion model keeps running the whole pipeline.
    """
    if isinstance(stage_role, DiffusionStageRole):
        return stage_role
    if isinstance(stage_role, str) and stage_role:
        try:
            return DiffusionStageRole(stage_role)
        except ValueError:
            resolved = _MODEL_STAGE_TO_ROLE.get(stage_role)
            if resolved is not None:
                return resolved
    if model_stage:
        return _MODEL_STAGE_TO_ROLE.get(model_stage, DiffusionStageRole.FULL)
    return DiffusionStageRole.FULL


def _resolve_scheduler(
    execution_type: StageExecutionType,
    async_scheduling: bool = True,
) -> type[VLLMScheduler] | None:
    """Return the scheduler class for the given execution_type.

    NOTE: For AutoRegressive stages, we have two schedulers for sync / async
    respectively, and decide which to used based on the value of async_scheduling.
    For other execution types, async_scheduling is not used.
    """
    if execution_type == StageExecutionType.LLM_AR:
        if not async_scheduling:
            return OmniARScheduler
        return OmniARAsyncScheduler
    if execution_type == StageExecutionType.LLM_GENERATION:
        return OmniGenerationScheduler
    # Diffusion currently returns None here.
    return None


def _scheduler_path(cls: type[VLLMScheduler] | None) -> str | None:
    """Return the dotted import path for a scheduler class (``None`` passes through)."""
    if cls is None:
        return None
    return f"{cls.__module__}.{cls.__qualname__}"


@dataclass(frozen=True)
class StagePipelineConfig:
    """Fixed topology for one stage (frozen, not user-configurable)."""

    stage_id: int
    model_stage: str
    execution_type: StageExecutionType = StageExecutionType.LLM_AR
    # Diffusion-only: which slice of a diffusion model this stage runs
    # (encode / denoise / decode / full). Orthogonal to ``execution_type`` and
    # only meaningful when ``execution_type == DIFFUSION``. ``None`` falls back
    # to ``model_stage`` (legacy) and ultimately to ``FULL``.
    stage_role: DiffusionStageRole | None = None
    input_sources: tuple[int, ...] = ()
    final_output: bool = False
    final_output_type: str | None = None
    owns_tokenizer: bool = False
    requires_multimodal_data: bool = False
    hf_config_name: str | None = None
    engine_output_type: str | None = None
    model_arch: str | None = None
    # The model keeps per-request execution state while awaiting the next
    # async chunk, so the parked request continues to consume model capacity.
    retains_state_across_chunks: bool = False
    # The model may yield output before completing the current input unit.
    supports_pending_generation: bool = False
    # Some stateful audio stages cannot roll back already consumed frames.
    supports_running_prefix_cache_reset: bool = True
    # Recompute preemption (upstream's only mode) frees KV and replays the
    # prompt. A native-AR stage whose decode step feeds more than the sampled
    # token into the model -- side-channel codes, per-request hidden state,
    # vocoder progress -- cannot rebuild that KV from the token stream. Under
    # ``"fail"`` the scheduler reclaims the request's resources and emits one
    # terminal error instead of requeuing it, so the caller never receives the
    # spliced audio the replay would produce.
    recompute_preemption: Literal["allow", "fail"] = "allow"
    sampling_constraints: dict[str, Any] = field(default_factory=dict)
    custom_process_input_func: str | None = None
    custom_process_next_stage_input_func: str | None = None
    # Alternates picked by ``merge_pipeline_deploy`` based on ``deploy.async_chunk``.
    async_chunk_process_next_stage_input_func: str | None = None
    sync_process_input_func: str | None = None
    supports_native_mrv2_data_plane: bool = False
    supports_duplex_mrv2: bool = False
    # Rewrites the Stage-0 view of a raw prompt before vLLM input processing.
    # The callable receives ``(prompt, sampling_params_list)``; downstream
    # stages continue to receive the original prompt. It also runs on
    # streaming-input updates unless marked with ``skip_on_streaming_updates``.
    prompt_transform_func: str | None = None
    prompt_expand_func: str | None = None
    cfg_kv_collect_func: str | None = None
    # Payload keys this stage expects to receive from its upstream stage over
    # the omni connector instead of through the orchestrator IPC hop. Declaring
    # them is what enables the worker-side connector receive path, so an empty
    # tuple leaves existing deployments untouched.
    stage_input_payload_keys: tuple[str, ...] = ()
    stage_input_optional_payload_keys: tuple[str, ...] = ()
    # Mirror of the above on the producing side: keys this stage hands to the
    # next stage over the connector. Only diffusion producers need this; AR
    # stages already send through ``send_full_payload_outputs``.
    stage_output_payload_keys: tuple[str, ...] = ()
    # Set on an async-chunk receiving stage. The orchestrator calls it with the
    # original prompt when it submits this stage's prewarm placeholder; it
    # returns a flat ``{name: Tensor | scalar}`` dict (or ``None``) sent under
    # ``ASYNC_CHUNK_PREWARM_NS`` so the stage can warm up before chunk 0.
    async_chunk_prewarm_payload_func: str | None = None
    omni_kv_config: dict[str, Any] | None = None
    scheduler_cls: str | None = None
    # Model subdirectory indirections: for multi-component HF repos where the
    # stage's config/tokenizer lives in a subdirectory (e.g. GLM-Image's AR
    # config is in ``vision_language_encoder/``).  Consumed at stage-init time
    # by ``stage_init_utils._resolve_model_tokenizer_paths``.
    model_subdir: str | None = None
    tokenizer_subdir: str | None = None
    # Model-owned hook that resolves a pipeline root to this stage's checkpoint.
    # Consumed and removed before backend engine args are constructed.
    model_path_resolver: str | None = None
    # Keep a single-replica diffusion stage in the orchestrator process.
    # Disabled by default so existing multi-stage pipelines retain subprocess
    # isolation unless their topology explicitly opts in.
    inline_diffusion: bool = False
    # Whether the non-async path waits for a complete upstream payload from
    # the model-runner connector before scheduling this stage.
    requires_full_payload_input: bool = False
    # Stage 0 only: a chat request carrying none of these input modalities
    # skips this stage and enters at stage 1 (e.g. Qwen3-ASR runs only for
    # requests with audio). Empty means every request runs it.
    bypass_without_modalities: tuple[str, ...] = ()
    # Optional model-owned adapter for runner payload metadata that affects
    # scheduling. The scheduler only receives its typed effects.
    scheduling_metadata_adapter: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PipelineConfig:
    """Complete pipeline topology for a model (frozen)."""

    model_type: str
    model_arch: str = ""
    stages: tuple[StagePipelineConfig, ...] = ()
    # A single stage that streams its own final output in async-chunk mode
    # (e.g. a Talker decoding audio in-stage) keeps deploy.async_chunk.
    single_stage_async_chunk: bool = False
    # HF architecture aliases: used by StageConfigFactory when the model's
    # HF config reports a generic model_type that collides with a different
    # model (e.g. MiMo Audio reports model_type="qwen2"). The factory
    # matches ``hf_config.architectures[*]`` against this tuple to route
    # to the correct pipeline. Leave empty for models with unique model_type.
    hf_architectures: tuple[str, ...] = ()
    # Optional second-stage predicate for resolving an arch-name collision
    # between sibling model generations that ship the same
    # ``architectures=[...]`` entry. When the arch-fallback in
    # ``StageConfigFactory.create_from_model`` finds an intersection with
    # ``hf_architectures``, it additionally evaluates this predicate against
    # the loaded ``hf_config`` and only selects this pipeline when it
    # returns ``True``. Leave ``None`` to skip the extra check (default).
    # Example: MiniCPM-o 4.5 and 2.6 both ship ``architectures=["MiniCPMO"]``
    # but differ on the ``version`` field, so the 4.5 pipeline declares
    # ``hf_config_predicate=lambda c: getattr(c, "version", "") == "4.5"``
    # to avoid misrouting 2.6 checkpoints.
    hf_config_predicate: Callable[[Any], bool] | None = None
    # Canonical diffusion runtime class for this registered pipeline.
    # Serving uses it as a metadata fallback; model_index.json discovery
    # also matches its _class_name against this value and its aliases.
    # None delegates class discovery to the checkpoint metadata.
    diffusers_class_name: str | None = None
    diffusers_class_aliases: tuple[str, ...] = ()
    endpoint_restrictions: tuple[EndpointRestriction, ...] = ()
    # Dotted path of the model's ``DuplexModelPlugin``. Online serving uses
    # DuplexOmni only when the deploy configuration selects session_mode: duplex.
    duplex_plugin: str | None = None
    # Preserve legacy turn deployments when adding an optional duplex plugin.
    default_session_mode: str | None = None
    # Legacy duplex wiring of the model that is not ported to the plugin
    # framework yet (Nemotron VoiceChat, RFC vllm-omni#7181 PR 4). Nothing
    # reads them: a pipeline that only declares these is served turn-based.
    # The fields go away with the PR that ports it to ``duplex_plugin``.
    duplex_runtime_extension: str | None = None
    duplex_serving_adapter: str | None = None
    duplex_control_enabled: bool = False
    # Bundled deploy defaults for this concrete pipeline topology. The file is
    # loaded from vllm_omni/deploy; None uses DeployConfig defaults.
    default_deploy_config_name: str | None = None
    # Global CLI spelling -> (stage id, stage-local spelling).
    stage_cli_aliases: dict[str, tuple[int, str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        errors = self.get_validation_errors()

        if errors:
            # If we have multiple errors, put them on separate indented lines for readability
            multi_sep = "\n\t"
            error_str = multi_sep.join(errors)
            if len(errors) > 1:
                error_str = f"{multi_sep}{error_str}"
            raise ValueError(f"PipelineConfig initialization failed with the following error(s): {error_str}")

    def get_stage(self, stage_id: int) -> StagePipelineConfig | None:
        """Look up a stage by its ID."""
        for stage in self.stages:
            if stage.stage_id == stage_id:
                return stage
        return None

    def get_validation_errors(self) -> list[str]:
        """Return list of topology errors (empty if valid)."""
        errors: list[str] = []
        if not self.stages:
            errors.append("Pipeline has no stages defined")
            return errors
        stage_ids = [s.stage_id for s in self.stages]
        if len(stage_ids) != len(set(stage_ids)):
            errors.append("Duplicate stage IDs found")
        stage_id_set = set(stage_ids)
        for stage in self.stages:
            for src in stage.input_sources:
                if src not in stage_id_set:
                    errors.append(f"Stage {stage.stage_id} references non-existent input source {src}")
                if src == stage.stage_id:
                    errors.append(f"Stage {stage.stage_id} references itself")
        if not any(not s.input_sources for s in self.stages):
            errors.append("No entry point (stage with empty input_sources)")
        # Request completion and client-visible output are both driven by stages
        # that declare ``final_output`` (see ``Orchestrator._route_output``). A
        # pipeline without one can never emit a result, so every request hangs.
        if not any(s.final_output for s in self.stages):
            errors.append("No terminal stage (stage with final_output=True)")
        return errors


@dataclass
class StageDeployConfig:
    """Per-stage deployment knobs.

    Only fields whose value legitimately varies across stages of the same
    pipeline live here (e.g. ``max_num_seqs`` on thinker vs talker,
    ``devices`` for GPU placement). Pipeline-wide settings
    (``trust_remote_code``, ``distributed_executor_backend``, ``dtype``,
    ``quantization``, prefix/chunked prefill, DP/PP sizes) are declared at
    the top level of ``DeployConfig`` and propagated to every stage.
    """

    # === Omni stage wrapper fields ===
    # Stage identity and Omni runtime placement.
    stage_id: int
    devices: str | None = None
    num_replicas: int = 1
    env: dict[str, Any] | None = None

    # False opts this stage out of pipeline-wide async chunking.
    async_chunk: bool | None = None
    # Overrides the deploy-level ``model_runner`` for this stage, so a pipeline
    # can run e.g. its LLM stage on v1 and its codec stages on MRv2.
    model_runner: Literal["v1", "v2"] | None = None

    # Inter-stage connector wiring and request defaults.
    output_connectors: dict[str, str] | None = None
    input_connectors: dict[str, str] | None = None
    default_sampling_params: dict[str, Any] | None = None
    default_pooling_params: dict[str, Any] | None = None
    subtalker_sampling_params: dict[str, Any] | None = None
    silence_ban_frames: int = 0

    # === Generic stage engine fields ===
    # Parallelism, scheduler, and memory-capacity controls.
    tensor_parallel_size: int | None = None
    enable_expert_parallel: bool | None = None
    gpu_memory_utilization: float | None = None
    max_num_seqs: int | None = None
    max_num_batched_tokens: int | None = None
    max_model_len: int | None = None

    # Upstream AR attention and shared AR/diffusion kernel selection.
    # None means omitted, so model/platform defaults remain authoritative.
    attention_backend: str | None = None
    moe_backend: str | None = None
    linear_backend: str | None = None

    # Generic execution, scheduling, and KV/cache behavior.
    enforce_eager: bool | None = None
    async_scheduling: bool | None = None
    disable_hybrid_kv_cache_manager: bool | None = None
    mm_processor_cache_gb: float | None = None
    # Hybrid-mamba stages (e.g. the NemotronVoiceChat thinker's NemotronH
    # backbone) pin the SSM state dtype; projected onto vLLM CacheConfig.
    mamba_ssm_cache_dtype: str | None = None

    # Generic compilation, profiling, tokenizer/config parsing, and model
    # loading controls.
    compilation_config: dict[str, Any] | None = None
    profiler_config: dict[str, Any] | None = None
    skip_mm_profiling: bool | None = None
    enable_flashinfer_autotune: bool | None = None
    config_format: str | None = None
    load_format: str | None = None
    tokenizer_mode: str | None = None

    # === Diffusion stage runtime fields ===
    # Diffusion parallel_config deploy/runtime override fields.
    ulysses_degree: int | None = None
    ulysses_mode: str | None = None
    ulysses_a2a_permute: bool | None = None
    ring_degree: int | None = None
    allgather_degree: int | None = None
    sequence_parallel_size: int | None = None
    cfg_parallel_size: int | None = None
    vae_patch_parallel_size: int | None = None
    vae_parallel_mode: str | None = None
    text_encoder_tp_size: int | None = None
    use_hsdp: bool | None = None
    hsdp_shard_size: int | None = None
    hsdp_replicate_size: int | None = None

    # Diffusion model loading and adapter construction.
    model_class_name: str | None = None
    diffusion_load_format: str | None = None
    controlnet_model_path: str | None = None
    """Local original H3 Fun ControlNet Union safetensors checkpoint."""
    lora_path: str | list[str] | None = None
    lora_backend: str | None = None
    lora_application: str | None = None
    lora_scale: float | None = None
    diffusers_load_kwargs: dict[str, Any] | None = None
    diffusers_call_kwargs: dict[str, Any] | None = None
    diffusion_quantization_config: str | None = None
    diffusion_attention_backend: str | None = None
    fastvideo_vsa_topk: int | None = None
    diffusion_attention_config: dict[str, Any] | None = None
    diffusion_attention_schedule: dict[str, Any] | None = None

    # Diffusion execution, cache, and VAE behavior.
    diffusion_compile_granularity: str | None = None
    diffusion_compile_dynamic: bool | None = None
    # CUDA graph capture of fixed-shape KV-cache decode steps (Qwen-Image-2.1
    # today). Independent of compilation_config.cudagraph_mode;
    # enforce_eager=True also disables it.
    enable_cuda_graph_decode: bool | None = None
    diffusion_use_graph: bool | None = None
    diffusion_graph_release_after_denoise: bool | None = None
    fa_deterministic: bool | None = None
    enable_cfg_batching: bool | None = None
    cache_backend: str | None = None
    cache_config: dict[str, Any] | None = None
    video_output_transport: dict[str, Any] | None = None
    enable_cache_dit_summary: bool | None = None
    step_execution: bool | None = None
    vae_use_slicing: bool | None = None
    vae_use_tiling: bool | None = None
    vae_fast_path: str | None = None
    vae_encode_fast_path: str | None = None
    boundary_ratio: float | None = None
    flow_shift: float | None = None
    diffusion_kv_cache_dtype: str | None = None
    diffusion_kv_cache_skip_steps: str | None = None
    diffusion_kv_cache_skip_layers: str | None = None

    # Runtime optimizations used by diffusion loading/execution.
    hsdp_weight_load_strategy: str | None = None
    enable_multithread_weight_load: bool | None = None
    enable_broadcast_weight_load: bool | None = None
    num_weight_load_threads: int | None = None
    diffusion_offload_config: dict[str, Any] | None = None
    kv_offload_config: dict[str, Any] | None = None
    # Compatibility aliases for existing callers and model-specific stage
    # lifecycles that are broader than the compact dit/text_encoder selector.
    enable_cpu_offload: bool | None = None
    enable_layerwise_offload: bool | None = None

    enable_distributed_layerwise_offload: bool | None = None
    dlo_use_allgather: bool | None = None
    dlo_chunk_size_mb: int | None = None
    dlo_resident_layers: int | None = None
    host_weight_runtime_mode: str | None = None
    host_weight_runtime_root: str | None = None
    dlo_host_registration_limit_gib: float | None = None
    # Diffusion-specific debug and observability knobs.
    enable_diffusion_pipeline_profiler: bool | None = None
    # Mixed-resolution batch packing (MixFusion) server-level defaults.
    enable_mixfusion: bool | None = None
    mixfusion_min_chunk_tokens: int | None = None
    mixfusion_max_chunks: int | None = None

    # Modality/service constraints consumed outside the core engine config.
    max_generated_image_size: int | None = None
    tts_max_instructions_length: int | None = None

    # === Pass-through stage engine fields ===
    # Pass-through stage engine args that are not represented above.
    engine_extras: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _normalize_stage_backend_fields(self)


@dataclass(frozen=True)
class DuplexSessionRuntimeConfig:
    """Server-owned lifecycle and per-session buffering limits."""

    idle_ttl_s: float | None = 300.0
    disconnect_grace_s: float = 30.0
    reaper_interval_s: float = 5.0
    resume_replay_ttl_s: float = 60.0
    resume_replay_max_bytes_per_session: int = 8 * 1024 * 1024
    max_pending_input_bytes_per_session: int = 16 * 1024 * 1024
    max_pending_turns_per_session: int = 4
    max_pending_output_bytes_per_session: int = 2 * 1024 * 1024
    max_pending_output_events_per_session: int = 512
    max_sessions: int = 1
    # Total function-call records one session may track until it closes --
    # pending calls and terminal tombstones together. At the limit, new calls
    # are refused without closing the session or evicting records. Keeping
    # terminal tombstones prevents a late ``function_call_output`` from binding
    # to a newer call that reuses its call_id.
    max_tool_calls_per_session: int = 4096
    replica_policy: Literal["legacy", "least_sessions"] = "legacy"
    max_sessions_per_replica: int | None = None
    replica_groups: list[dict[int, int]] | None = None
    # Unread by the plugin framework. It used to bound the per-session
    # completed-append table that made a retried append RPC submit once; the
    # framework carries appends as one-way commands on the runner's ordered
    # mailbox, so there is no client-visible retry to deduplicate. The field
    # stays so the deploy configs of the models that are not ported yet still
    # parse, and goes away with the PR that ports the last of them.
    completed_append_cache_size: int = 256
    server_vad_model_path: str | None = None
    # Local Smart Turn v3.2 ONNX artifact for ``turn_detection: semantic_vad``;
    # null resolves the pinned file from the Hugging Face cache.
    semantic_vad_model_path: str | None = None
    # Experimental Qwen heard-text calibration. Server-owned URL; never accept
    # a transcription endpoint from a client session.update.
    history_asr_url: str | None = None
    history_asr_model: str | None = None
    history_asr_max_concurrency: int = 4
    # Opt-in token-rate estimate; fallback ms/token when audio generation is incomplete.
    history_ms_per_token: float | None = None
    history_calibration_timeout_ms: int = 1000
    history_audio_max_bytes_per_session: int = 8 * 1024 * 1024
    # Server-only model configuration. Models validate their own options;
    # client session.update cannot select code or change these limits.
    model_custom_options: dict[str, object] = field(default_factory=dict)
    # Startup warmup, before real ``/v1/realtime`` clients are admitted.
    # Audio-primary models run this many silent frames; 0 disables that path.
    # Video-required models (AURA) still run one short non-silent audio chunk
    # plus one image when this is 0, so ASR, vision, Talker and Code2Wav
    # compile their real shapes. The empty per-stage JIT registry does not.
    # A negative value disables every startup warmup.
    warmup_frames: int = 0
    # Opt-in L1 history view for plugins that consume ``conversation_view``
    # (Qwen3-Omni): user turns before the N most recent user runs drop their
    # audio and image parts there. ``None`` leaves every prompt unchanged.
    context_keep_media_turns: int | None = None
    # Record per-turn stage work and emitted audio and answer the client's
    # ``session.stats.get`` (RFC #8325). Off: nothing is recorded or attached.
    # Single-host only: stage and API timestamps share one CLOCK_MONOTONIC.
    collect_stats: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.model_custom_options, dict):
            raise ValueError("duplex_session.model_custom_options must be a mapping")
        if not isinstance(self.collect_stats, bool):
            raise ValueError("duplex_session.collect_stats must be a boolean")
        if self.replica_policy not in ("legacy", "least_sessions"):
            raise ValueError("duplex_session.replica_policy must be 'legacy' or 'least_sessions'")
        if self.max_sessions_per_replica is not None and (
            isinstance(self.max_sessions_per_replica, bool)
            or not isinstance(self.max_sessions_per_replica, int)
            or self.max_sessions_per_replica < 1
        ):
            raise ValueError("duplex_session.max_sessions_per_replica must be an integer >= 1 or null")
        if self.context_keep_media_turns is not None and (
            isinstance(self.context_keep_media_turns, bool)
            or not isinstance(self.context_keep_media_turns, int)
            or self.context_keep_media_turns < 0
        ):
            raise ValueError("duplex_session.context_keep_media_turns must be an integer >= 0 or null")
        if self.replica_policy == "least_sessions" and self.max_sessions_per_replica is None:
            raise ValueError("duplex_session.max_sessions_per_replica is required for replica_policy='least_sessions'")
        if self.replica_groups is not None:
            if not isinstance(self.replica_groups, list) or not self.replica_groups:
                raise ValueError("duplex_session.replica_groups must be a nonempty list of stage-to-replica mappings")
            for index, group in enumerate(self.replica_groups):
                if not isinstance(group, dict) or not group:
                    raise ValueError(
                        f"duplex_session.replica_groups[{index}] must be a nonempty stage-to-replica mapping"
                    )
                if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in group):
                    raise ValueError(f"duplex_session.replica_groups[{index}] stage IDs must be nonnegative integers")
                if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in group.values()):
                    raise ValueError(f"duplex_session.replica_groups[{index}] replica IDs must be nonnegative integers")
        positive = {
            "disconnect_grace_s": self.disconnect_grace_s,
            "reaper_interval_s": self.reaper_interval_s,
            "resume_replay_ttl_s": self.resume_replay_ttl_s,
            "resume_replay_max_bytes_per_session": self.resume_replay_max_bytes_per_session,
            "max_pending_input_bytes_per_session": self.max_pending_input_bytes_per_session,
            "max_pending_turns_per_session": self.max_pending_turns_per_session,
            "max_pending_output_bytes_per_session": self.max_pending_output_bytes_per_session,
            "max_pending_output_events_per_session": self.max_pending_output_events_per_session,
            "max_sessions": self.max_sessions,
            "max_tool_calls_per_session": self.max_tool_calls_per_session,
            "completed_append_cache_size": self.completed_append_cache_size,
            "history_calibration_timeout_ms": self.history_calibration_timeout_ms,
            "history_audio_max_bytes_per_session": self.history_audio_max_bytes_per_session,
            "history_asr_max_concurrency": self.history_asr_max_concurrency,
        }
        if self.idle_ttl_s is not None and self.idle_ttl_s <= 0:
            raise ValueError("duplex_session.idle_ttl_s must be positive or null")
        if self.history_asr_url is not None:
            from urllib.parse import urlsplit

            if not isinstance(self.history_asr_url, str):
                raise ValueError("duplex_session.history_asr_url must be a string")
            parsed = urlsplit(self.history_asr_url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
                raise ValueError("duplex_session.history_asr_url requires an HTTP(S) URL without credentials")
            if not isinstance(self.history_asr_model, str) or not self.history_asr_model.strip():
                raise ValueError("duplex_session.history_asr_model is required with history_asr_url")
        if self.history_ms_per_token is not None:
            rate = self.history_ms_per_token
            if isinstance(rate, bool) or not isinstance(rate, (int, float)) or not math.isfinite(rate) or rate <= 0:
                raise ValueError("duplex_session.history_ms_per_token must be finite and positive")
            if self.history_asr_url is not None:
                raise ValueError("Choose history_asr_url or history_ms_per_token, not both")
        for name in (
            "history_calibration_timeout_ms",
            "history_audio_max_bytes_per_session",
            "history_asr_max_concurrency",
        ):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise ValueError(f"duplex_session.{name} must be a positive integer")
        if self.server_vad_model_path is not None and (
            not isinstance(self.server_vad_model_path, str) or not self.server_vad_model_path.strip()
        ):
            raise ValueError("duplex_session.server_vad_model_path must be a non-empty string or null")
        if self.semantic_vad_model_path is not None and (
            not isinstance(self.semantic_vad_model_path, str) or not self.semantic_vad_model_path.strip()
        ):
            raise ValueError("duplex_session.semantic_vad_model_path must be a non-empty string or null")
        for name, value in positive.items():
            if value <= 0:
                raise ValueError(f"duplex_session.{name} must be positive")
        # A record budget is a count, not a measurement. ``True <= 0`` is False
        # and ``0.5 <= 0`` is False, so the positive check alone would let a
        # bool become a limit of one and a fraction become a silently truncated
        # one; ``nan`` would pass it too. Rejecting the shape here keeps the
        # ledger's ``int(max_calls)`` from inventing a budget nobody configured.
        budget = self.max_tool_calls_per_session
        if isinstance(budget, bool) or not isinstance(budget, int):
            raise ValueError("duplex_session.max_tool_calls_per_session must be an integer")

    @property
    def worker_max_sessions(self) -> int:
        """Model-owned state capacity of one worker replica."""
        if self.replica_policy == "least_sessions":
            assert self.max_sessions_per_replica is not None
            return self.max_sessions_per_replica
        return self.max_sessions


@dataclass
class DeployConfig:
    """Loaded from deploy/<model>.yaml — the only config file users edit.

    Top-level fields (``trust_remote_code``, ``distributed_executor_backend``,
    ``dtype``, ``quantization``, ``enable_prefix_caching``,
    ``enable_chunked_prefill``, ``data_parallel_size``,
    ``pipeline_parallel_size``) are pipeline-wide: they apply uniformly to
    every stage. Fields that legitimately vary per stage live in the
    individual ``StageDeployConfig`` entries under ``stages:``.
    """

    # Async chunk's default depends on whether or not the pipeline supports it.
    async_chunk: bool | None = None
    weight_sharing: WeightSharingConfig | None = None
    session_mode: str = "turn"
    model_runner: Literal["v1", "v2"] = "v1"
    # Stage-1 active stream slots; 0 preserves legacy all-stream cycling.
    active_stream_window: int = 0
    # Experimental local NVIDIA MPS; disabled unless a deploy explicitly opts in.
    cuda_mps: bool = False
    duplex_session: DuplexSessionRuntimeConfig = field(default_factory=DuplexSessionRuntimeConfig)
    speech_cache: SpeechCacheConfig = field(default_factory=SpeechCacheConfig)
    connectors: dict[str, Any] | None = None
    edges: list[dict[str, Any]] | None = None
    stages: list[StageDeployConfig] = field(default_factory=list)
    platforms: dict[str, Any] | None = None
    # Overrides the auto-detected pipeline registry key for structural variants.
    pipeline: str | None = None

    # === Pipeline-wide engine settings (applied uniformly to every stage) ===
    trust_remote_code: bool | None = None
    distributed_executor_backend: str | None = None
    dtype: str | None = None
    quantization: str | None = None
    enable_prefix_caching: bool | None = None
    enable_chunked_prefill: bool | None = None
    data_parallel_size: int | None = None
    pipeline_parallel_size: int | None = None
    custom_voice_dir: str | None = None
    weight_transfer_config: dict[str, Any] | None = None


_STAGE_RESERVED_KEYS = frozenset(
    {
        "async_chunk",
        "model_runner",
        "stage_id",
        "devices",
        "num_replicas",
        "env",
        "output_connectors",
        "input_connectors",
        "default_sampling_params",
        "default_pooling_params",
        "engine_extras",
        "engine_args",
        "runtime",
    }
)

# Pipeline-wide DeployConfig fields that are propagated to every stage's
# engine args during merge. These live at top level of the deploy YAML.
PIPELINE_WIDE_ENGINE_FIELDS: tuple[str, ...] = (
    "trust_remote_code",
    "distributed_executor_backend",
    "dtype",
    "quantization",
    "enable_prefix_caching",
    "enable_chunked_prefill",
    "data_parallel_size",
    "pipeline_parallel_size",
    "active_stream_window",
    "custom_voice_dir",
    "weight_transfer_config",
)


# Fields on StageDeployConfig that are populated from engine_args dict
_STAGE_DEPLOY_FIELDS = {f.name: f for f in fields(StageDeployConfig) if f.name not in _STAGE_RESERVED_KEYS}


def deploy_runtime_override_keys() -> frozenset[str]:
    """Return deploy-schema fields that are valid CLI/runtime overrides.

    These keys form the positive contract for stage override propagation:
    stage-scoped deploy knobs plus top-level pipeline-wide engine settings.
    They must remain overridable even if they are also modeled on
    ``OrchestratorArgs`` for top-level CLI parsing.
    """
    return frozenset(_STAGE_DEPLOY_FIELDS) | frozenset(PIPELINE_WIDE_ENGINE_FIELDS)


def _parse_stage_deploy(stage_data: dict[str, Any]) -> StageDeployConfig:
    """Parse a single stage entry from deploy YAML into StageDeployConfig."""
    # Get the non-reserved keys for this stage
    flat_args = {k: v for k, v in stage_data.items() if k not in _STAGE_RESERVED_KEYS}
    explicit_engine_extras = dict(stage_data.get("engine_extras") or {})
    runtime_cfg = dict(stage_data.get("runtime", {}))
    devices = runtime_cfg.get("devices", stage_data.get("devices"))
    num_replicas = runtime_cfg.get("num_replicas", stage_data.get("num_replicas", 1))
    env = runtime_cfg.get("env", stage_data.get("env"))

    if "engine_args" in stage_data:
        for k, v in stage_data["engine_args"].items():
            existing = flat_args.get(k)
            # If we have multiple dictionaries, merge recursively.
            if isinstance(v, dict) and isinstance(existing, dict):
                flat_args[k] = _get_recursively_merged_dict(existing, v)
            else:
                flat_args[k] = v

    stage_runner = stage_data.get("model_runner")
    if stage_runner is not None and stage_runner not in ("v1", "v2"):
        raise ValueError(f"stage {stage_data['stage_id']}: model_runner must be 'v1' or 'v2', got {stage_runner!r}")
    kwargs: dict[str, Any] = {
        "stage_id": stage_data["stage_id"],
        "devices": devices,
        "num_replicas": int(num_replicas),
        "env": env,
    }
    for name, f in _STAGE_DEPLOY_FIELDS.items():
        if name in flat_args:
            kwargs[name] = flat_args.pop(name)

    kwargs["async_chunk"] = stage_data.get("async_chunk")
    kwargs["model_runner"] = stage_runner
    kwargs["output_connectors"] = stage_data.get("output_connectors")
    kwargs["input_connectors"] = stage_data.get("input_connectors")
    kwargs["default_sampling_params"] = stage_data.get("default_sampling_params")
    kwargs["default_pooling_params"] = stage_data.get("default_pooling_params")
    kwargs["engine_extras"] = _get_recursively_merged_dict(explicit_engine_extras, flat_args)
    return StageDeployConfig(**kwargs)


_DEEP_MERGE_KEYS = frozenset(
    {
        "default_sampling_params",
        "default_pooling_params",
        "subtalker_sampling_params",
        "engine_extras",
        "engine_args",
    }
)


_DEPLOY_DEEP_MERGE_KEYS = frozenset({"speech_cache"})


def _merge_config_fields(base: dict, overlay: dict, *, deep_merge_keys: frozenset[str]) -> dict:
    """Recursively merge selected fields; overlay replaces all other fields."""
    base_nested = {k: v for k, v in base.items() if k in deep_merge_keys}
    overlay_nested = {k: v for k, v in overlay.items() if k in deep_merge_keys}
    merged_nested = _get_recursively_merged_dict(original=base_nested, update=overlay_nested)
    return {**base, **overlay, **merged_nested}


def _deep_merge_stage(base: dict, overlay: dict) -> dict:
    """Deep-merge ``_DEEP_MERGE_KEYS`` so thin overlays don't drop base keys."""
    return _merge_config_fields(base, overlay, deep_merge_keys=_DEEP_MERGE_KEYS)


def _get_recursively_merged_dict(original: dict, update: dict) -> dict:
    """Recursively merge two dicts, returning a new dict."""
    merged = original.copy()
    for k, update_v in update.items():
        orig_v = merged.get(k)
        if isinstance(orig_v, dict) and isinstance(update_v, dict):
            merged[k] = _get_recursively_merged_dict(orig_v, update_v)
        else:
            if orig_v is not None and (isinstance(orig_v, dict) != isinstance(update_v, dict)):
                logger.warning(
                    "Deep-merge key %r has non-dict value (base=%s, overlay=%s); "
                    "overlay will fully replace base instead of merging.",
                    k,
                    type(orig_v).__name__,
                    type(update_v).__name__,
                )

            merged[k] = update_v
    return merged


def _merge_stage_lists(
    base_stages: list[dict[str, Any]] | None,
    overlay_stages: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    """Merge two ``stages:`` lists by ``stage_id`` (overlay wins per field)."""
    by_id: dict[int, dict[str, Any]] = {s["stage_id"]: s for s in (base_stages or [])}
    for overlay_stage in overlay_stages or []:
        sid = overlay_stage["stage_id"]
        if sid in by_id:
            by_id[sid] = _deep_merge_stage(by_id[sid], overlay_stage)
        else:
            by_id[sid] = overlay_stage
    return list(by_id.values())


def _merge_platforms(
    base: dict[str, Any] | None,
    overlay: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Merge platform blocks by stage ID and named connector definition."""
    if not base and not overlay:
        return None
    base = base or {}
    overlay = overlay or {}
    merged: dict[str, Any] = {}
    for plat in set(base) | set(overlay):
        bp = base.get(plat) or {}
        op = overlay.get(plat) or {}
        merged_plat = {**bp, **{k: v for k, v in op.items() if k != "stages"}}
        merged_plat["stages"] = _merge_stage_lists(bp.get("stages"), op.get("stages"))
        connectors = _merge_connectors(bp.get("connectors"), op.get("connectors"))
        if connectors is not None:
            merged_plat["connectors"] = connectors
        merged[plat] = merged_plat
    return merged


def _merge_connectors(
    base: dict[str, Any] | None,
    overlay: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Deep-merge named connector definitions from a deploy overlay."""
    if not base and not overlay:
        return None
    return _get_recursively_merged_dict(base or {}, overlay or {})


def resolve_deploy_yaml(path: str | Path) -> dict[str, Any]:
    """Load a deploy YAML with optional ``base_config`` inheritance."""
    raw_dict = to_dict(load_yaml_config(path))

    base_path = raw_dict.pop("base_config", None)
    if base_path is None:
        return raw_dict

    # Resolve relative to the overlay file's directory
    base_path = Path(path).parent / base_path
    base_dict = resolve_deploy_yaml(base_path)

    # Merge top-level scalars: overlay wins. Structured sections are merged
    # below so a thin overlay does not discard inherited runtime contracts.
    merged = _merge_config_fields(
        base_dict,
        {k: v for k, v in raw_dict.items() if k not in ("connectors", "stages", "platforms")},
        deep_merge_keys=_DEPLOY_DEEP_MERGE_KEYS,
    )
    merged_connectors = _merge_connectors(base_dict.get("connectors"), raw_dict.get("connectors"))
    if merged_connectors is not None:
        merged["connectors"] = merged_connectors
    merged["stages"] = _merge_stage_lists(base_dict.get("stages"), raw_dict.get("stages"))
    merged_platforms = _merge_platforms(base_dict.get("platforms"), raw_dict.get("platforms"))
    if merged_platforms is not None:
        merged["platforms"] = merged_platforms

    return merged


def load_deploy_config(path: str | Path) -> DeployConfig:
    """Load a deploy YAML (with optional base_config inheritance)."""
    raw_dict = resolve_deploy_yaml(path)
    if "stage_args" in raw_dict:
        raise ValueError(
            f"Deploy config {path} uses the removed `stage_args` schema; "
            "define topology in PipelineConfig and deployment overrides under `stages`."
        )

    speech_cache = raw_dict.get("speech_cache", {})
    if not isinstance(speech_cache, dict):
        raise ValueError("speech_cache must be a mapping")
    stages = [_parse_stage_deploy(s) for s in raw_dict.get("stages", [])]

    model_runner = raw_dict.get("model_runner", "v1")
    if model_runner not in ("v1", "v2"):
        raise ValueError(f"model_runner must be one of ('v1', 'v2'), got {model_runner!r}")

    if not isinstance(raw_dict.get("cuda_mps", False), bool):
        raise ValueError("cuda_mps must be a boolean")

    # TODO (Alex): Clean this up, we should not have fallback values here
    kwargs: dict[str, Any] = {
        "speech_cache": SpeechCacheConfig(**speech_cache),
        "weight_sharing": parse_weight_sharing(raw_dict.get("weight_sharing")),
        "cuda_mps": raw_dict.get("cuda_mps", False),
        "async_chunk": raw_dict.get("async_chunk"),
        "session_mode": raw_dict.get("session_mode", "turn"),
        "model_runner": model_runner,
        "duplex_session": DuplexSessionRuntimeConfig(**(raw_dict.get("duplex_session") or {})),
        "connectors": raw_dict.get("connectors", None),
        "edges": raw_dict.get("edges", None),
        "stages": stages,
        "platforms": raw_dict.get("platforms", None),
        "pipeline": raw_dict.get("pipeline", None),
    }
    # Pipeline-wide engine settings: only set if explicitly present in YAML
    # so the DeployConfig dataclass defaults take effect otherwise.
    for name in PIPELINE_WIDE_ENGINE_FIELDS:
        if name in raw_dict:
            value = raw_dict[name]
            # NOTE: This is arguably bad behavior since it's a one-off for
            # only this field. We should consider deprecating this coercion.
            if name == "active_stream_window":
                value = int(value or 0)
            kwargs[name] = value
    return DeployConfig(**kwargs)


class PlatformOverrides(NamedTuple):
    overrides: dict[str, Any]
    devices: str | None
    env: dict[str, Any] | None


def _extract_platform_overrides(ps: dict[str, Any]) -> PlatformOverrides:
    """Return overrides, devices, and env from a platform stage entry.

    Handles both the nested layout (``engine_args:`` / ``runtime.devices``) and
    the flat layout. ``devices`` is ``None`` when no override is set.
    """
    if "engine_args" in ps:
        overrides = dict(ps["engine_args"])
        runtime_cfg = ps.get("runtime", {})
        if "num_replicas" in runtime_cfg:
            overrides["num_replicas"] = runtime_cfg["num_replicas"]
        return PlatformOverrides(overrides, runtime_cfg.get("devices"), runtime_cfg.get("env"))
    overrides = {k: v for k, v in ps.items() if k not in ("stage_id", "devices", "env")}
    return PlatformOverrides(overrides, ps.get("devices"), ps.get("env"))


# Why a platform still rejects Model Runner V2. CUDA API aliases alone do not
# adapt a platform worker, so an entry is removed only with the real integration.
# NPU AR stages use the Ascend V2 runner (attention metadata and input state).
# Platforms whose workers still force the V1 runner; XPU and NPU build the omni V2 runners.
_MRV2_UNSUPPORTED_PLATFORMS: dict[str, str] = {}


def _apply_platform_overrides(
    deploy: DeployConfig,
    platform: str | None = None,
) -> DeployConfig:
    """Merge platform-specific runner and stage overrides into deploy config."""
    if platform is None:
        from vllm_omni.platforms import current_omni_platform

        device_name = current_omni_platform.device_name
        platform = device_name.lower() if device_name is not None else None
    platform_section = (deploy.platforms or {}).get(platform) if platform is not None else None
    if platform_section is not None and "connectors" in platform_section:
        deploy.connectors = _merge_connectors(deploy.connectors, platform_section["connectors"])
    if platform_section is not None and "cuda_mps" in platform_section:
        cuda_mps = platform_section["cuda_mps"]
        if not isinstance(cuda_mps, bool):
            raise ValueError("platform cuda_mps must be a boolean")
        deploy.cuda_mps = cuda_mps
    if platform_section is not None and "model_runner" in platform_section:
        model_runner = platform_section["model_runner"]
        if model_runner not in ("v1", "v2"):
            raise ValueError(f"platform model_runner must be one of ('v1', 'v2'), got {model_runner!r}")
        deploy.model_runner = model_runner
        if model_runner == "v1":
            # A platform's V1 fallback also covers stages that opt into V2.
            for stage in deploy.stages:
                if stage.model_runner == "v2":
                    stage.model_runner = None
    platform_stages = platform_section.get("stages", []) if platform_section else []
    base_by_id = {s.stage_id: s for s in deploy.stages}

    for ps in platform_stages:
        base = base_by_id.get(ps["stage_id"])
        if base is None:
            continue
        po = _extract_platform_overrides(ps)
        if po.devices is not None:
            base.devices = po.devices
        if po.env is not None:
            if isinstance(base.env, dict) and isinstance(po.env, dict):
                base.env = {**base.env, **po.env}
            else:
                logger.warning(
                    "Stage %s env override replaces base env entirely (base type=%s, override type=%s)",
                    ps["stage_id"],
                    type(base.env).__name__,
                    type(po.env).__name__,
                )
                base.env = po.env
        # Remove base legacy values before merging the entire overlay. Nested
        # extras in the overlay must still be checked regardless of key order.
        for key in ("attention_backend", "moe_backend", "linear_backend"):
            if key in po.overrides:
                base.engine_extras.pop(key, None)
        for key, val in po.overrides.items():
            if hasattr(base, key):
                # Deep-merge dict-valued fields listed in _DEEP_MERGE_KEYS so
                # platform overlays don't silently clobber sibling keys (e.g.
                # setting default_sampling_params={max_tokens: 2048} must not
                # drop temperature / top_p / top_k from the base stage).
                if key in _DEEP_MERGE_KEYS and isinstance(val, dict):
                    base_val = getattr(base, key, None)
                    if isinstance(base_val, dict):
                        setattr(base, key, _get_recursively_merged_dict(base_val, val))
                        continue
                setattr(base, key, val)
            else:
                base.engine_extras[key] = val
        # Platform overlays run after construction and can reintroduce nested
        # backend extras. Reapply normalization and first-class precedence.
        _normalize_stage_backend_fields(base)

    # Validate the final values, including stage entries from the platform
    # overlay. A global V2 default may still apply to omitted pipeline stages.
    for stage in deploy.stages:
        if stage.model_runner is not None and stage.model_runner not in ("v1", "v2"):
            raise ValueError(f"stage {stage.stage_id}: model_runner must be 'v1' or 'v2', got {stage.model_runner!r}")
    uses_v2 = deploy.model_runner == "v2" or any(stage.model_runner == "v2" for stage in deploy.stages)
    if uses_v2 and platform is not None:
        reason = _MRV2_UNSUPPORTED_PLATFORMS.get(platform)
        if reason is not None:
            raise NotImplementedError(f"Model Runner V2 is not supported on {platform.upper()}: {reason}.")

    return deploy


_EXECUTION_TYPE_TO_STAGE_WORKER: dict[StageExecutionType, tuple[StageType, str | None]] = {
    StageExecutionType.LLM_AR: (StageType.LLM, "ar"),
    StageExecutionType.LLM_GENERATION: (StageType.LLM, "generation"),
    StageExecutionType.DIFFUSION: (StageType.DIFFUSION, None),
}


def _resolve_execution_mode(
    execution_type: StageExecutionType,
) -> tuple[StageType, str | None]:
    """Map ``execution_type`` → ``(stage_type, worker_type)`` legacy tuple."""
    return _EXECUTION_TYPE_TO_STAGE_WORKER.get(execution_type, (StageType.LLM, None))


def resolve_stage_model_runner(deploy: DeployConfig, stage: StageDeployConfig | None) -> str:
    """The stage's own ``model_runner`` if set, else the deploy-level one."""
    runner = getattr(stage, "model_runner", None) if stage is not None else None
    return runner or deploy.model_runner


def validate_native_mrv2_session(deploy: DeployConfig, ps: StagePipelineConfig, stage_runner: str) -> None:
    """Reject session modes a downstream MRv2 native-data-plane stage lacks.

    Streaming-session prompt replacement exists only in the V1 chunk adapter,
    so a stage that receives from an upstream stage on MRv2 supports
    turn-based sessions only unless it explicitly declares supports_duplex_mrv2.
    """
    if stage_runner != "v2" or not ps.supports_native_mrv2_data_plane or not ps.input_sources:
        return
    if deploy.session_mode == "duplex" and ps.supports_duplex_mrv2:
        return
    if deploy.session_mode != "turn":
        raise ValueError(
            f"stage {ps.stage_id}: model_runner v2 supports session_mode 'turn' only, got "
            f"{deploy.session_mode!r}; run this stage with model_runner: v1 for streaming sessions."
        )


def resolve_stage_async_chunk(deploy: DeployConfig, stage: StageDeployConfig | None) -> bool:
    if not isinstance(deploy.async_chunk, bool):
        raise ValueError("async_chunk must be a boolean")
    if stage is not None and stage.async_chunk is not None and not isinstance(stage.async_chunk, bool):
        raise ValueError(f"Stage {stage.stage_id} async_chunk must be a boolean or null")
    return deploy.async_chunk and (stage is None or stage.async_chunk is not False)


def _select_processor_funcs(
    ps: StagePipelineConfig,
    async_chunk: bool,
) -> tuple[str | None, str | None]:
    """Pick ``(input_proc, next_stage_proc)`` based on the async_chunk mode."""
    next_stage_proc = ps.custom_process_next_stage_input_func
    input_proc = ps.custom_process_input_func
    if async_chunk and ps.async_chunk_process_next_stage_input_func:
        next_stage_proc = ps.async_chunk_process_next_stage_input_func
    elif not async_chunk and ps.sync_process_input_func:
        input_proc = ps.sync_process_input_func
    return input_proc, next_stage_proc


def _build_engine_args(
    ps: StagePipelineConfig,
    ds: StageDeployConfig | None,
    pipeline: PipelineConfig,
    deploy: DeployConfig,
    next_stage_proc: str | None,
) -> dict[str, Any]:
    """Assemble the flat ``yaml_engine_args`` dict for one stage.

    Pipeline-wide DeployConfig fields are applied uniformly to every stage;
    per-stage StageDeployConfig overrides take precedence when present (e.g.
    ``engine_extras`` can still carry a stage-specific ``dtype``).
    """
    engine_args: dict[str, Any] = {"model_arch": ps.model_arch or pipeline.model_arch or None}
    engine_args["retains_state_across_chunks"] = ps.retains_state_across_chunks
    if ps.supports_pending_generation:
        engine_args["supports_pending_generation"] = True
    if ps.execution_type == StageExecutionType.DIFFUSION and ps.model_arch:
        engine_args.setdefault("model_class_name", ps.model_arch)
    if ps.engine_output_type is not None:
        engine_args["engine_output_type"] = ps.engine_output_type
    if next_stage_proc:
        engine_args["custom_process_next_stage_input_func"] = next_stage_proc
    # Subdirectory indirections from StagePipelineConfig (structural, not
    # deployment knobs).  Deploy YAML ``engine_extras`` can still override
    # these per-stage if needed.
    if ps.model_subdir:
        engine_args["model_subdir"] = ps.model_subdir
    if ps.tokenizer_subdir:
        engine_args["tokenizer_subdir"] = ps.tokenizer_subdir
    if ps.model_path_resolver:
        engine_args["model_path_resolver"] = ps.model_path_resolver
    engine_args["inline_diffusion"] = ps.inline_diffusion
    if ps.stage_input_payload_keys:
        engine_args["stage_input_payload_keys"] = tuple(ps.stage_input_payload_keys)
    if ps.stage_input_optional_payload_keys:
        engine_args["stage_input_optional_payload_keys"] = tuple(ps.stage_input_optional_payload_keys)
    if ps.stage_output_payload_keys:
        engine_args["stage_output_payload_keys"] = tuple(ps.stage_output_payload_keys)

    # Pipeline-wide top-level DeployConfig settings, applied to every stage.
    for name in PIPELINE_WIDE_ENGINE_FIELDS:
        value = getattr(deploy, name)
        if value is not None:
            engine_args[name] = value

    # Per-stage StageDeployConfig values override pipeline-wide settings.
    if ds is not None:
        for k, v in asdict(ds).items():
            if k in _STAGE_RESERVED_KEYS or v is None:
                continue
            engine_args[k] = v
        engine_args.update(ds.engine_extras)
    engine_args["async_chunk"] = resolve_stage_async_chunk(deploy, ds)
    engine_args["session_mode"] = deploy.session_mode
    if deploy.session_mode == "duplex":
        # Session placement caps model-owned state per replica. Legacy deploys
        # retain the global admission limit as their worker capacity.
        engine_args["duplex_max_sessions"] = deploy.duplex_session.worker_max_sessions
    # The runner selection is a deploy-topology decision owned by the
    # ``model_runner`` field; do not let an opaque ``engine_extras`` entry
    # silently veto or force it per stage.
    if ds is not None:
        for reserved in ("use_v2_model_runner", "supports_native_mrv2_data_plane"):
            if reserved in ds.engine_extras:
                raise ValueError(
                    f"stage {ds.stage_id}: {reserved!r} must not be set via engine_extras; "
                    "it is derived from the deploy-level `model_runner` field and the "
                    "pipeline's `supports_native_mrv2_data_plane` declaration."
                )
    stage_runner = resolve_stage_model_runner(deploy, ds)
    validate_native_mrv2_session(deploy, ps, stage_runner)
    engine_args["use_v2_model_runner"] = stage_runner == "v2"
    engine_args["supports_native_mrv2_data_plane"] = bool(ps.supports_native_mrv2_data_plane)
    if stage_runner == "v2" and not ps.supports_native_mrv2_data_plane:
        logger.warning(
            "Stage %s (%s) selects model_runner=v2 without declaring "
            "supports_native_mrv2_data_plane. It will use the legacy transport path; "
            "MRV2 support for this pipeline has not been validated. Use model_runner=v1 "
            "unless you are validating a new MRV2 integration.",
            ps.stage_id,
            ps.model_arch or pipeline.model_arch or pipeline.model_type,
        )
    if ps.omni_kv_config:
        engine_args["omni_kv_config"] = dict(ps.omni_kv_config)
    engine_args["requires_full_payload_input"] = ps.requires_full_payload_input
    if not ps.supports_running_prefix_cache_reset:
        engine_args["supports_running_prefix_cache_reset"] = False
    if ps.execution_type is StageExecutionType.LLM_AR and ps.recompute_preemption != "allow":
        engine_args["recompute_preemption"] = ps.recompute_preemption
    engine_args["scheduling_metadata_adapter"] = ps.scheduling_metadata_adapter
    return engine_args


def merge_sampling_constraints(
    sampling_params: Mapping[str, Any] | None,
    constraints: Mapping[str, Any],
) -> dict[str, Any]:
    """Apply scalar constraints and extend stop tokens without mutating inputs."""
    resolved_constraints = dict(constraints)
    if "stop_token_ids" in resolved_constraints:
        caller_stop_ids = (sampling_params or {}).get("stop_token_ids") or []
        required_stop_ids = resolved_constraints["stop_token_ids"] or []
        resolved_constraints["stop_token_ids"] = list(dict.fromkeys([*caller_stop_ids, *required_stop_ids]))
    return {**(sampling_params or {}), **resolved_constraints}


def _build_extras(
    ps: StagePipelineConfig,
    ds: StageDeployConfig | None,
) -> dict[str, Any]:
    """Assemble ``yaml_extras`` (sampling + connectors + pipeline extras)."""
    extras: dict[str, Any] = {}
    sampling = merge_sampling_constraints(
        ds.default_sampling_params if ds is not None else None,
        ps.sampling_constraints,
    )
    if sampling:
        extras["default_sampling_params"] = sampling
    if ds is not None and ds.default_pooling_params:
        extras["default_pooling_params"] = dict(ds.default_pooling_params)
    if ds is not None and ds.output_connectors:
        extras["output_connectors"] = dict(ds.output_connectors)
    if ds is not None and ds.input_connectors:
        extras["input_connectors"] = dict(ds.input_connectors)
    if ps.prompt_transform_func:
        extras["prompt_transform_func"] = ps.prompt_transform_func
    if ps.prompt_expand_func:
        extras["prompt_expand_func"] = ps.prompt_expand_func
    if ps.cfg_kv_collect_func:
        extras["cfg_kv_collect_func"] = ps.cfg_kv_collect_func
    if ps.async_chunk_prewarm_payload_func:
        extras["async_chunk_prewarm_payload_func"] = ps.async_chunk_prewarm_payload_func
    if ps.extras:
        extras.update(ps.extras)
    return extras


def update_deploy_config_async_chunk_enabled(
    pipeline: PipelineConfig,
    deploy: DeployConfig,
) -> None:
    """Set the pipeline wide async chunk value & validate it."""
    deploy.async_chunk = _resolve_pipeline_async_chunk_enabled(pipeline, deploy)
    validate_stage_async_chunk_edges(pipeline, deploy)


def _resolve_pipeline_async_chunk_enabled(
    pipeline: PipelineConfig,
    deploy: DeployConfig,
) -> bool:
    """Given the pipeline config and deploy config, determine the value of async_chunk.
    Note that this currently assumes the cli override has been externally handled.

    The default is True if the model actually supports async chunk and is multistage,
    and False otherwise. If the user tried to enable async chunk through the deploy
    config, but it's inapplicable or unsupported, it will be disabled with a warning.
    """
    if len(pipeline.stages) <= 1:
        if pipeline.single_stage_async_chunk:
            if deploy.async_chunk is False:
                raise ValueError(f"Pipeline {pipeline.model_type!r} requires async_chunk=True")
            return True
        if deploy.async_chunk:
            logger.warning(
                "Deploy config set async_chunk=True, but async chunk is inapplicable "
                "to single stage models. As such, it will be disabled."
            )
        return False

    has_inter_stage_edges = any(stage.input_sources for stage in pipeline.stages)
    has_next_stage_inps = any(stage.async_chunk_process_next_stage_input_func for stage in pipeline.stages)
    has_kv_transfer_cfg = any(stage.engine_extras.get("kv_transfer_config") for stage in deploy.stages)
    supports_async_chunk = has_inter_stage_edges and has_next_stage_inps

    # If async chunk was set, make sure it's supported if
    # requested; otherwise warn and disable it.
    if deploy.async_chunk is not None:
        if deploy.async_chunk:
            if not supports_async_chunk:
                logger.warning(
                    "Deploy config set async_chunk=True, but the pipeline config does not support it; disabling it."
                )
                return False
            if has_kv_transfer_cfg:
                logger.warning("Native AR-to-DiT KV transfer requires async_chunk=False; async chunk will be disabled.")
                return False
        return deploy.async_chunk

    return supports_async_chunk and not has_kv_transfer_cfg


def validate_stage_async_chunk_edges(pipeline: PipelineConfig, deploy: DeployConfig) -> None:
    stages = {stage.stage_id: stage for stage in pipeline.stages}
    deploy_by_id = {stage.stage_id: stage for stage in deploy.stages}
    for consumer in pipeline.stages:
        for source_id in consumer.input_sources:
            producer = stages[source_id]
            if not producer.async_chunk_process_next_stage_input_func:
                continue
            producer_async = resolve_stage_async_chunk(deploy, deploy_by_id.get(source_id))
            consumer_async = resolve_stage_async_chunk(deploy, deploy_by_id.get(consumer.stage_id))
            if producer_async != consumer_async:
                raise ValueError(
                    f"Pipeline {pipeline.model_type!r} has incompatible async_chunk settings on "
                    f"connector edge {source_id} -> {consumer.stage_id}. "
                    "Set the same async_chunk mode on both stages or disable pipeline-wide async_chunk."
                )


def merge_pipeline_deploy(
    pipeline: PipelineConfig,
    deploy: DeployConfig,
) -> list[StageConfig]:
    """Merge pipeline + deploy + platform overrides → list[StageConfig]."""
    deploy = _apply_platform_overrides(deploy)
    deploy_by_id = {s.stage_id: s for s in deploy.stages}

    # NOTE: The CLI override is applied to the Deployconfig for async chunk prior
    # to this point. We are in the process of better organizing the creation of the
    # DeployConfig/PipelineConfig, and this path will be removed with the incorporation
    # of the OmniConfig.
    update_deploy_config_async_chunk_enabled(pipeline, deploy)

    result: list[StageConfig] = []
    for ps in pipeline.stages:
        ds = deploy_by_id.get(ps.stage_id)
        stage_type, worker_type = _resolve_execution_mode(ps.execution_type)
        stage_async_chunk = resolve_stage_async_chunk(deploy, ds)
        input_proc, next_stage_proc = _select_processor_funcs(ps, stage_async_chunk)
        engine_args = _build_engine_args(ps, ds, pipeline, deploy, next_stage_proc)
        # Downstream stages may share a multimodal wrapper class without owning
        # an encoder. Do not make vLLM profile dummy multimodal inputs for them.
        if not ps.requires_multimodal_data:
            engine_args.setdefault("skip_mm_profiling", True)
        sched_cls = _resolve_scheduler(
            ps.execution_type,
            engine_args.get("async_scheduling", True),
        )
        if ps.execution_type == StageExecutionType.LLM_AR:
            engine_args["async_scheduling"] = sched_cls is OmniARAsyncScheduler
        extras = _build_extras(ps, ds)
        runtime: dict[str, Any] = {"process": True}
        if ds is not None:
            if ds.devices is not None:
                runtime["devices"] = ds.devices
            runtime["num_replicas"] = ds.num_replicas
            if ds.env is not None:
                runtime["env"] = ds.env
        if deploy.cuda_mps:
            runtime["cuda_mps"] = True
        runtime["requires_multimodal_data"] = ps.requires_multimodal_data

        result.append(
            StageConfig(
                stage_id=ps.stage_id,
                model_stage=ps.model_stage,
                stage_role=ps.stage_role.value if ps.stage_role is not None else None,
                session_mode=deploy.session_mode,
                stage_type=stage_type,
                input_sources=list(ps.input_sources),
                custom_process_input_func=input_proc,
                final_output=ps.final_output,
                final_output_type=ps.final_output_type,
                worker_type=worker_type,
                scheduler_cls=ps.scheduler_cls or _scheduler_path(sched_cls),
                hf_config_name=ps.hf_config_name,
                is_comprehension=ps.owns_tokenizer,
                sampling_constraints=dict(ps.sampling_constraints),
                yaml_engine_args=engine_args,
                yaml_runtime=runtime,
                yaml_extras=extras,
            )
        )
    return result


@dataclass
class StageConfig:
    """Per-stage config (legacy path). Used by both new and legacy loaders.

    TODO(@lishunyang12): replace with ResolvedStageConfig once all models are migrated.
    """

    stage_id: int
    model_stage: str
    stage_role: str | None = None
    session_mode: str = "turn"
    stage_type: StageType = StageType.LLM
    input_sources: list[int] = field(default_factory=list)
    custom_process_input_func: str | None = None
    final_output: bool = False
    final_output_type: str | None = None
    worker_type: str | None = None
    scheduler_cls: str | None = None
    hf_config_name: str | None = None
    is_comprehension: bool = False
    sampling_constraints: dict[str, Any] = field(default_factory=dict)
    yaml_engine_args: dict[str, Any] = field(default_factory=dict)
    yaml_runtime: dict[str, Any] = field(default_factory=dict)
    yaml_extras: dict[str, Any] = field(default_factory=dict)
    runtime_overrides: dict[str, Any] = field(default_factory=dict)

    def to_omegaconf(self) -> Any:
        """TODO(@lishunyang12): remove once engine consumes ResolvedStageConfig directly."""
        # Start with YAML engine_args defaults
        engine_args: dict[str, Any] = dict(self.yaml_engine_args)
        runtime_overrides = dict(self.runtime_overrides)

        # Overlay topology-level fields
        engine_args["model_stage"] = self.model_stage
        # Diffusion disaggregation stage role (see DiffusionStageRole). Only
        # surfaced when set so non-diffusion stages are unaffected; the payload
        # key schema rides along in ``yaml_engine_args``.
        if self.stage_role is not None:
            engine_args["stage_role"] = self.stage_role
        if self.worker_type:
            engine_args["worker_type"] = self.worker_type
        if self.scheduler_cls:
            engine_args["scheduler_cls"] = self.scheduler_cls
        if self.hf_config_name:
            engine_args["hf_config_name"] = self.hf_config_name

        if StageType(self.stage_type) == StageType.DIFFUSION:
            _apply_diffusion_parallel_runtime_overrides(engine_args, runtime_overrides)
            reconcile_diffusion_attention_overrides(engine_args, runtime_overrides)

        # CLI overrides take precedence over YAML defaults. Most dict-valued
        # overrides are deep-merged so a partial CLI dict (e.g. --no-guardrails
        # riding on ``model_config``) layers onto the deploy YAML instead of
        # clobbering sibling keys such as ``policy_server_config`` — the same
        # rationale as the platform-overlay deep-merge. Legacy atomic mappings
        # are handled explicitly below.
        for key, value in runtime_overrides.items():
            if value is None or key in _RUNTIME_ONLY_OVERRIDE_FIELDS:
                continue
            if key in _TOPOLOGY_OWNED_ENGINE_FIELDS:
                logger.warning(
                    "Stage %s: ignoring runtime override for topology-owned field '%s'; keeping the pipeline value.",
                    self.stage_id,
                    key,
                )
                continue
            existing = engine_args.get(key)
            # ``omni_kv_config`` is an atomic legacy override: callers use
            # a partial mapping to replace the topology-provided transfer
            # role, rather than to add fields to it.
            if key != "omni_kv_config" and isinstance(existing, dict) and isinstance(value, dict):
                engine_args[key] = _get_recursively_merged_dict(existing, value)
            else:
                engine_args[key] = value

        # Terminal-stage ownership comes from topology, not engine overrides.
        engine_args["final_output"] = self.final_output
        if self.yaml_engine_args.get("supports_running_prefix_cache_reset") is False:
            engine_args["supports_running_prefix_cache_reset"] = False

        # Build runtime config from YAML defaults + CLI overrides
        runtime: dict[str, Any] = dict(self.yaml_runtime)
        runtime.setdefault("process", True)
        if runtime_overrides.get("devices") is not None:
            runtime["devices"] = runtime_overrides["devices"]
        if runtime_overrides.get("num_replicas") is not None:
            runtime["num_replicas"] = runtime_overrides["num_replicas"]

        # Legacy compat: migrate runtime.max_batch_size → engine_args.max_num_seqs
        legacy_mbs = runtime.pop("max_batch_size", None)
        cli_mbs = runtime_overrides.get("max_batch_size")
        if legacy_mbs is not None or cli_mbs is not None:
            warnings.warn(
                "runtime.max_batch_size is deprecated and will be removed in a "
                "future release. Use engine_args.max_num_seqs instead.",
                FutureWarning,
                stacklevel=2,
            )
            effective_mbs = int(cli_mbs or legacy_mbs or 1)
            engine_args.setdefault("max_num_seqs", effective_mbs)

        # Build full config dict
        config_dict: dict[str, Any] = {
            "stage_id": self.stage_id,
            "stage_type": StageType(self.stage_type).value,
            "session_mode": self.session_mode,
            "engine_args": create_config(engine_args),
            "runtime": create_config(runtime),
            "engine_input_source": self.input_sources,  # Legacy field name
            "final_output": self.final_output,
            "final_output_type": self.final_output_type,
            "is_comprehension": self.is_comprehension,
            "sampling_constraints": dict(self.sampling_constraints),
        }

        if self.custom_process_input_func:
            config_dict["custom_process_input_func"] = self.custom_process_input_func

        # Pass through extra YAML fields (default_sampling_params,
        # output_connectors, input_connectors, tts_args, etc.)
        config_dict.update(self.yaml_extras)

        return create_config(config_dict)
