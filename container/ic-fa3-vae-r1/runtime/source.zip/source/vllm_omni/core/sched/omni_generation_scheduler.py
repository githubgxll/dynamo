# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

from __future__ import annotations

import math
import queue
import time
from collections import defaultdict
from typing import TYPE_CHECKING, Any

import torch
from vllm.compilation.cuda_graph import CUDAGraphStat
from vllm.logger import init_logger
from vllm.v1.core.kv_cache_manager import KVCacheBlocks
from vllm.v1.core.sched.interface import PauseState
from vllm.v1.core.sched.output import KVConnectorBlockState, SchedulerOutput
from vllm.v1.core.sched.request_queue import create_request_queue
from vllm.v1.core.sched.scheduler import Scheduler as VLLMScheduler
from vllm.v1.core.sched.utils import remove_all
from vllm.v1.engine import EngineCoreEventType, EngineCoreOutput, EngineCoreOutputs
from vllm.v1.metrics.perf import PerfStats
from vllm.v1.request import Request, RequestStatus, StreamingUpdate
from vllm.v1.spec_decode.metrics import SpecDecodingStats

from vllm_omni.core.sched.duplex_stage_work import perf_chunk_from_buffer, set_request_perf_chunk
from vllm_omni.core.sched.omni_scheduler_mixin import OmniSchedulerMixin
from vllm_omni.core.sched.output import OmniCachedRequestData, OmniNewRequestData
from vllm_omni.engine.serialization import deserialize_additional_information
from vllm_omni.outputs import OmniModelRunnerOutput

if TYPE_CHECKING:
    from vllm.v1.core.sched.request_queue import RequestQueue


logger = init_logger(__name__)


def _has_async_chunk_payload_to_run(request: Request) -> bool:
    additional_information = getattr(request, "additional_information", None)
    if not isinstance(additional_information, dict):
        additional_information = deserialize_additional_information(additional_information)

    codes = additional_information.get("codes")
    audio = codes.get("audio") if isinstance(codes, dict) else additional_information.get("codes.audio")
    if audio is None:
        return False
    if hasattr(audio, "numel"):
        return bool(audio.numel())
    return bool(audio)


class OmniGenerationScheduler(OmniSchedulerMixin, VLLMScheduler):
    waiting: RequestQueue

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        model_config = self.vllm_config.model_config
        self._init_omni_io_scheduling_state()
        self._retains_state_across_chunks = bool(getattr(model_config, "retains_state_across_chunks", False))
        self._supports_pending_generation = bool(getattr(model_config, "supports_pending_generation", False))
        self._pending_finish_reqs: list[Request] = []
        self._pending_chunk_error_outputs: list[tuple[int, EngineCoreOutput]] = []
        connector_config = getattr(model_config, "stage_connector_config", None)
        extra = (
            connector_config.get("extra", connector_config)
            if isinstance(connector_config, dict)
            else getattr(connector_config, "extra", None)
        ) or {}
        self._generation_min_batch_size = int(extra.get("generation_min_batch_size", 1))
        self._generation_max_wait_s = float(extra.get("generation_max_wait_ms", 0)) / 1000
        self._generation_coalescing_policy = extra.get("generation_coalescing_policy", "fixed")
        self._generation_max_regular_batch = int(extra.get("generation_max_regular_batch", 0) or 0)
        if self._generation_max_regular_batch < 0:
            raise ValueError("generation_max_regular_batch must be nonnegative")
        if self._generation_coalescing_policy not in ("fixed", "idle_wait"):
            raise ValueError("generation_coalescing_policy must be fixed or idle_wait")
        if not 1 <= self._generation_min_batch_size <= self.max_num_running_reqs:
            raise ValueError("generation_min_batch_size must be in [1, max_num_seqs]")
        if not math.isfinite(self._generation_max_wait_s) or self._generation_max_wait_s < 0:
            raise ValueError("generation_max_wait_ms must be finite and nonnegative")
        if self._generation_max_wait_s and self._generation_min_batch_size > 1:
            parallel = self.vllm_config.parallel_config
            if not self._native_data_plane:
                # CUDA-oriented profiles can inherit a platform's V1 runner.
                # Their connector extras survive that override, but batching
                # must revert to the fallback runner's default scheduling.
                logger.warning(
                    "Generation batch waiting and regular-batch limit ignored: "
                    "requires native MRV2; using default generation scheduling."
                )
                self._generation_min_batch_size = 1
                self._generation_max_wait_s = 0.0
                self._generation_max_regular_batch = 0
            elif not (
                self._retains_state_across_chunks
                and parallel.tensor_parallel_size == parallel.pipeline_parallel_size == 1
            ):
                raise ValueError("Generation batch waiting requires a stateful native MRV2 TP1/PP1 stage")
            else:
                logger.info(
                    "Generation input coalescing: target batch=%d, max wait=%.3f ms",
                    self._generation_min_batch_size,
                    self._generation_max_wait_s * 1000,
                )
        self._first_chunk_express = bool(extra.get("generation_first_chunk_express", False))
        self._last_step_express = False
        # Streams that already had a chunk scheduled; the rest await their first.
        self._chunk_started: set[str] = set()
        # Optional guard: take an express step only while every ready later
        # chunk's stream still holds at least this much unplayed audio, so a
        # loaded stage does not trade first packets for playback underruns.
        # Playback is assumed to start with a stream's first emitted audio.
        self._express_min_slack_s = float(extra.get("generation_first_chunk_express_min_slack_s", 0.0))
        # request id -> [monotonic time of first emitted audio, emitted seconds]
        self._stream_audio: dict[str, list[float]] = {}
        self._express_skipped_for_slack = 0
        if self._first_chunk_express:
            logger.info(
                "Generation scheduler decodes first chunks in express steps (min continuation slack %.2f s)",
                self._express_min_slack_s,
            )

    def _requires_atomic_chunk(self) -> bool:
        adapter = self.chunk_transfer_adapter
        if adapter is not None:
            return adapter.receives_chunks

        coordinator = self.input_coordinator
        # Native receivers have no legacy adapter. A stage-0 coordinator is
        # bookkeeping only, and full-payload coordinators do not receive chunks.
        return self._native_data_plane and coordinator is not None and coordinator.receives_chunks

    def _reject_oversized_ready_chunks(self) -> None:
        if not self._requires_atomic_chunk():
            return

        adapter = self.chunk_transfer_adapter
        owner = adapter if adapter is not None else self.input_coordinator
        assert owner is not None  # An async-chunk receiver owns readiness.
        ready_request_ids = owner.requests_with_ready_chunks
        full_budget = self.max_num_scheduled_tokens

        # finish_requests() mutates the queues; iterate a de-duplicated
        # snapshot covering both waiting queues and running follow-ups.
        candidates = {req.request_id: req for req in [*self.waiting, *self.kv_holding_waiting, *self.running]}
        rejected_reasons: dict[str, str] = {}
        for req_id, request in candidates.items():
            if req_id not in self.requests or request.is_finished():
                continue
            if req_id not in ready_request_ids:
                # Only inspect chunks already handed to the scheduler thread;
                # requests whose chunk has not arrived (or stale placeholders)
                # are not new chunks and must not be rejected.
                continue
            if self._native_data_plane and request.num_in_flight_tokens > 0:
                # Let the previous execution emit its valid output before
                # terminal cleanup. Readiness survives until the fence clears.
                continue

            # For 1-D codec inputs, both receive paths replace
            # prompt_token_ids and reset num_computed_tokens to zero,
            # so len(...) is the full chunk's scheduling length.
            full_chunk_tokens = len(request.prompt_token_ids)
            if full_chunk_tokens <= full_budget:
                continue

            reason = f"async chunk requires {full_chunk_tokens} tokens, but max_num_scheduled_tokens is {full_budget}"
            logger.error("Rejecting async chunk for %s: %s", req_id, reason)
            request.stop_reason = reason
            rejected_reasons[req_id] = reason

        if not rejected_reasons:
            return

        # Batch cleanup avoids repeatedly scanning queues for many bad requests.
        # Keep the existing finish path: it reconciles queue status and handles
        # connector cleanup, finished IDs and deferred KV-block release.
        finished = self.finish_requests(set(rejected_reasons), RequestStatus.FINISHED_ERROR)
        for finished_request in finished:
            # This is a terminal request error, not a resumable segment boundary.
            finished_request.resumable = False
            error_output = self._make_omni_engine_output(
                finished_request,
                new_token_ids=[],
                finish_reason=finished_request.get_finished_reason(),
                stop_reason=rejected_reasons[finished_request.request_id],
                is_segment_finished=False,
            )
            self._pending_chunk_error_outputs.append((finished_request.client_index, error_output))

    def _drain_omni_connector_outputs(self):
        self._generation_defer_batch = False
        outputs = super()._drain_omni_connector_outputs()
        max_wait = getattr(self, "_generation_max_wait_s", 0)
        target = getattr(self, "_generation_min_batch_size", 1)
        coordinator = self.input_coordinator
        if not max_wait or target <= 1 or coordinator is None or self._pause_state != PauseState.UNPAUSED:
            return outputs

        # Count distinct runnable streams, not notifications, padding rows, or
        # chunks whose previous execution still owns their state. Waiting here
        # precedes allocation and metadata replacement. Do not schedule a batch
        # and then discard it to try to accumulate more input.
        ready = set(coordinator.requests_with_ready_chunks)
        terminal = set(coordinator.finished_requests) | set(coordinator.input_terminal_req_ids)
        deadline = getattr(self, "_generation_batch_deadline", None)
        if deadline is None:
            deadline = time.monotonic() + max_wait
        in_flight = any(
            not request.is_finished() and request.num_in_flight_tokens > 0 for request in self.requests.values()
        )
        new_outputs = outputs
        waited_without_input = False
        while True:
            for output in new_outputs:
                ready.update(output.chunk_ready_req_ids)
                terminal.update(output.chunk_finished_req_ids)
                terminal.update(req_id for req_id, update in output.request_metadata.items() if update.input_terminal)
            runnable = {
                req_id
                for req_id in ready | terminal
                if (request := self.requests.get(req_id)) is not None
                and not request.is_finished()
                and request.num_in_flight_tokens == 0
            }
            if runnable and waited_without_input:
                # Idle waiting must not eat the ready batch's coalescing budget.
                # Start that budget at its first arrival, once only. The two
                # bounded windows can delay control processing by at most 2W.
                deadline = time.monotonic() + max_wait
                waited_without_input = False
            # A first/final chunk participates in the same bounded window.
            # At high concurrency almost every batch contains one; bypassing
            # the entire batch in that case defeats coalescing. Low concurrency
            # still dispatches immediately, including single-request tails.
            if not runnable:
                # With no output to retire and all receivers already parked,
                # a wakeable inbox wait avoids repeatedly executing empty steps.
                # Admission/registration/terminal work must reach the runner
                # first; waiting for a not-yet-registered receiver would stall it.
                can_wait_idle = (
                    getattr(self, "_generation_coalescing_policy", "fixed") == "idle_wait"
                    and not in_flight
                    and bool(self.requests)
                    and not getattr(coordinator, "pending_chunk_registrations", ())
                    and not getattr(coordinator, "pending_input_registrations", ())
                    and not getattr(self, "_pending_data_plane_terminal_req_ids", ())
                    and all(request.status == RequestStatus.WAITING_FOR_CHUNK for request in self.requests.values())
                )
                if not can_wait_idle:
                    break
                waited_without_input = True
            elif len(runnable) >= target or len(self.requests) < target:
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            if in_flight:
                # Let EngineCore retire the prior output before waiting for
                # more input. Blocking this thread also blocks the in-flight
                # fence that makes those streams eligible for the next batch.
                # Emit a normal empty scheduler step (including connector and
                # cancellation bookkeeping), never discard an allocated step.
                self._generation_defer_batch = True
                self._generation_batch_deadline = deadline
                return outputs
            try:
                output = self._omni_connector_output_inbox.get(timeout=remaining)
            except queue.Empty:
                break
            outputs.append(output)
            new_outputs = [output]
            # Drain a burst before re-evaluating, retaining notification order.
            while True:
                try:
                    output = self._omni_connector_output_inbox.get_nowait()
                except queue.Empty:
                    break
                outputs.append(output)
                new_outputs.append(output)
        self._generation_batch_deadline = None
        return outputs

    def _build_generation_scheduler_output(
        self,
        new_reqs_data: list[OmniNewRequestData],
        cached_reqs_data: OmniCachedRequestData,
        num_scheduled_tokens: dict[str, int],
        scheduled_spec_decode_tokens: dict[str, list[int]],
        scheduled_encoder_inputs: dict[str, list[int]],
        num_common_prefix_blocks: list[int],
    ) -> SchedulerOutput:
        """Build the worker output and consume scheduler-only connector state."""
        # Dynamic speculative decoding: optimal K chosen by scheduler
        # (upstream Scheduler.schedule parity; 0 when spec decode is unused).
        num_spec_tokens_to_schedule = self.num_spec_tokens
        if self.dynamic_sd_lookup is not None and len(num_scheduled_tokens) > 0:
            num_spec_tokens_to_schedule = self.dynamic_sd_lookup[len(num_scheduled_tokens)]

        # Mamba "align" boundary states must be handed off with exact block ids;
        # they cannot be reconstructed from a connector's append-only block
        # table. Drained every step so stale offers cannot accumulate.
        boundary_state_offloads = self.kv_cache_manager.take_boundary_state_offloads()

        # Connector-only block state: a producer-side connector resolves the
        # current block table lazily for every request scheduled this step (not
        # only the ones that allocated blocks). Built here and cleared again
        # before the output is dispatched -- workers must never see it.
        kv_connector_block_state = None
        if self.connector is not None:
            block_state_req_ids = set(num_scheduled_tokens)
            block_state_req_ids.update(req_id for req_id in boundary_state_offloads if req_id in self.requests)
            kv_connector_block_state = KVConnectorBlockState(
                req_ids=block_state_req_ids,
                resolve_block_ids=self.kv_cache_manager.get_block_ids,
                boundary_state_offloads=boundary_state_offloads,
            )

        scheduler_output = SchedulerOutput(
            scheduled_new_reqs=new_reqs_data,
            scheduled_cached_reqs=cached_reqs_data,
            num_scheduled_tokens=num_scheduled_tokens,
            total_num_scheduled_tokens=sum(num_scheduled_tokens.values()),
            scheduled_spec_decode_tokens=scheduled_spec_decode_tokens,
            scheduled_encoder_inputs=scheduled_encoder_inputs,
            num_common_prefix_blocks=num_common_prefix_blocks,
            finished_req_ids=self.finished_req_ids,
            free_encoder_mm_hashes=self.encoder_cache_manager.get_freed_mm_hashes(),
            # Preemptions accumulated since the previous step; cleared by
            # _update_after_schedule below, exactly like upstream.
            preempted_req_ids=self.reset_preempted_req_ids,
            # Upstream drains the manager-side list every step (unbounded growth
            # otherwise) and applies _skip_zero_block_ids before zeroing.
            new_block_ids_to_zero=self._get_new_block_ids_to_zero(),
            ec_manager_metadata=self.encoder_cache_manager.get_manager_metadata(),
            kv_connector_block_state=kv_connector_block_state,
            num_spec_tokens_to_schedule=num_spec_tokens_to_schedule,
        )

        # KVTransfer: package metadata
        if self.connector is not None:
            meta = self._build_kv_connector_meta(self.connector, scheduler_output)
            scheduler_output.kv_connector_metadata = meta
        if self.aux_output_connector is not None:
            scheduler_output.aux_output_connector_metadata = self.aux_output_connector.build_connector_meta(
                scheduler_output, self.requests
            )
        # EC Connector: package metadata
        if self.ec_connector is not None:
            ec_meta = self.ec_connector.build_connector_meta(scheduler_output)
            scheduler_output.ec_connector_metadata = ec_meta
        # Connector-only block state must not be dispatched to workers.
        scheduler_output.kv_connector_block_state = None

        return scheduler_output

    def _update_after_schedule(self, scheduler_output: SchedulerOutput) -> None:
        self._enforce_kstep_span_uniformity(scheduler_output)
        super()._update_after_schedule(scheduler_output)

    def _is_done_receiving_chunks(self, request_id: str) -> bool:
        if self.chunk_transfer_adapter is not None:
            return self.chunk_transfer_adapter.is_done_receiving_chunks(request_id)
        coordinator = self.input_coordinator
        return bool(self._native_data_plane and coordinator is not None and request_id in coordinator.finished_requests)

    def _input_execution_is_terminal(
        self,
        request_id: str,
        scheduler_output: SchedulerOutput,
    ) -> bool:
        if self._native_data_plane:
            return request_id in getattr(
                scheduler_output,
                "input_terminal_req_ids",
                set(),
            )
        return self._is_done_receiving_chunks(request_id)

    @staticmethod
    def _record_prefill_stats(request: Request) -> None:
        """Mirror upstream first-prefill prompt accounting for generation stages.

        Async-chunk generation stages can grow ``prompt_token_ids`` after the
        first schedule; until this path tracks final chunk lengths, this records
        the first scheduled prompt snapshot. Keep this in sync with vLLM
        Scheduler.schedule() if this fast path gains prefix-cache or external-KV
        accounting.
        """
        if request.prefill_stats is None:
            return
        request.prefill_stats.set(
            num_prompt_tokens=request.num_prompt_tokens,
            num_local_cached_tokens=0,
            num_external_cached_tokens=0,
        )

    def _handle_stopped_request(self, request: Request) -> bool:
        if (
            request.resumable
            and not request.streaming_queue
            and self.chunk_transfer_adapter is not None
            and self.chunk_transfer_adapter.receives_chunks
        ):
            # Downstream async-chunk stages receive the next segment from the
            # connector, not from an API StreamingUpdate. Enqueue them as
            # schedulable before the base class can defer a streaming-input wait.
            request.status = RequestStatus.WAITING
            self._enqueue_waiting_request(request)
            return False
        finished = super()._handle_stopped_request(request)
        if not finished:
            # The pin no longer enqueues inside the base stop handler.
            self._enqueue_waiting_request(request)
        return finished

    def _requeue_completed_native_chunks(self) -> None:
        """Return completed native generation chunks to the admission queue.

        A generation batch slot belongs to one chunk, not the entire stream.
        Keep requests with outstanding output in ``running`` so their state
        cannot be reused before completion. Other live requests join the tail
        of the appropriate waiting queue without freeing decoder state or KV blocks.
        Preserve WAITING_FOR_CHUNK until the coordinator observes fresh input.
        Stateful codecs retain lifetime admission until their decoder state is
        released, even when no chunk is currently executing.
        """
        if (
            not getattr(self, "_native_data_plane", False)
            or not self._async_chunk_transport_enabled()
            or self._retains_state_across_chunks
        ):
            return
        in_flight: list[Request] = []
        for request in self.running:
            if request.num_in_flight_tokens > 0 or request.is_finished():
                in_flight.append(request)
                continue
            if request.status == RequestStatus.RUNNING:
                request.status = RequestStatus.WAITING
            self._enqueue_waiting_request(request)
        self.running = in_flight

    def schedule(self, throttle_prefills: bool = False) -> SchedulerOutput:
        """One-shot generation fast path:
        - Feed all input tokens of the request at once
          (if 0, allocate 1 placeholder token).
        - If the token budget cannot be satisfied at once, fall back to the
          default vLLM scheduling.
        """

        token_budget = self.max_num_scheduled_tokens
        execution_batch_size = self.max_num_running_reqs
        if self._pause_state == PauseState.PAUSED_ALL:
            token_budget = 0
        scheduled_timestamp = time.monotonic()

        self.kv_cache_manager.new_step_starts()

        scheduled_new_reqs: list[Request] = []

        req_to_new_blocks: dict[str, KVCacheBlocks] = {}
        num_scheduled_tokens: dict[str, int] = {}
        scheduled_running_reqs: list[Request] = []
        scheduled_spec_decode_tokens: dict[str, list[int]] = {}
        scheduled_encoder_inputs: dict[str, list[int]] = {}
        cached_prompt_token_ids: dict[str, list[int]] = {}
        cached_additional_information: dict[str, dict | None] = {}

        # Temporary queue: preserve waiting order while requests await input.
        skipped_waiting_requests = create_request_queue(self.policy)
        skipped_kv_holding_requests = create_request_queue(self.policy)
        req_index = 0
        self._drop_aborted_queued_requests()
        self._requeue_completed_native_chunks()
        self._process_pending_omni_inputs(model_mode="generation")
        if getattr(self, "_generation_defer_batch", False):
            token_budget = 0
        max_regular = getattr(self, "_generation_max_regular_batch", 0)
        if max_regular:
            execution_batch_size = min(execution_batch_size, max_regular)
        self._drop_aborted_queued_requests()
        self._reject_oversized_ready_chunks()
        self._resync_streaming_input_counter()
        async_chunk_transport = self._async_chunk_transport_enabled()
        native_chunks = bool(getattr(self, "_native_data_plane", False) and async_chunk_transport)
        serialize_inputs = native_chunks or (
            async_chunk_transport and getattr(self, "_supports_pending_generation", False)
        )
        # Parking releases an execution slot, but stateful codecs retain their
        # request-owned state until completion or abort, in either runner.
        reserved_running_slots = (
            self._get_async_chunk_reserved_running_slots() if self._retains_state_across_chunks else 0
        )

        # OMNI: Track requests that are already finished (e.g., marked by connector)
        # These should be removed from running and not scheduled
        already_finished_reqs: set[Request] = set()
        # An express step isolates first chunks from ready continuations.
        # Two express steps never run back to back; the optional slack guard
        # requires playback headroom before delaying a continuation.
        first_chunk_express = getattr(self, "_first_chunk_express", False)
        express = (
            first_chunk_express
            and native_chunks
            and not self._last_step_express
            and any(
                r.request_id not in self._chunk_started
                and r.num_in_flight_tokens == 0
                and len(r.prompt_token_ids) > r.num_computed_tokens
                for r in self.waiting
            )
        )
        if express and getattr(self, "_express_min_slack_s", 0) > 0 and not self._continuations_have_slack():
            express = False
        if first_chunk_express:
            self._last_step_express = express
        while (
            not express
            and req_index < len(self.running)
            and token_budget > 0
            and len(num_scheduled_tokens) < execution_batch_size
        ):
            request = self.running[req_index]
            # OMNI: Skip requests that are not in self.requests
            if request.request_id not in self.requests or (
                self.chunk_transfer_adapter is None and request.status == RequestStatus.FINISHED_STOPPED
            ):
                already_finished_reqs.add(request)
                req_index += 1
                continue

            if request.num_in_flight_tokens > 0 and (
                serialize_inputs or request.num_computed_tokens >= len(request.prompt_token_ids)
            ):
                # Overlap different streams, never two stateful chunks from
                # the same stream. Readiness remains pending for the next step.
                req_index += 1
                continue

            num_computed_tokens = request.num_computed_tokens
            required_tokens = len(request.prompt_token_ids) - num_computed_tokens
            must_take_whole = self._requires_atomic_chunk() or not self.scheduler_config.enable_chunked_prefill
            if must_take_whole and required_tokens > token_budget:
                # Connector-delivered stateful async chunks must remain intact.
                # When chunked prefill is disabled, preserve the existing
                # all-or-nothing scheduling behavior.
                break
            # async_chunk: don't schedule placeholder tokens when no new chunk is available.
            if required_tokens <= 0:
                if async_chunk_transport and self._is_done_receiving_chunks(request.request_id):
                    if len(request.prompt_token_ids) == 0 and _has_async_chunk_payload_to_run(request):
                        required_tokens = 1
                    else:
                        self._pending_finish_reqs.append(request)
                        req_index += 1
                        continue
                else:
                    req_index += 1
                    continue
            num_new_tokens = min(required_tokens, token_budget)
            new_blocks = self.kv_cache_manager.allocate_slots(
                request,
                num_new_tokens,
                num_lookahead_tokens=self.num_lookahead_tokens,
            )
            if new_blocks is None:
                # Allocation failed (e.g., VRAM pressure); stop fast path and
                # fall back to default scheduling
                # Put the current request back to the head of the waiting queue
                # Note: the original queue order is preserved
                break
            if self.log_stats:
                request.record_event(EngineCoreEventType.SCHEDULED, scheduled_timestamp)
            if num_computed_tokens == 0:
                self._record_prefill_stats(request)
            req_to_new_blocks[request.request_id] = new_blocks
            num_scheduled_tokens[request.request_id] = num_new_tokens
            cached_prompt_token_ids[request.request_id] = request.prompt_token_ids
            cached_additional_information[request.request_id] = getattr(request, "additional_information", None)
            token_budget -= num_new_tokens
            scheduled_running_reqs.append(request)
            req_index += 1

        # OMNI: Remove already finished requests from running queue
        if already_finished_reqs:
            self.running = remove_all(self.running, already_finished_reqs)

        # Fast path selection and scheduling (treat all as diffusion requests,
        # independent of pooling_params)
        while (
            (self.kv_holding_waiting or self.waiting)
            and token_budget > 0
            and len(num_scheduled_tokens) < execution_batch_size
            and (
                len(num_scheduled_tokens)
                if native_chunks and not self._retains_state_across_chunks
                else len(self.running) + reserved_running_slots
            )
            < self.max_num_active_reqs
            and self._pause_state == PauseState.UNPAUSED
        ):
            request_queue = self.kv_holding_waiting or self.waiting
            skipped_requests = (
                skipped_kv_holding_requests if request_queue is self.kv_holding_waiting else skipped_waiting_requests
            )
            request = request_queue.peek_request()
            if express and request.request_id in self._chunk_started:
                request_queue.pop_request()
                self.deferred_waiting.add(request)
                skipped_requests.add_request(request)
                continue
            if request.num_in_flight_tokens > 0 and (
                serialize_inputs or request.num_computed_tokens >= len(request.prompt_token_ids)
            ):
                # A restored waiting entry can still own an outstanding batch.
                # Do not let it block other ready streams or execute it twice.
                request_queue.pop_request()
                self.deferred_waiting.add(request)
                skipped_requests.add_request(request)
                continue
            # OMNI: Skip requests that are not in self.requests
            if request.request_id not in self.requests or (
                self.chunk_transfer_adapter is None and request.status == RequestStatus.FINISHED_STOPPED
            ):
                # Pop the finished request from waiting queue and don't schedule it
                request_queue.pop_request()
                self.deferred_waiting.discard(request)
                continue

            # async_chunk: wait for the first upstream chunk (don't start with placeholders).
            if async_chunk_transport and len(request.prompt_token_ids) == 0:
                if self._is_done_receiving_chunks(request.request_id):
                    if not _has_async_chunk_payload_to_run(request):
                        request_queue.pop_request()
                        self.deferred_waiting.discard(request)
                        self._pending_finish_reqs.append(request)
                        continue
                else:
                    request_queue.pop_request()
                    self.deferred_waiting.add(request)
                    skipped_requests.prepend_request(request)
                    continue

            # Allocate all input tokens for the request in one shot
            # (allocate 1 placeholder if zero)
            required_tokens = max(len(request.prompt_token_ids), 1)
            if native_chunks:
                required_tokens = len(request.prompt_token_ids) - request.num_computed_tokens
                if required_tokens <= 0:
                    if (
                        self._is_done_receiving_chunks(request.request_id)
                        and not request.prompt_token_ids
                        and _has_async_chunk_payload_to_run(request)
                    ):
                        required_tokens = 1
                    else:
                        request_queue.pop_request()
                        if self._is_done_receiving_chunks(request.request_id):
                            self.deferred_waiting.discard(request)
                            self._pending_finish_reqs.append(request)
                        else:
                            self.deferred_waiting.add(request)
                            skipped_requests.add_request(request)
                        continue
            if self._requires_atomic_chunk() and required_tokens > token_budget:
                # Oversized chunks were rejected before entering this loop.
                # Defer intact before allocating slots or popping the request.
                break
            num_new_tokens = min(required_tokens, token_budget)
            new_blocks = self.kv_cache_manager.allocate_slots(
                request,
                num_new_tokens,
                num_lookahead_tokens=self.num_lookahead_tokens,
            )
            if new_blocks is None:
                # Allocation failed (e.g., VRAM pressure); stop fast path and
                # fall back to default scheduling
                # Put the current request back to the head of the waiting queue
                # Note: the original queue order is preserved
                break

            # Officially schedule this request
            request = request_queue.pop_request()
            self.deferred_waiting.discard(request)
            self.running.append(request)
            if self.log_stats:
                request.record_event(EngineCoreEventType.SCHEDULED, scheduled_timestamp)
            if request.num_computed_tokens == 0:
                self._record_prefill_stats(request)

            req_to_new_blocks[request.request_id] = new_blocks
            num_scheduled_tokens[request.request_id] = num_new_tokens
            token_budget -= num_new_tokens
            scheduled_new_reqs.append(request)

        if first_chunk_express:
            self._chunk_started.update(num_scheduled_tokens)

        # Return skipped requests to their original queue.
        if skipped_kv_holding_requests:
            self.kv_holding_waiting.prepend_requests(skipped_kv_holding_requests)
        if skipped_waiting_requests:
            self.waiting.prepend_requests(skipped_waiting_requests)

        # If fast path scheduled none, fall back to the original scheduling
        if not num_scheduled_tokens:
            if async_chunk_transport:
                # Don't fall back: base scheduler doesn't handle async_chunk
                # requests with empty prompt_token_ids.
                self._restore_omni_wait_queues()
            else:
                res = super().schedule(throttle_prefills)
                self._restore_omni_wait_queues()
                self._postprocess_omni_schedule_output(res)
                return self._wrap_omni_scheduler_output(res)

        # Compute common prefix blocks (aligned with v1)
        num_common_prefix_blocks = [0] * len(self.kv_cache_config.kv_cache_groups)
        if self.running:
            any_request = self.running[0]
            num_common_prefix_blocks = self.kv_cache_manager.get_num_common_prefix_blocks(any_request.request_id)

        # Assemble the current SchedulerOutput contract.
        if self.use_v2_model_runner:
            # No resumed reqs in fast path; pass prefill_token_ids for new reqs.
            new_reqs_data = [
                OmniNewRequestData.from_request(
                    req,
                    req_to_new_blocks[req.request_id].get_block_ids(),
                    getattr(req, "_all_token_ids", None),
                )
                for req in scheduled_new_reqs
            ]
        else:
            new_reqs_data = [
                OmniNewRequestData.from_request(req, req_to_new_blocks[req.request_id].get_block_ids())
                for req in scheduled_new_reqs
            ]
        # No running/resumed reqs scheduled in our fast path
        cached_reqs_data = self._make_cached_request_data(
            running_reqs=scheduled_running_reqs,
            resumed_reqs=[],
            num_scheduled_tokens=num_scheduled_tokens,
            spec_decode_tokens=scheduled_spec_decode_tokens,
            req_to_new_blocks=req_to_new_blocks,
        )

        cached_reqs_data = OmniCachedRequestData(
            req_ids=cached_reqs_data.req_ids,
            resumed_req_ids=cached_reqs_data.resumed_req_ids,
            new_token_ids=cached_reqs_data.new_token_ids,
            all_token_ids=cached_reqs_data.all_token_ids,
            new_block_ids=cached_reqs_data.new_block_ids,
            num_computed_tokens=cached_reqs_data.num_computed_tokens,
            num_output_tokens=cached_reqs_data.num_output_tokens,
            prompt_token_ids=cached_prompt_token_ids,
            additional_information=cached_additional_information,
        )

        total_num_scheduled_tokens = sum(num_scheduled_tokens.values())

        # Record request ids scheduled in this step for the next update.
        self.prev_step_scheduled_req_ids.clear()
        self.prev_step_scheduled_req_ids.update(num_scheduled_tokens.keys())

        scheduler_output = self._build_generation_scheduler_output(
            new_reqs_data,
            cached_reqs_data,
            num_scheduled_tokens,
            scheduled_spec_decode_tokens,
            scheduled_encoder_inputs,
            num_common_prefix_blocks,
        )

        # Advance the fence only for non-empty steps (those that actually
        # write KV and have their output processed later in
        # update_from_output). Must precede _update_after_schedule, which
        # stamps request.last_sched_seq from the advanced value; the other
        # half drains in update_from_output. The fallback path above gets
        # both halves from super().schedule(). getattr: __new__-constructed
        # test schedulers carry no defer_block_free attribute.
        if getattr(self, "defer_block_free", False) and total_num_scheduled_tokens > 0:
            self.sched_step_seq += 1

        # Update internal state (advance num_computed_tokens, free encoder inputs,
        # etc.)
        self._update_after_schedule(scheduler_output)

        try:
            # Streaming generation may need several executions of this input.
            self._postprocess_omni_schedule_output(
                scheduler_output, consume_chunks=not getattr(self, "_supports_pending_generation", False)
            )
        finally:
            self._restore_omni_wait_queues()

        return self._wrap_omni_scheduler_output(scheduler_output)

    def _continuations_have_slack(self) -> bool:
        """Whether every started stream with a chunk ready to decode can wait one express step."""
        now = time.monotonic()
        for request in (*self.running, *self.waiting):
            if request.request_id not in self._chunk_started or request.num_in_flight_tokens > 0:
                continue
            if len(request.prompt_token_ids) <= request.num_computed_tokens:
                continue
            audio = self._stream_audio.get(request.request_id)
            if audio is None:
                # No known playback credit: do not delay this continuation.
                return False
            if audio[0] + audio[1] - now < self._express_min_slack_s:
                self._express_skipped_for_slack += 1
                if self._express_skipped_for_slack in (1, 100, 10000):
                    logger.info(
                        "First-chunk express deferred: a stream holds under %.2f s of audio (%d times)",
                        self._express_min_slack_s,
                        self._express_skipped_for_slack,
                    )
                return False
        return True

    def _record_stream_audio(self, request_id: str, mm_output: Any) -> None:
        """Accumulate the seconds of audio each stream has emitted (``model_outputs`` at ``sr``)."""
        if not isinstance(mm_output, dict):
            return
        audio = mm_output.get("model_outputs")
        rate = mm_output.get("sr")
        # Only mono sample vectors have an unambiguous duration here.
        # Unknown/multichannel layouts earn no slack credit.
        if not isinstance(audio, torch.Tensor) or audio.ndim != 1 or audio.numel() == 0:
            return
        if isinstance(rate, torch.Tensor):
            rate = int(rate.reshape(-1)[0]) if rate.numel() else 0
        if not isinstance(rate, int) or rate <= 0:
            return
        entry = self._stream_audio.setdefault(request_id, [time.monotonic(), 0.0])
        entry[1] += audio.numel() / rate

    def _free_request(
        self, request: Request, delay_free_blocks: bool = False
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        if getattr(self, "_first_chunk_express", False):
            self._chunk_started.discard(request.request_id)
            getattr(self, "_stream_audio", {}).pop(request.request_id, None)
        if self.input_coordinator is None:
            return super()._free_request(request, delay_free_blocks)

        try:
            return super()._free_request(request, delay_free_blocks)
        finally:
            self._free_input_coordinator_request(request.request_id)

    def update_from_output(
        self,
        scheduler_output: SchedulerOutput,
        model_runner_output: OmniModelRunnerOutput,
    ) -> dict[int, EngineCoreOutputs]:
        """Update scheduler state and finish completed one-shot work."""
        sampled_token_ids = model_runner_output.sampled_token_ids
        logprobs = model_runner_output.logprobs
        prompt_logprobs_dict = model_runner_output.prompt_logprobs_dict
        num_scheduled_tokens = scheduler_output.num_scheduled_tokens
        pooler_outputs = model_runner_output.pooler_output
        mm_outputs = getattr(model_runner_output, "multimodal_outputs", None)
        num_nans_in_logits = model_runner_output.num_nans_in_logits
        kv_connector_output = model_runner_output.kv_connector_output
        ec_connector_output = getattr(model_runner_output, "ec_connector_output", None)

        cudagraph_stats: CUDAGraphStat | None = model_runner_output.cudagraph_stats

        # Every GPU write enqueued by this and earlier steps has completed, so
        # it is safe to return deferred-free blocks to the pool. This is the
        # update-side half of the upstream v0.28 deferred-free fence; the schedule
        # half advances sched_step_seq in the fast path above.
        # getattr: __new__-constructed test schedulers carry no
        # defer_block_free attribute.
        if (
            getattr(self, "defer_block_free", False)
            # getattr again: SchedulerOutput is mocked field-by-field in the
            # scheduler unit tests, and dataclass fields without defaults are
            # invisible to MagicMock(spec=...).
            and getattr(scheduler_output, "total_num_scheduled_tokens", 0) > 0
        ):
            self.processed_step_seq += 1
            self._drain_deferred_frees()
            # HiSparse async loads must wait for the same completed-step fence.
            if getattr(self, "defer_async_loads", False):
                self._drain_deferred_loads()

        perf_stats: PerfStats | None = None
        if self.perf_metrics and self.perf_metrics.is_enabled():
            perf_stats = self.perf_metrics.get_step_perf_stats_per_gpu(scheduler_output)

        outputs: dict[int, list[EngineCoreOutput]] = defaultdict(list)
        # Emit queued terminal errors even when no model tokens were scheduled.
        for client_index, error_output in self._pending_chunk_error_outputs:
            outputs[client_index].append(error_output)
        self._pending_chunk_error_outputs.clear()
        spec_decoding_stats: SpecDecodingStats | None = None

        failed_kv_load_req_ids: set[str] = set()
        if kv_connector_output and getattr(kv_connector_output, "failed_recving", None):
            # Upstream d43bb2f37f (HiSparse #53781): a receive failure is
            # reported per request identity, so hybrid / multi-pool layouts
            # whose numeric block ids overlap fail closed instead of recovering
            # the wrong request. The helper returns an empty set when the
            # failure is being recomputed, matching _handle_failed_kv_load_outputs.
            failed_kv_load_req_ids.update(self._handle_failed_recving(kv_connector_output.failed_recving))
        if kv_connector_output and getattr(kv_connector_output, "invalid_block_ids", None):
            failed_kv_load_req_ids.update(
                self._handle_invalid_blocks(
                    kv_connector_output.invalid_block_ids,
                    num_scheduled_tokens,
                )
            )

        # NOTE(woosuk): As len(num_scheduled_tokens) can be up to 1K or more,
        # the below loop can be a performance bottleneck. We should do our best
        # to avoid expensive operations inside the loop.
        stopped_running_reqs: set[Request] = set()
        stopped_preempted_reqs: set[Request] = set()
        for req_id, num_tokens_scheduled in num_scheduled_tokens.items():
            assert num_tokens_scheduled > 0
            request = self.requests.get(req_id)
            if request is not None:
                # Settle the in-flight tokens counted in schedule().
                # Must happen before the skips below — failed-KV-load and
                # already-finished requests were incremented too, and the two
                # readers (allocate_slots, _connector_finished) clamp with
                # max(0, computed - in_flight), so a leaked counter silently
                # freezes sliding-window block freeing.
                request.num_in_flight_tokens -= num_tokens_scheduled
            # vLLM 0.27 (a0c092ee72) removed the async_tokens_to_discard
            # handling from the upstream scheduler and replaced it with the
            # num_stale_output_tokens/is_stale mechanism. Omni's discard
            # sites (segment stop, streaming-session replacement) record the
            # in-flight share here; the delayed outputs are dropped below
            # instead of decrementing num_output_placeholders (which the
            # discard zeroed) and underflowing the upstream assert.
            output_is_stale = False
            if request is not None and request.num_stale_output_tokens > 0:
                output_is_stale = True
                request.num_stale_output_tokens -= num_tokens_scheduled
                assert request.num_stale_output_tokens >= 0
            if failed_kv_load_req_ids and req_id in failed_kv_load_req_ids:
                # Skip requests that were recovered from KV load failure
                continue
            if request is None or request.is_finished():
                # Request may already be finished (e.g., aborted during
                # execution / pipeline parallelism / async scheduling).
                continue
            if output_is_stale:
                # Output of a step scheduled before the request's in-flight
                # tokens were discarded (segment stop / session replacement).
                # num_computed_tokens was rolled back at the discard site, so
                # this output must not be appended or emitted.
                continue

            req_index = model_runner_output.req_id_to_index[req_id]
            generated_token_ids = sampled_token_ids[req_index] if sampled_token_ids else []

            scheduled_spec_token_ids = scheduler_output.scheduled_spec_decode_tokens.get(req_id)
            if scheduled_spec_token_ids and generated_token_ids:
                num_draft_tokens = len(scheduled_spec_token_ids)
                num_accepted = len(generated_token_ids) - 1
                num_rejected = num_draft_tokens - num_accepted
                # num_computed_tokens represents the number of tokens
                # processed in the current step, considering scheduled
                # tokens and rejections. If some tokens are rejected,
                # num_computed_tokens is decreased by the number of rejected
                # tokens.
                if request.num_computed_tokens > 0:
                    request.num_computed_tokens -= num_rejected
                # If async scheduling, num_output_placeholders also includes
                # the scheduled spec tokens count and so is similarly adjusted.
                if request.num_output_placeholders > 0:
                    request.num_output_placeholders -= num_rejected
                spec_decoding_stats = self.make_spec_decoding_stats(
                    spec_decoding_stats,
                    num_draft_tokens=num_draft_tokens,
                    num_accepted_tokens=num_accepted,
                    num_invalid_spec_tokens=scheduler_output.num_invalid_spec_tokens,
                    request_id=req_id,
                )

            # Free encoder inputs only after the step has actually executed.
            if request.has_encoder_inputs:
                self._free_encoder_inputs(request)

            stopped = False
            new_logprobs = None
            new_token_ids = generated_token_ids
            kv_transfer_params = None
            ec_transfer_params = None
            pooler_output = pooler_outputs[req_index] if pooler_outputs else None
            mm_output = mm_outputs[req_index] if mm_outputs else None
            if getattr(self, "_express_min_slack_s", 0) > 0 and self._first_chunk_express:
                self._record_stream_audio(req_id, mm_output)
            status_before_stop = request.status
            finish_reason = None
            is_segment_finished = False
            routed_experts = None

            # Decode the pooling output before stop handling so a decoder
            # failure finishes the request with FinishReason.ERROR (500).
            try:
                pooling_output_payload = self._maybe_decode_pooling_output(request, pooler_output)
            except Exception as exc:
                logger.exception("[pooling] decoder hook failed for request %s", req_id)
                pooling_output_payload = None
                request.status = RequestStatus.FINISHED_ERROR
                request.stop_reason = f"pooling output decode failed: {exc}"
                request.resumable = False

            # One-shot generation request: finish after its current input unit
            # has been fully processed.
            generation_pending = req_id in getattr(model_runner_output, "pending_generation_req_ids", set())
            if generation_pending:
                # The model owns its AR/KV state and yielded an output chunk.
                # Re-schedule this input unit without inventing output tokens.
                request.num_computed_tokens -= num_tokens_scheduled
            elif self.chunk_transfer_adapter is not None and getattr(self, "_supports_pending_generation", False):
                self.chunk_transfer_adapter.mark_chunk_consumed(req_id)
            if (
                request.status == RequestStatus.FINISHED_ERROR
                or request.status == RequestStatus.FINISHED_STOPPED
                or (
                    not self._async_chunk_transport_enabled()
                    and not generation_pending
                    and request.num_computed_tokens >= request.num_prompt_tokens
                )
                or (
                    self._async_chunk_transport_enabled()
                    and not generation_pending
                    and self._input_execution_is_terminal(
                        request.request_id,
                        scheduler_output,
                    )
                    and request.num_computed_tokens >= len(request.prompt_token_ids)
                )
            ):
                if request.status != RequestStatus.FINISHED_ERROR:
                    request.status = RequestStatus.FINISHED_STOPPED
                # Optional: set a stop_reason for front-end clarity
                # (does not affect protocol)
                stopped = True

            # Validate grammar before terminal cleanup and finish-reason capture.
            if OmniSchedulerMixin._reject_invalid_grammar_tokens(self, request, new_token_ids):
                stopped = True

            # Finalize prefill stats BEFORE stop handling (upstream v0.28
            # order): _free_request below releases the KV blocks, after which
            # estimate_cached_tokens(request) reports 0. kv_transfer_params is
            # omitted from the emission predicate here because it only becomes
            # non-None when stopped is already True.
            prefill_stats = None
            if new_token_ids or mm_output is not None or pooler_output is not None or stopped:
                prefill_stats = request.take_prefill_stats()
                if prefill_stats is not None:
                    prefill_stats.finalize(self.kv_cache_manager.estimate_cached_tokens(request))

            if stopped:
                if (
                    self.aux_output_connector is not None
                    and (aux_output := model_runner_output.aux_output_connector_output) is not None
                ):
                    routed_experts = self.aux_output_connector.take_output(request, aux_output)
                finish_reason = request.get_finished_reason()
                finished = self._handle_stopped_request(request)
                is_segment_finished = not finished
                if finished and self._native_data_plane:
                    self._pending_data_plane_terminal_req_ids.add(req_id)
                if not finished:
                    # for streaming input request only
                    if self.chunk_transfer_adapter:
                        self.chunk_transfer_adapter.segment_finished_requests.discard(req_id)
                if finished:
                    kv_transfer_params, ec_transfer_params = self._free_request(request)
                    if self.chunk_transfer_adapter is not None:
                        self.chunk_transfer_adapter.cleanup(
                            request.request_id,
                            getattr(request, "external_req_id", None),
                        )
                if status_before_stop == RequestStatus.WAITING_FOR_CHUNK:
                    stopped_running_reqs.add(request)
                    stopped_preempted_reqs.add(request)
                else:
                    stopped_running_reqs.add(request)

            # Extract sample logprobs if needed.
            if request.sampling_params is not None and request.sampling_params.num_logprobs is not None and logprobs:
                new_logprobs = logprobs.slice_request(req_index, len(new_token_ids))

            # spec_token_ids comes from the model runner output
            if num_nans_in_logits is not None and req_id in num_nans_in_logits:
                request.num_nans_in_logits = num_nans_in_logits[req_id]

            # Get prompt logprobs for this request.
            prompt_logprobs_tensors = prompt_logprobs_dict.get(req_id)
            if new_token_ids or mm_output is not None or pooler_output is not None or kv_transfer_params or stopped:
                OmniSchedulerMixin._append_request_output(
                    self,
                    outputs,
                    request,
                    new_token_ids=new_token_ids,
                    finish_reason=finish_reason,
                    new_logprobs=new_logprobs,
                    new_prompt_logprobs_tensors=prompt_logprobs_tensors,
                    pooling_output=pooling_output_payload,
                    multimodal_output=mm_output,
                    stop_reason=request.stop_reason,
                    prefill_stats=prefill_stats,
                    kv_transfer_params=kv_transfer_params,
                    ec_transfer_params=ec_transfer_params,
                    routed_experts=routed_experts,
                    num_nans_in_logits=request.num_nans_in_logits,
                    is_segment_finished=is_segment_finished,
                )
            else:
                # Invariant: EngineCore returns no partial prefill outputs.
                assert not prompt_logprobs_tensors

        # Finish async_chunk requests that schedule() collected because their
        # upstream completed with no remaining codec tokens.
        for request in self._pending_finish_reqs:
            if request in stopped_running_reqs or request.is_finished():
                continue
            request.status = RequestStatus.FINISHED_STOPPED
            finish_reason = request.get_finished_reason()
            finished = self._handle_stopped_request(request)
            is_segment_finished = not finished
            kv_transfer_params = None
            ec_transfer_params = None
            if finished:
                kv_transfer_params, ec_transfer_params = self._free_request(request)
                if self.chunk_transfer_adapter is not None:
                    self.chunk_transfer_adapter.cleanup(
                        request.request_id,
                        getattr(request, "external_req_id", None),
                    )
            OmniSchedulerMixin._append_request_output(
                self,
                outputs,
                request,
                new_token_ids=[],
                finish_reason=finish_reason,
                stop_reason=request.stop_reason,
                kv_transfer_params=kv_transfer_params,
                ec_transfer_params=ec_transfer_params,
                is_segment_finished=is_segment_finished,
            )
            stopped_running_reqs.add(request)
        self._pending_finish_reqs.clear()

        self._remove_stopped_requests_from_queues(
            stopped_running_reqs,
            stopped_preempted_reqs,
        )

        OmniSchedulerMixin._finish_error_requests(self, outputs)

        failed_requests = self._handle_failed_kv_load_outputs(
            failed_kv_load_req_ids,
            outputs,
        )
        if self.chunk_transfer_adapter is not None:
            for request in failed_requests:
                self.chunk_transfer_adapter.cleanup(
                    request.request_id,
                    getattr(request, "external_req_id", None),
                )

        # KV Connector: update state for finished KV Transfers.
        if kv_connector_output:
            self._update_from_kv_xfer_finished(kv_connector_output)

        # EC Connector: update state from worker-side EC connector output.
        # Use getattr for safety with test __new__/SimpleNamespace code paths.
        if getattr(self, "ec_connector", None) is not None and ec_connector_output:
            self.ec_connector.update_connector_output(ec_connector_output)

        kv_connector_stats = self._aggregate_kv_connector_stats(kv_connector_output)
        self._publish_kv_cache_events()

        # Create EngineCoreOutputs for all clients that have requests with
        # outputs in this step.
        engine_core_outputs = {client_index: EngineCoreOutputs(outputs=outs) for client_index, outs in outputs.items()}

        self._attach_finished_request_sets(
            engine_core_outputs,
            synthesize_abort_outputs=False,
        )

        self._attach_scheduler_stats(
            engine_core_outputs,
            spec_decoding_stats,
            kv_connector_stats,
            cudagraph_stats,
            perf_stats,
        )

        self._capture_omni_connector_output(model_runner_output)
        OmniSchedulerMixin._attach_duplex_stage_work(self, scheduler_output, engine_core_outputs)

        return engine_core_outputs

    def _update_request_as_session(self, session: Request, update: StreamingUpdate) -> None:
        """
        Override: Just replace the existing session with the next streaming update.

        Do not expend prompt id using update.
        """
        set_request_perf_chunk(session, perf_chunk_from_buffer(getattr(update, "model_intermediate_buffer", None)))
        self._replace_streaming_session(session, update)
