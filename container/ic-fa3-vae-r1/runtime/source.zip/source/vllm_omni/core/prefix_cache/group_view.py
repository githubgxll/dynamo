# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""KV-cache group access for the omni prefix cache.

The sole path through which the prefix cache touches vLLM scheduler
internals (block tables, slot mappings). Group-spec rejection happens
at kv-cache init via ``check_prefix_cache_kv_groups``; the factory only
returns None when the input batch has no block table.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING, Any, cast

import numpy as np
import torch

from vllm_omni.core.prefix_cache.interface import ModelCachePolicy, OmniPrefixCacheUnmatchError, PrefixCacheConfig

if TYPE_CHECKING:
    from vllm.v1.worker.gpu_input_batch import InputBatch


class FullAttentionGroupView:
    """View over the first (full-attention) KV-cache group.

    Step slots come from the CPU block table (`step_slots_cpu`), not the
    device slot_mapping.
    """

    def __init__(self, input_batch: InputBatch, block_size: int):
        self._input_batch = input_batch
        self.block_size = block_size
        check_prefix_cache_block_layout(input_batch.block_table[0], block_size)

    def _block_table_cpu(self) -> torch.Tensor:
        return self._input_batch.block_table[0].block_table.cpu

    def batch_req_ids(self) -> list[str]:
        return list(self._input_batch.req_ids)

    def step_slots_cpu(self, req_ids: list[str], num_scheduled: dict[str, int]) -> torch.Tensor:
        """This step's slot mapping, computed on CPU from the block table.

        The device slot_mapping would need a stream sync to read back, which
        stalls the whole forward; the CPU block table carries the same
        information (positions are num_computed .. +num_scheduled per request).
        Positions past the table width are dropped. Vectorized: this runs on
        the engine thread every step.
        """
        bs = self.block_size
        index_of = self._input_batch.req_id_to_index
        sched = [(index_of[req_id], n) for req_id in req_ids if (n := int(num_scheduled.get(req_id, 0))) > 0]
        if not sched:
            return torch.empty((0,), dtype=torch.long)
        rows, counts = np.array(sched, dtype=np.int64).T
        starts = np.asarray(self._input_batch.num_computed_tokens_cpu)[rows].astype(np.int64)
        first = np.cumsum(counts) - counts
        pos = np.arange(int(counts.sum()), dtype=np.int64) + np.repeat(starts - first, counts)
        row = np.repeat(rows, counts)
        table = self._block_table_cpu().numpy()
        blocks = pos // bs
        if int(blocks.max()) >= table.shape[1]:
            keep = blocks < table.shape[1]
            pos, row, blocks = pos[keep], row[keep], blocks[keep]
        return torch.from_numpy(table[row, blocks].astype(np.int64) * bs + pos % bs)


class MRv2FullAttentionGroupView:
    """View for Model Runner V2, whose block table has no host copy.

    Block ids come from the adapter's per-request ledger (built from the
    scheduler output it already translates); positions and batch order from
    the ``InputBatch`` bound for the step being saved. Nothing is read back
    from the device and the runner's ``BlockTables`` is not touched.
    """

    def __init__(self, adapter: Any, block_size: int):
        self._adapter = adapter
        self.block_size = block_size
        self._input_batch: Any = None

    def bind(self, input_batch: Any) -> None:
        self._input_batch = input_batch

    def _batch(self) -> Any:
        if self._input_batch is None:
            raise OmniPrefixCacheUnmatchError("MRv2 prefix-cache view has no bound input batch")
        return self._input_batch

    def batch_req_ids(self) -> list[str]:
        batch = self._batch()
        return list(batch.req_ids[: batch.num_reqs])

    def step_slots_cpu(self, req_ids: list[str], num_scheduled: dict[str, int]) -> torch.Tensor:
        batch = self._batch()
        row_of = {req_id: row for row, req_id in enumerate(batch.req_ids[: batch.num_reqs])}
        bs = self.block_size
        parts: list[np.ndarray] = []
        for req_id in req_ids:
            count = int(num_scheduled.get(req_id, 0))
            if count <= 0:
                continue
            row = row_of.get(req_id)
            if row is None or int(batch.num_scheduled_tokens[row]) != count:
                raise OmniPrefixCacheUnmatchError(
                    f"req {req_id}: scheduled {count} tokens, bound input batch disagrees"
                )
            blocks = self._adapter.block_ids(req_id)
            pos = np.arange(count, dtype=np.int64) + int(batch.num_computed_tokens_np[row])
            idx = pos // bs
            if int(idx[-1]) >= len(blocks):
                raise OmniPrefixCacheUnmatchError(
                    f"req {req_id}: position {int(pos[-1])} lies past its {len(blocks)} recorded blocks"
                )
            parts.append(np.asarray(blocks, dtype=np.int64)[idx] * bs + pos % bs)
        if not parts:
            return torch.empty((0,), dtype=torch.long)
        return torch.from_numpy(np.concatenate(parts))


def check_mrv2_prefix_cache_layout(*, block_sizes: list[int], block_size: int, dcp_size: int) -> None:
    """Reject MRv2 layouts the ledger slot math cannot mirror.

    MRv2 block tables hold allocator block ids and its slot mapping uses the
    allocator block size; kernel-block splitting stays inside attention
    metadata, so only DCP striping and a size mismatch need refusing.
    """
    if dcp_size != 1:
        raise OmniPrefixCacheUnmatchError(
            f"omni prefix caching does not support decode context parallel (dcp_world_size={dcp_size}); "
            "disable enable_prefix_caching"
        )
    if not block_sizes or int(block_sizes[0]) != int(block_size):
        raise OmniPrefixCacheUnmatchError(
            f"omni prefix caching block_size {block_size} does not match the kv-cache block table ({block_sizes})"
        )


def check_prefix_cache_block_layout(block_table: object, block_size: int) -> None:
    """Reject block-table layouts ``step_slots_cpu`` cannot mirror.

    The CPU slot math is ``table[req, pos // block_size] * block_size +
    pos % block_size`` over allocator block ids. vLLM breaks that in two
    cases: hybrid kernel blocks (the row holds ``blocks_per_kv_block``
    kernel ids per allocator block, e.g. FlashInfer/FlashMLA with
    ``--block-size 128``) and decode context parallel (tokens are striped
    across ranks and hashed at ``block_size * dcp_world_size``).
    """
    if getattr(block_table, "use_hybrid_blocks", False) or int(getattr(block_table, "blocks_per_kv_block", 1)) != 1:
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching requires kernel_block_size == block_size; the attention backend "
            f"splits each block into {getattr(block_table, 'blocks_per_kv_block', '?')} kernel blocks. "
            "Pick a --block-size the backend supports natively or disable enable_prefix_caching"
        )
    if int(getattr(block_table, "dcp_world_size", 1)) != 1:
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching does not support decode context parallel "
            f"(dcp_world_size={getattr(block_table, 'dcp_world_size', '?')}); disable enable_prefix_caching"
        )
    kv_bs = getattr(block_table, "kv_cache_block_size", block_size)
    if int(kv_bs) != int(block_size):
        raise OmniPrefixCacheUnmatchError(
            f"omni prefix caching block_size {block_size} does not match the kv-cache block table ({kv_bs})"
        )


def check_prefix_cache_kv_groups(kv_cache_groups: Iterable[Any] | None) -> None:
    """Reject hybrid / multi-group models at kv-cache init, not first step.

    Only needs ``kv_cache_config.kv_cache_groups``. ``FullAttentionSpec``
    is imported here so ``tests/core`` can load this module without vllm.
    """
    groups = list(cast(Iterable[object], kv_cache_groups or ()))
    if len(groups) != 1:
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching requires a single full-attention kv-cache group; "
            f"found {len(groups)}. disable enable_prefix_caching for this model"
        )
    from vllm.v1.kv_cache_interface import FullAttentionSpec

    spec = getattr(groups[0], "kv_cache_spec", None)
    if not isinstance(spec, FullAttentionSpec):
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching requires a single full-attention kv-cache group; "
            f"found {type(spec).__name__}. disable enable_prefix_caching for this model"
        )


def check_prefix_cache_kv_transfer(kv_transfer_config: object) -> None:
    """Reject kv_consumer / kv_both stages.

    KV loaded from a producer also shows up as ``num_computed_tokens``; the
    manager would read it as a local hit with no rows behind it.
    """
    if kv_transfer_config is not None and getattr(kv_transfer_config, "is_kv_consumer", False):
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching cannot tell locally cached tokens from KV received "
            "through a KV connector; disable enable_prefix_caching on kv_consumer / "
            "kv_both stages"
        )


def check_prefix_cache_token_accounting(cache_config: object, speculative_config: object) -> None:
    """Reject configs where ``num_computed_tokens`` stops meaning "first
    scheduled position, block aligned".

    Speculative decoding: with async scheduling vLLM keeps
    ``num_computed_tokens_cpu`` optimistic (all drafts accepted) during the
    forward and corrects it after; ``step_slots_cpu`` would read the
    uncorrected value and mirror rows at the wrong slots. Refused as a
    whole until that path is verified. ``prefix_match_unit`` smaller than
    the block enables sub-block hits, which the hit registry rejects as
    unaligned on the first hit; refuse at init instead.
    """
    if speculative_config is not None:
        raise OmniPrefixCacheUnmatchError(
            "omni prefix caching is not supported together with speculative decoding; "
            "disable enable_prefix_caching on this stage"
        )
    unit = getattr(cache_config, "prefix_match_unit", None)
    block_size = getattr(cache_config, "block_size", None)
    if unit is not None and block_size is not None and int(unit) != int(block_size):
        raise OmniPrefixCacheUnmatchError(
            f"omni prefix caching requires block-aligned hits; prefix_match_unit={unit} with block_size={block_size} "
            "enables sub-block hits. Unset prefix_match_unit or disable enable_prefix_caching"
        )


def stage_prefix_cache_config(
    *,
    kv_cache_config: object,
    cache_config: object,
    kv_transfer_config: object,
    scheduler_config: object,
    model_config: object,
    is_pooling_model: bool,
    speculative_config: object = None,
    model_cache_policy: ModelCachePolicy = ModelCachePolicy(),
) -> PrefixCacheConfig | None:
    """Runner-side gate shared by the GPU and NPU model runners.

    Returns None when the stage does not run an omni prefix cache
    (``enable_prefix_caching`` off, a pooling stage that never saves, or
    an explicit native-KV-only model). Native-only stages leave native KV
    cache configuration and its validation untouched.
    Otherwise refuses kv_consumer / kv_both, speculative decoding,
    sub-block matching and hybrid kv groups, then sizes the config from
    the scheduler. One place so a platform runner cannot silently skip a
    refusal the other one has.
    """
    if not getattr(cache_config, "enable_prefix_caching", False) or is_pooling_model:
        return None
    if model_cache_policy.native_kv_cache_only:
        return None
    check_prefix_cache_kv_transfer(kv_transfer_config)
    check_prefix_cache_token_accounting(cache_config, speculative_config)
    check_prefix_cache_kv_groups(getattr(kv_cache_config, "kv_cache_groups", None))
    return PrefixCacheConfig.from_vllm_config(
        num_blocks=kv_cache_config.num_blocks,  # type: ignore[attr-defined]
        block_size=cache_config.block_size,  # type: ignore[attr-defined]
        scheduler_config=scheduler_config,
        model_config=model_config,
    )


def get_prefix_cache_group_view(
    input_batch: InputBatch,
    block_size: int,
    kv_cache_groups: Iterable[Any] | None = None,
) -> FullAttentionGroupView | None:
    """Build the group view; None only if the batch has no block table.

    Group spec is checked first (raises). Selection is by spec, not by
    counting block tables: a hybrid model's group 0 is not necessarily
    full attention, and a narrower per-group table would make
    step_slots_cpu silently clamp.
    """
    check_prefix_cache_kv_groups(kv_cache_groups)
    block_tables = getattr(input_batch.block_table, "block_tables", None)
    if not block_tables:
        return None
    return FullAttentionGroupView(input_batch, block_size)
