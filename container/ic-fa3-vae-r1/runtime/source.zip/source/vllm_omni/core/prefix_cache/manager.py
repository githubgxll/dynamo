# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Omni prefix cache, manager side.

Owns slot occupancy, the request-task table, the hit/span registry,
per-step snapshots, and the merge. The controller owns the staging
pool, copy queues, and writing rows into the CPU block pool. The
state lock covers those tables only — never a wait-for-copy, a
GPU-byte-budget flush, or a memcpy.

Helper docstrings mark ``_state_lock`` (non-reentrant):

    Caller holds   already inside a critical section; do not acquire
    Takes          acquires here (``@_locked`` or ``with``)

Two host stores:

    StagingBufferPool   reusable step-sized pages. save copies this
                        step's immediately-cached keys (hidden +
                        non-deferred mm) device→host into one page.
                        Per-task `chunk.host` is a view into that page,
                        not a second copy.
    PrefixBlockPool     durable (kv_slot, key) prefix cache. The
                        committer only writes into it.

Two write paths (which keys, not how many tokens):

    JOIN_NEXT_STEP      immediately-cached keys. Device→host is already
                        in flight at submit; the committer waits
                        `step_d2h_event` then copies host→pool. The next
                        save waits `done`: reused slots must not leave a
                        pending pool write behind.
    JOIN_ON_FINISH      deferred mm. Stays on the device clone; the
                        committer does that device→host, then writes the
                        pool. Forced onto the high-priority queue on
                        finish/abort or GPU-byte-budget pressure.

Per real scheduler_output, engine-thread order:

    new_step_starts   before _update_states drops finished requests
                      (register hits, start prefix prefetch)
    forward
    save_outputs      clone off live buffers + launch staging copy;
                      returns step id
    materialize or discard_step   exactly one of the two, once

materialize may run on the async output builder while the engine is
already in the next step. Warmup/dummy runs are never fed.
"""

from __future__ import annotations

import logging
import threading
from collections import deque
from collections.abc import Iterable, Mapping
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, NamedTuple, NoReturn

import torch

from vllm_omni.core.prefix_cache.adapter import (
    PrefixCacheEventKind,
    PrefixCacheStep,
    PrefixCacheWriteLayout,
)
from vllm_omni.core.prefix_cache.block_pool import PrefixBlockPool
from vllm_omni.core.prefix_cache.controller import (
    OmniPrefixCacheController,
    StepSnapshot,
    StepWriteContext,
    WriteTaskHandle,
)
from vllm_omni.core.prefix_cache.interface import (
    ModelCachePolicy,
    OmniPrefixCacheStagingTimeoutError,
    OmniPrefixCacheUnmatchError,
    PrefixCacheConfig,
    ReqId,
    StageCacheOutputs,
    StepId,
    TensorName,
    Tid,
    WriteSchedule,
    is_hidden_key,
    without_hidden,
)

logger = logging.getLogger(__name__)


class _Occupancy(IntEnum):
    ABSENT = 0
    IN_TRANSIT = 1
    COMMITTED = 2


def _is_step_token_tensor(val: Any, n: int, padded: int) -> bool:
    """2D+ tensor whose first dim is this step's token count (``n`` or padded).

    True means callers may take ``val[:n]``. Leftover tensors (``codes.ref``),
    lists, and other shapes are False.
    """
    return isinstance(val, torch.Tensor) and val.ndim >= 2 and int(val.shape[0]) in (n, padded)


def _raise_unreadable_hit(req_id: str, key: str, why: str) -> NoReturn:
    raise OmniPrefixCacheUnmatchError(f"hit span for req {req_id} key={key} is not readable ({why})")


def _snapshot_leftover_mm_cpu(
    mm_outputs: dict[str, Any],
    device_snapshot_keys: set[str],
    num_tokens_unpadded: int,
    num_tokens_padded: int | None = None,
) -> tuple[dict[str, Any], torch.cuda.Event | None]:
    """CPU copy of mm that did not land on the staging page.

    Skip ``device_snapshot_keys`` (those already have a device→host page).
    Copy the rest — deferred mm, lists, ``codes.ref`` — so materialize can
    run after the next forward overwrites graph buffers. Slice ``[:n]``
    only when ``shape[0] == n``; ``>= n`` would clip ``codes.ref``.

    CUDA tensors land in pinned memory through a non-blocking copy on the
    current stream: stream order keeps it ahead of the next forward, and
    the engine thread does not wait for this forward to finish. The
    returned event (None when nothing was on CUDA) must be synchronized
    before the snapshot is read.
    """
    n = num_tokens_unpadded
    padded = n if num_tokens_padded is None else int(num_tokens_padded)
    on_cuda = False

    def _copy(val: Any) -> Any:
        nonlocal on_cuda
        if isinstance(val, torch.Tensor):
            t = val[:n] if _is_step_token_tensor(val, n, padded) and int(val.shape[0]) == n else val
            t = t.detach()
            if t.is_cuda:
                host = torch.empty(t.shape, dtype=t.dtype, device="cpu", pin_memory=True)
                host.copy_(t, non_blocking=True)
                on_cuda = True
                return host
            # .cpu() copies other device tensors; CPU/pinned views still share storage.
            copied = t.cpu() if t.device.type != "cpu" else t.clone()
            return copied.contiguous()
        if isinstance(val, Mapping):
            return {k: _copy(v) for k, v in val.items()}
        if isinstance(val, list):
            return [_copy(v) for v in val]
        if isinstance(val, tuple):
            return tuple(_copy(v) for v in val)
        return val

    leftover = {
        key: _copy(val) for key, val in mm_outputs.items() if key not in device_snapshot_keys and not is_hidden_key(key)
    }
    event = None
    if on_cuda:
        event = torch.cuda.Event()
        event.record()
    return leftover, event


def _unpin_leftover(val: Any) -> Any:
    """Clone pinned tensors out so the payload does not hold pinned pages."""
    if isinstance(val, torch.Tensor):
        return val.clone() if val.is_pinned() else val
    if isinstance(val, Mapping):
        return {k: _unpin_leftover(v) for k, v in val.items()}
    if isinstance(val, list):
        return [_unpin_leftover(v) for v in val]
    if isinstance(val, tuple):
        return tuple(_unpin_leftover(v) for v in val)
    return val


@dataclass
class _StepOutputs:
    """This step's outputs split by consumer.

    A tensor whose first dim equals this step's token count (or the
    CUDA-graph padded count) can be sliced ``[:n]`` into per-token rows.
    ``codes.ref`` and lists are not that shape.

    ``immediate``: those per-token rows copied device→host this step
    (hidden + non-deferred mm). ``deferred``: packed per-token mm
    for JOIN_ON_FINISH. ``leftover``: CPU replica
    for this step's materialize of everything that did not get a staging
    page.
    A deferred per-token key is in both ``deferred`` (later cache
    write) and ``leftover`` (this-step read) — two consumers, not a
    duplicate store.

    The controller accounts for these packed clones when preparing writes.
    """

    immediate: dict[str, torch.Tensor]
    deferred: dict[str, torch.Tensor]
    leftover: dict[str, Any]
    # Completion of the leftover device→host copies; None when none ran on CUDA.
    leftover_event: torch.cuda.Event | None = None
    # Pool storage allocated (unlocked) for keys first seen this step;
    # published into the pool / occupancy tables under the state lock.
    new_key_storage: dict[str, torch.Tensor] = field(default_factory=dict)

    def freeze_targets(self) -> list[torch.Tensor]:
        """Device clones the freeze event must cover."""
        return list(self.immediate.values()) + list(self.deferred.values())


def _locked(fn):
    """Serialize public entry points: the async output builder calls
    materialize() while the engine thread is in the next step."""

    def wrapper(self, *args, **kwargs):
        with self._state_lock:
            return fn(self, *args, **kwargs)

    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


@dataclass
class _SlotRef:
    """Where one (req, key) span's slots live: planned under the lock, fetched outside it.

    Schedule split, not a single read tier:
    - JOIN_NEXT_STEP in-transit: ``join_tids``. Fetch waits ``done``,
      drains, then reads the pool. Staging views are never sliced.
    - JOIN_ON_FINISH in-transit: ``staged_list`` task refs. Fetch uses
      ``fetch_host`` (device freeze / committer host).
    - Already in the CPU pool: ``already_staged`` → pool.

    A JOIN_NEXT_STEP task may disappear between plan and join (another
    entry already published it into the pool); ``join`` no-ops and the
    pool rows persist.
    """

    slots: torch.Tensor  # KV slot ids (PrefixBlockPool rows)
    key: TensorName
    req_id: ReqId
    already_staged: bool  # this key is already in the CPU pool
    staged_list: list[tuple[WriteTaskHandle, torch.Tensor]]  # JOIN_ON_FINISH only
    join_tids: list[Tid] = field(default_factory=list)  # JOIN_NEXT_STEP in-transit
    # Slot version snapshot at plan time, checked on fetch.
    reserved_version: torch.Tensor | None = None
    # Copy-on-write rescue: slot's committed rows for pending reads.
    preserved: dict[int, torch.Tensor] = field(default_factory=dict)
    # Slots never written at plan time; their pool rows are unset storage.
    absent: torch.Tensor | None = None


@dataclass(kw_only=True)
class _StepContext:
    """Save-time snapshot of one step; consumed exactly once.

    Built on the engine thread in save_outputs so materialize (possibly on
    the async builder) never reads the live batch. Host rows live on `d2h_snapshot`
    (empty views when this save only had leftover mm). materialize or
    discard_step pops it and frees the staging slot. A later save waits
    if all slots are still held.
    """

    # Packed layout in batch order: req -> [start, end) of this step's rows.
    spans: dict[ReqId, tuple[int, int]]
    num_tokens_unpadded: int = 0

    # Hits snapshotted at new_step_starts. Prefetch fills [hit | empty tail]
    # during forward; materialize writes the tail.
    hits: dict[ReqId, tuple[int, list[int], int]]  # (hit_upto, blocks, read_start)
    hit_prefetch: dict[ReqId, dict[TensorName, Future]] = field(default_factory=dict)
    # Leading rows of this step's slice that were already delivered.
    trims: dict[ReqId, int] = field(default_factory=dict)

    # Key split frozen at save: recompute at materialize races ensure_key.
    cached_keys: set[TensorName] = field(default_factory=set)
    # Leftover mm copied to CPU at save (this-step deferred rows + mm
    # that is not written to the pool).
    mm_cpu_snapshot: dict[TensorName, Any] = field(default_factory=dict)
    # Wait this before reading mm_cpu_snapshot (None when nothing was on CUDA).
    mm_cpu_snapshot_event: torch.cuda.Event | None = None

    # Staging slot for this step id (empty views when only leftover mm).
    d2h_snapshot: StepSnapshot | None = None


class _SlotStatus(NamedTuple):
    """Occupancy row for one tensor name (views into the table, not copies)."""

    state: torch.Tensor  # int8[num_slots]
    tids: torch.Tensor  # Tid per kv slot; 0 = none
    slot_version: torch.Tensor  # int64[num_slots]; bumped each time a new write claims the slot


class _SlotStatusTable:
    """Per (KV slot, tensor name): empty, being written, or already in the pool.

    Hidden and a deferred mm field on the same slot are independent.
    ``map_slots`` marks a write in progress; if another task still owns
    the slot, the manager records those rows as no longer owned by it.
    ``commit`` runs after the pool write: still-owned slots become
    committed.
    """

    def __init__(self, num_slots: int) -> None:
        self.num_slots = num_slots
        self.state: dict[TensorName, torch.Tensor] = {}  # int8[num_slots]
        self.tids: dict[TensorName, torch.Tensor] = {}  # Tid per kv slot; 0 = none
        self.slot_versions: dict[TensorName, torch.Tensor] = {}  # int64[num_slots]; bumped on each new write claim
        self.task_slots: dict[Tid, torch.Tensor] = {}  # kv slots
        self.task_keys: dict[Tid, tuple[TensorName, ...]] = {}

    def init_table(self, key: TensorName) -> None:
        """Allocate occupancy tensors for ``key`` if they do not exist."""
        if key in self.state:
            return
        self.state[key] = torch.zeros(self.num_slots, dtype=torch.int8)
        self.tids[key] = torch.zeros(self.num_slots, dtype=torch.int64)
        self.slot_versions[key] = torch.zeros(self.num_slots, dtype=torch.int64)

    def get_slot_status(self, key: TensorName) -> _SlotStatus:
        """Occupancy tensors for ``key``. ``init_table`` must have run."""
        return _SlotStatus(state=self.state[key], tids=self.tids[key], slot_version=self.slot_versions[key])

    def map_slots(
        self, slots: torch.Tensor, tid: Tid, keys: Iterable[TensorName]
    ) -> list[tuple[Tid, TensorName, torch.Tensor]]:
        """Record ``tid`` on these (slot, key). Return in-transit rows
        another write still owned (caller marks them skipped on it)."""
        keys = tuple(keys)
        stolen: list[tuple[Tid, TensorName, torch.Tensor]] = []
        for key in keys:
            status = self.get_slot_status(key)
            cur = status.tids[slots]
            stale = (status.state[slots] == _Occupancy.IN_TRANSIT) & (cur != tid) & (cur != 0)
            if bool(stale.any()):
                for old in {int(o) for o in cur[stale].tolist()}:
                    stolen.append((old, key, slots[stale & (cur == old)]))
            status.state[slots] = _Occupancy.IN_TRANSIT
            status.tids[slots] = tid
            # Bump the version so a reader that captured an older one detects
            # this claim even after it later commits (COMMITTED, not IN_TRANSIT).
            status.slot_version[slots] += 1
        prev = self.task_slots.get(tid)
        if prev is None:
            self.task_slots[tid] = slots
            self.task_keys[tid] = keys
        else:
            # Deferred writes accumulate slots across steps.
            self.task_slots[tid] = torch.cat([prev, slots])
            self.task_keys[tid] = tuple(dict.fromkeys(self.task_keys[tid] + keys))
        return stolen

    def commit(self, tids: Iterable[Tid]) -> None:
        """Flip still-owned slots to COMMITTED and drop the reverse index."""
        for tid in tids:
            slots = self.task_slots.pop(tid, None)
            keys = self.task_keys.pop(tid, ())
            if slots is None:
                continue
            for key in keys:
                status = self.get_slot_status(key)
                still_ours = status.tids[slots] == tid
                idx = slots[still_ours]
                status.state[idx] = _Occupancy.COMMITTED
                status.tids[idx] = 0


class _RequestTaskTable:
    """Per request: still live, which writes it opened, deferred task.

    Also allocates ``tid`` and increments per-request ``write_n``.
    Device→host copy and pool write stay on the controller.
    """

    def __init__(self) -> None:
        self._next_tid: Tid = 1
        self.write_n: dict[ReqId, int] = {}  # last write_n issued
        self.tasks: dict[ReqId, set[Tid]] = {}
        self.deferred: dict[ReqId, WriteTaskHandle] = {}

    def alloc_tid(self) -> Tid:
        tid = self._next_tid
        self._next_tid += 1
        return tid

    def increment_write_n(self, req_id: ReqId) -> int:
        n = self.write_n.get(req_id, 0) + 1
        self.write_n[req_id] = n
        return n

    def track(self, req_id: ReqId, tid: Tid) -> None:
        self.tasks.setdefault(req_id, set()).add(tid)

    def finish(self, req_id: ReqId) -> tuple[set[Tid], WriteTaskHandle | None]:
        """Drop this request's rows. Returns owned tids + deferred task."""
        self.write_n.pop(req_id, None)
        tids = self.tasks.pop(req_id, set())
        dtask = self.deferred.pop(req_id, None)
        return tids, dtask

    def drop_completed(self, tids: Iterable[Tid]) -> None:
        done = set(tids)
        if not done:
            return
        for req_tids in self.tasks.values():
            req_tids -= done


class OmniPrefixCacheManager:
    def __init__(
        self,
        config: PrefixCacheConfig,
        *,
        eager: bool | None = None,
    ):
        self._config = config
        self._pool = PrefixBlockPool(config)
        self._controller = OmniPrefixCacheController(self._pool, config, eager=eager)
        self._policy = ModelCachePolicy()
        # Serializes engine vs async-builder public entries. Non-reentrant:
        # those entries never call each other, and the lock must not cover
        # a wait-for-copy, GPU-byte-budget flush, or device→host copy.
        self._state_lock = threading.Lock()

        self._slot_status = _SlotStatusTable(config.num_blocks * config.block_size)
        # Hidden is known from the default policy; mm rows at init_table.
        if (hk := self._policy.hidden_key) is not None:
            self._slot_status.init_table(hk)
        self._request_tasks = _RequestTaskTable()
        # Join worklists — not occupancy, not the request-task table.
        self._join_next_step_tids: list[Tid] = []
        self._join_finished_tids: set[Tid] = set()  # escalated on finish/abort

        # This step's hits (copied into _StepContext at save).
        self._cur_num_scheduled: dict[ReqId, int] = {}
        self._hit_spans: dict[ReqId, tuple[int, list[int], int]] = {}  # (upto, blocks, read_start)
        self._hit_prefetch: dict[ReqId, dict[TensorName, Future]] = {}
        self._trims: dict[ReqId, int] = {}

        # Planned-but-unread slot refs. A write reusing their slots copies the
        # old rows into ``_SlotRef.preserved`` before overwriting (COW). Guarded
        # by ``_state_lock``; each ref is dropped when its fetch completes.
        self._pending_reads: list[_SlotRef] = []
        # Pending refs per (key, slot), so a write checks its slots with one gather.
        self._pending_slot_refs: dict[TensorName, torch.Tensor] = {}
        # Sticky fatal set on the first drained write failure; every later
        # facade entry re-raises it (see _commit_drained_writes).
        self._fatal_write_failure: str | None = None

        # Prefix gather during forward (CPU work releases the GIL).
        # One worker: complete in submit order; pop finished work from the head.
        self._prefetch_pool = ThreadPoolExecutor(1, thread_name_prefix="omni-prefix-cache-prefetch")
        self._prefetch_queue: deque[tuple[Future, _SlotRef]] = deque()

        # One snapshot per step id; consume with materialize or discard_step.
        self._next_step_id: StepId = 1
        self._step_ctxs: dict[StepId, _StepContext] = {}

    # ------------------------------------------------------ public entries

    def register_policy(self, policy: ModelCachePolicy) -> None:
        self._policy = policy
        if (hk := policy.hidden_key) is not None:
            self._slot_status.init_table(hk)

    @torch.inference_mode()
    def new_step_starts(self, step: PrefixCacheStep) -> None:
        """Handle one immutable adapter-produced step.

        Engine thread only; before _update_states removes finished
        requests. Runners may skip this entry for pure decode steps. Registers
        new-request prefix hits (copying their block tables) and forces finished/aborted
        requests' still-open writes onto the high-priority copy queue —
        a block hash that entered the batch must land in the cache,
        abort included. ``escalate`` (eager: the copy + pool write) runs
        after ``_state_lock`` is released.
        """
        if not isinstance(step, PrefixCacheStep):
            raise TypeError("new_step_starts requires a PrefixCacheStep")
        events = step.events
        to_escalate: list[int] = []
        with self._state_lock:
            # 1. Publish writes the committer has already written into the pool.
            self._commit_drained_writes()

            # 2. Finished/aborted reqs: collect still-open writes. Abort too:
            #    those block hashes are already in vLLM; dropping the write
            #    would leave future hits ABSENT. The next save waits
            #    join_host_ready. (Not leftover_mm — those are this-step reads.)
            for event in events:
                if event.kind not in (PrefixCacheEventKind.FINISHED, PrefixCacheEventKind.ABORTED):
                    continue
                req_id = event.req_id
                tids, dtask = self._request_tasks.finish(req_id)
                if dtask is not None:
                    tids.add(dtask.tid)
                pending_tasks = [tid for tid in tids if self._controller.lookup(tid) is not None]
                if pending_tasks:
                    to_escalate.extend(pending_tasks)
                    self._join_finished_tids.update(pending_tasks)

            # 3. Copy this arrival's prefix-hit block ids. The adapter captures
            #    them before _update_states; after that point they sit
            #    on the live request and grow as decode allocates more blocks.
            #    materialize (async builder) must not reread that live table.
            self._clear_hit_infos()
            for event in events:
                if event.kind not in (PrefixCacheEventKind.STARTED,):
                    continue
                req_id = event.req_id
                # The adapter alone classifies starts versus continuation or
                # resume. Do not re-infer that lifecycle from write-task state.
                num_computed = int(event.hit_end)
                if num_computed > 0:
                    self._register_hit_span(req_id, num_computed, event.block_ids, read_start=0)
            # Re-entries whose first position differs from what was already
            # delivered: replay the gap from the cache, or drop the overlap.
            for delivery in step.deliveries:
                if delivery.read_end > delivery.read_start:
                    self._register_hit_span(
                        delivery.req_id, delivery.read_end, delivery.block_ids, read_start=delivery.read_start
                    )
                elif delivery.trim > 0:
                    self._trims[delivery.req_id] = int(delivery.trim)

            # 4. Gather those spans on the prefetch thread; overlaps this forward.
            while self._prefetch_queue and self._prefetch_queue[0][0].done():
                self._prefetch_queue.popleft()
            self._cur_num_scheduled = dict(step.scheduled_tokens)
            if self._hit_spans:
                self._prefetch_hit_spans()
        if to_escalate:
            self._controller.escalate(to_escalate)

    @torch.inference_mode()
    def save_outputs(
        self,
        hidden_states: torch.Tensor | None,
        mm_outputs: dict[str, Any] | None,
        *,
        num_tokens_unpadded: int,
        num_tokens_padded: int,
        write_layout: PrefixCacheWriteLayout,
        owned: bool = False,
    ) -> int:
        """Write this step's outputs into the cache; returns the step id.

        Engine thread only, after the forward and before materialize.
        Immediately-cached rows: one on-device clone, one whole-step
        device→host into the staging pool, then one JOIN_NEXT_STEP
        write for the step's requests, managed by the controller.
        Deferred rows stay on the device clone (JOIN_ON_FINISH); the
        committer copies them later. Leftover mm (this-step deferred rows
        + mm not written to the pool) is copied to CPU here so materialize
        never reads live graph buffers.
        Snapshots everything materialize needs. The returned step id MUST
        be consumed exactly once — by materialize() or discard_step().
        Every step id claims one staging slot (saves with only leftover mm
        included); a later save waits for a free slot and times out if
        none return. ``owned`` inputs are fresh, unaliased storage the
        caller hands over, so they are kept instead of cloned.

        The state lock never covers a blocking wait: the previous step's
        JOIN_NEXT_STEP wait, the clone build, the GPU-byte-budget reserve
        (which may flush), and the staging-slot claim all run unlocked.
        """
        # 1. Join the previous step's host copies (unlocked).
        self._wait_for_host_ready()

        # 2. Packed batch layout for this step (req -> [start, end)).
        if write_layout is None:
            raise OmniPrefixCacheUnmatchError("save_outputs requires an adapter-produced write_layout")
        req_order = [write.req_id for write in write_layout.writes]
        num_sched = {write.req_id: write.row_end - write.row_start for write in write_layout.writes}
        query_start = {write.req_id: write.row_start for write in write_layout.writes}
        # Hit buffers were sized from the captured step, not this layout.
        # Reject disagreement before cloning, staging or publishing rows.
        with self._state_lock:
            for req_id in self._hit_spans:
                expected = self._cur_num_scheduled.get(req_id, 0)
                actual = num_sched.get(req_id, 0)
                if actual != expected:
                    raise OmniPrefixCacheUnmatchError(
                        f"scheduled token count mismatch for req {req_id}: step={expected}, layout={actual}"
                    )

        slots_cpu: torch.Tensor | None = write_layout.slots_cpu
        mm_outputs = mm_outputs or {}
        freeze_event = None

        # 3. Slot map, then split into immediate / deferred / leftover.
        if num_tokens_unpadded > 0:
            # Derive the slot mapping on CPU: reading the device one back
            # would need a stream sync that waits on the whole forward.
            if slots_cpu is None:
                raise OmniPrefixCacheUnmatchError("write_layout is missing its CPU slot snapshot")
            if int(slots_cpu.numel()) != num_tokens_unpadded:
                # Fail at the cause: skipping the save would leave rows absent
                # behind hashes vLLM already published — a delayed crash at
                # some future hit instead of a debuggable one here.
                raise OmniPrefixCacheUnmatchError(
                    f"slot mapping covers {int(slots_cpu.numel())} of {num_tokens_unpadded} scheduled tokens; "
                    "CPU-side slot derivation out of sync with the batch"
                )
        step_outputs = self._split_step_outputs(
            hidden_states,
            mm_outputs,
            num_tokens_unpadded,
            num_tokens_padded,
            owned=owned,
        )

        # Freeze on the compute stream before the controller launches copies.
        freezed_tensors = step_outputs.freeze_targets()
        if freezed_tensors:
            if torch.cuda.is_available() and any(t.is_cuda for t in freezed_tensors):
                freeze_event = torch.cuda.Event()
                freeze_event.record()

        step_id = self._next_step_id
        try:
            with self._prepare_step(step_id, step_outputs, slots_cpu, num_tokens_unpadded, freeze_event) as write_ctx:
                self._publish_saved_step(
                    step_id=step_id,
                    req_order=req_order,
                    query_start=query_start,
                    num_sched=num_sched,
                    num_tokens_unpadded=num_tokens_unpadded,
                    step_outputs=step_outputs,
                    slots_cpu=slots_cpu,
                    mm_keys=set(mm_outputs.keys()),
                    write_ctx=write_ctx,
                )
                # Eager execution and queue dispatch must remain outside the lock.
                write_ctx.start_writes()
                return step_id
        except BaseException:
            with self._state_lock:
                self._step_ctxs.pop(step_id, None)
            raise

    @torch.inference_mode()
    def materialize(self, step_id: int, req_ids: list[str], *, include_uncached: bool = True) -> StageCacheOutputs:
        """Per-request merged outputs for the step saved as `step_id`.

        Any thread. `req_ids` must be (a subset of) the save-time snapshot;
        an outside id means the caller is reading the live batch.
        A request without a hit is a plain miss and gets exactly
        this step's rows — normal path, nothing logged. A hit span that
        resolves to absent rows raises OmniPrefixCacheUnmatchError: fatal
        by contract (do not pretend it was a miss). A replay span prepends
        its cached rows; a trim drops this step's already-delivered leading
        rows. Both apply to hidden and pool keys only: leftover mm is
        request-scoped and passes through unchanged. ``include_uncached``
        False omits the leftover mm entirely.

        Two phases: under the lock, publish finished writes and pin every
        row source (task refs + masks, absent checks included) — not yet
        reading the tensors. Unlocked: wait this step's `step_d2h_event`,
        clone the staging views (then drop the step holder), and merge.
        The engine thread never waits on this thread's device→host copy.
        """
        ctx = None
        step_released = False
        try:
            with self._state_lock:
                ctx = self._take_step_ctx(step_id)
                self._commit_drained_writes()

                # The builder must pass (a subset of) the req list captured at
                # save time — an id outside the snapshot means it is reading the
                # live batch, which the contract forbids. Not a fallback that
                # serves a miss.
                unknown = set(req_ids) - set(ctx.spans)
                if unknown:
                    raise OmniPrefixCacheUnmatchError(
                        f"materialize(step {step_id}) got req ids outside the save snapshot: {sorted(unknown)[:8]}"
                    )

                cached_keys = ctx.cached_keys

                hit_sources: dict[tuple[str, str], _SlotRef | Future] = {}
                for req_id in req_ids:
                    hit = ctx.hits.get(req_id)
                    if not hit:
                        continue
                    hit_upto, hit_blocks, read_start = hit
                    prefetched = ctx.hit_prefetch.get(req_id, {})
                    slots = self._get_hit_slots(hit_upto, hit_blocks, read_start)
                    keys = self._policy.get_hit_keys(cached_keys)
                    for key in keys:
                        fut = prefetched.get(key)
                        if fut is not None:
                            hit_sources[(req_id, key)] = fut
                            continue
                        hit_sources[(req_id, key)] = self._slot_ref(slots, key, req_id)

            # ---- unlocked: data movement + merge ----
            if ctx.mm_cpu_snapshot_event is not None:
                ctx.mm_cpu_snapshot_event.synchronize()
                ctx.mm_cpu_snapshot = _unpin_leftover(ctx.mm_cpu_snapshot)
            current: dict[str, torch.Tensor] = {}
            if ctx.d2h_snapshot is not None:
                # Whole-step device→host was launched at save. One event wait
                # (usually already complete), then a contiguous copy-out per
                # key so consumers no longer depend on the reusable slot.
                current = ctx.d2h_snapshot.copy_to_cpu()
                self._release_step_staging(ctx)
                step_released = True

            hidden_out: dict[str, torch.Tensor] | None = None
            hidden_key = self._policy.hidden_key
            if hidden_key is not None and hidden_key in current:
                hidden_out = {}
                for req_id in req_ids:
                    hidden_out[req_id] = self._merge_cached_for_req(
                        ctx, req_id, hidden_key, current[hidden_key], hit_sources
                    )

            mm_out: dict[str, dict[str, Any]] = {}
            for key in cached_keys:
                cur = current.get(key)
                if cur is None:
                    val = ctx.mm_cpu_snapshot.get(key)
                    if not isinstance(val, torch.Tensor):
                        continue
                    # Leftover snapshot; spans stay within [0, n), no re-slice.
                    cur = val
                mm_out[key] = {
                    req_id: self._merge_cached_for_req(ctx, req_id, key, cur, hit_sources) for req_id in req_ids
                }

            if include_uncached:
                self._merge_uncached_mm(ctx, req_ids, cached_keys, mm_out)
            return StageCacheOutputs(hidden_states=hidden_out, mm_outputs=mm_out)
        finally:
            if ctx is not None and not step_released:
                self._release_step_staging(ctx)

    def reserve_device_bytes(self, nbytes: int) -> None:
        """Charge device rows the runner holds for a later save (its decode
        buffer) to the GPU-byte budget; may force pending copies first, so
        it runs outside the state lock."""
        self._controller.reserve_bytes(nbytes)

    def release_device_bytes(self, nbytes: int) -> None:
        self._controller.release_bytes(nbytes)

    @_locked
    def discard_step(self, step_id: int) -> None:
        """Consume the step context when nothing will materialize it.

        Any thread; same exactly-once contract as materialize (unknown or
        duplicate id raises). Only the read-side snapshot is dropped —
        the cache write proceeds unchanged.
        """
        ctx = self._take_step_ctx(step_id)
        self._release_step_staging(ctx)

    @_locked
    def step_rewrite_req_ids(self, step_id: int) -> frozenset[ReqId]:
        """Requests of a saved step whose merged rows differ from the step slice.

        Any thread; does not consume the step id. Empty means materialize
        would return exactly this step's rows for every request.
        """
        ctx = self._step_ctxs.get(step_id)
        if ctx is None:
            raise OmniPrefixCacheUnmatchError(f"step context {step_id} missing; already consumed or never saved")
        return frozenset(ctx.hits) | frozenset(req_id for req_id, trim in ctx.trims.items() if trim > 0)

    def shutdown(self) -> None:
        self._prefetch_pool.shutdown(wait=False, cancel_futures=True)
        self._prefetch_queue.clear()
        self._controller.shutdown()

    # ------------------------------------------------------ new_step

    def _clear_hit_infos(self) -> None:
        """Drop the live hit / prefetch tables. Caller holds ``_state_lock``."""
        self._hit_spans.clear()
        self._hit_prefetch.clear()
        self._trims.clear()

    def _register_hit_span(
        self, req_id: ReqId, hit_upto: int, block_ids: tuple[tuple[int, ...], ...], *, read_start: int
    ) -> None:
        """Caller holds ``_state_lock``. Snapshot one replay span ``[read_start, hit_upto)``."""
        # block_ids is per-kv-group; group 0 only.
        if not block_ids or not block_ids[0]:
            # Fail at the cause: a hit we cannot snapshot now would crash at
            # materialize time with less context (materialize is forbidden
            # from reading the live batch).
            raise OmniPrefixCacheUnmatchError(f"prefix hit for req {req_id} ({hit_upto} tokens) carries no block_ids")
        bs = self._config.block_size
        if hit_upto % bs != 0:
            raise OmniPrefixCacheUnmatchError(
                f"prefix hit not block aligned (req={req_id}, hit_upto={hit_upto}, block_size={bs})"
            )
        if not 0 <= read_start < hit_upto:
            raise OmniPrefixCacheUnmatchError(
                f"replay span for req {req_id} is empty or negative: [{read_start}, {hit_upto})"
            )
        needed = hit_upto // bs
        if len(block_ids[0]) < needed:
            raise OmniPrefixCacheUnmatchError(
                f"prefix hit for req {req_id} ({hit_upto} tokens) has {len(block_ids[0])} group-0 blocks, need {needed}"
            )
        self._hit_spans[req_id] = (hit_upto, list(block_ids[0][:needed]), read_start)

    def _invalidate_overwritten_prefetches(self) -> None:
        """Caller holds ``_state_lock``. Refresh this step's hits whose
        intended producer registered a write after the early prefetch."""
        for future, src in self._prefetch_queue:
            futs = self._hit_prefetch.get(src.req_id)
            if futs is None or futs.get(src.key) is not future:
                continue
            versions = self._slot_status.get_slot_status(src.key).slot_version[src.slots]
            if src.reserved_version is None or not torch.equal(versions, src.reserved_version):
                # Let the old fetch finish and unregister its pending read.
                # COW may have preserved the prior tenant, which this hit must not use.
                del futs[src.key]

    def _prefetch_hit_spans(self) -> None:
        """Caller holds ``_state_lock``. Plan each hit span not yet planned
        and gather it on the prefetch thread.

        Called twice per step: at new_step_starts (overlaps the forward)
        and again at publish for spans that could not plan then — same-step
        hits, whose rows this step's save has only now registered. Starting
        the gather at publish, not at materialize, means it runs before the
        next step can hand those blocks to a new tenant; a span that still
        fails to plan is left to materialize, which raises if unread.
        """
        keys = self._policy.get_hit_keys(self._pool.keys())
        for req_id, (hit_upto, hit_blocks, read_start) in self._hit_spans.items():
            futs = self._hit_prefetch.setdefault(req_id, {})
            if all(key in futs for key in keys):
                continue
            n_new = int(self._cur_num_scheduled.get(req_id, 0))
            slots = self._get_hit_slots(hit_upto, hit_blocks, read_start)
            for key in keys:
                if key in futs:
                    continue
                try:
                    src = self._slot_ref(slots, key, req_id)
                except OmniPrefixCacheUnmatchError:
                    continue
                fut = self._prefetch_pool.submit(self._prefetch_hit, src, n_new)
                self._prefetch_queue.append((fut, src))
                futs[key] = fut
            if not futs:
                del self._hit_prefetch[req_id]

    @torch.inference_mode()
    def _prefetch_hit(self, src: _SlotRef, n_new: int) -> torch.Tensor:
        """Prefetch thread: gather the hit span and pre-build the merged
        buffer with the prefix filled. materialize writes only this step's
        rows at the tail — the gather AND the prefix copy both happen while
        the forward runs, and the cat leaves the critical path."""
        rows = self._fetch_source(src)
        out = torch.empty((rows.shape[0] + n_new, rows.shape[-1]), dtype=rows.dtype)
        out[: rows.shape[0]] = rows
        return out

    # ---------------------------------------------------------- save

    def _prepare_step(
        self,
        step_id: StepId,
        outputs: _StepOutputs,
        slots: torch.Tensor | None,
        num_tokens: int,
        freeze_event: torch.cuda.Event | None,
    ) -> StepWriteContext:
        """Prepare unlocked; annotate backpressure with manager-owned diagnostics."""
        try:
            return self._controller.prepare_step(
                step_id=step_id,
                immediate=outputs.immediate,
                deferred=outputs.deferred,
                slots=slots,
                num_tokens=num_tokens,
                freeze_event=freeze_event,
            )
        except OmniPrefixCacheStagingTimeoutError as e:
            with self._state_lock:
                ids = sorted(self._step_ctxs)
            raise OmniPrefixCacheStagingTimeoutError(
                f"{e}; unconsumed step contexts (ids={ids}) or a stuck write "
                f"(in_flight_tasks={self._controller.in_flight_tasks()})"
            ) from e

    def _wait_for_host_ready(self) -> None:
        """Pop last step's join worklists and wait them out, unlocked.

        JOIN_NEXT_STEP waits ``done``, not ``host_ready``: this save may reuse
        those slots, and a pool write still pending behind a reused slot is
        unreadable for a delayed hit read (scatter skips reassigned rows).
        Escalated deferred writes keep ``host_ready`` — their readers hold the
        task in ``staged_list``. Lock covers only the pop.
        """
        with self._state_lock:
            finished_ids = list(self._join_finished_tids)
            next_step_ids = list(self._join_next_step_tids)
            self._join_finished_tids.clear()
            self._join_next_step_tids.clear()
        if finished_ids:
            self._controller.join_host_ready(finished_ids)
        if next_step_ids:
            self._controller.join(next_step_ids)

    @_locked
    def _publish_saved_step(
        self,
        *,
        step_id: StepId,
        req_order: list[str],
        query_start: dict[str, int],
        num_sched: dict[str, int],
        num_tokens_unpadded: int,
        step_outputs: _StepOutputs,
        slots_cpu: torch.Tensor | None,
        mm_keys: set[str],
        write_ctx: StepWriteContext,
    ) -> None:
        """Takes ``_state_lock``. Register this step's writes and store the
        consume-once snapshot. Copies live hits into the snapshot, then
        clears them. The caller starts writes after releasing the lock;
        device→host, budget flush and eager execution stay outside.
        """
        self._commit_drained_writes()
        for key, storage in step_outputs.new_key_storage.items():
            self._pool.install_key(key, storage)
            self._slot_status.init_table(key)
        if step_outputs.immediate or step_outputs.deferred:
            assert slots_cpu is not None
            self._register_step_writes(write_ctx, step_outputs, slots_cpu, req_order, query_start, num_sched)
        if self._hit_spans:
            # Same-step hits: their rows are registered now (IN_TRANSIT on
            # this step's tasks); start the gather before the next step.
            self._invalidate_overwritten_prefetches()
            self._prefetch_hit_spans()
        self._next_step_id = step_id + 1
        self._step_ctxs[step_id] = _StepContext(
            spans={r: (query_start[r], query_start[r] + num_sched[r]) for r in req_order},
            num_tokens_unpadded=num_tokens_unpadded,
            hits=dict(self._hit_spans),
            hit_prefetch=dict(self._hit_prefetch),
            trims=dict(self._trims),
            cached_keys=without_hidden(self._pool.keys()) & mm_keys,
            mm_cpu_snapshot=step_outputs.leftover,
            mm_cpu_snapshot_event=step_outputs.leftover_event,
            d2h_snapshot=write_ctx.snapshot,
        )
        self._clear_hit_infos()

    def _split_step_outputs(
        self,
        hidden_states: torch.Tensor | None,
        mm_outputs: dict[str, Any],
        num_tokens_unpadded: int,
        num_tokens_padded: int,
        *,
        owned: bool = False,
    ) -> _StepOutputs:
        """Split this step's outputs into immediate / deferred / leftover.

        Unlocked. One pass over ``mm_outputs``. ``n==0`` has only leftover
        mm (no device clones). A deferred key whose first dim is this
        step's token count is cloned for the JOIN_ON_FINISH write and
        CPU-copied into leftover for this-step materialize. Talker
        ``codes.audio`` stays unpadded while hidden is padded; both must
        open a pool key.
        Lists and other shapes stay leftover.
        """
        n = num_tokens_unpadded
        if owned and num_tokens_padded != n:
            # Owned rows are the caller's whole batch; a padded tail means a live buffer.
            raise OmniPrefixCacheUnmatchError(f"owned step outputs must be unpadded: {num_tokens_padded} rows for {n}")
        immediate: dict[str, torch.Tensor] = {}
        deferred_tensors: dict[str, torch.Tensor] = {}
        new_key_storage: dict[str, torch.Tensor] = {}

        def alloc_key(key: str, val: torch.Tensor) -> None:
            # Allocated unlocked; installed under the lock at publish.
            storage = self._pool.alloc_key(key, val.dtype, int(val.shape[-1]))
            if storage is not None:
                new_key_storage[key] = storage

        if n > 0:
            if hidden_states is not None and (hk := self._policy.hidden_key) is not None:
                if hidden_states.ndim < 2 or hidden_states.shape[0] < n:
                    rows = 0 if hidden_states.ndim < 2 else int(hidden_states.shape[0])
                    raise OmniPrefixCacheUnmatchError(f"hidden_states has {rows} rows, need {n}")
                alloc_key(hk, hidden_states)
                immediate[hk] = hidden_states[:n] if owned else hidden_states[:n].clone()
            for key, val in mm_outputs.items():
                is_step_rows = _is_step_token_tensor(val, n, num_tokens_padded)
                if key in self._policy.deferred_keys:
                    if is_step_rows:
                        alloc_key(key, val)
                        deferred_tensors[key] = val[:n] if owned else val[:n].clone()
                    continue
                if self._policy.skip_immediate_mm(key) or not is_step_rows:
                    continue
                alloc_key(key, val)
                immediate[key] = val[:n] if owned else val[:n].clone()
        leftover, leftover_event = _snapshot_leftover_mm_cpu(mm_outputs, set(immediate), n, num_tokens_padded)
        return _StepOutputs(
            immediate=immediate,
            deferred=deferred_tensors,
            leftover=leftover,
            leftover_event=leftover_event,
            new_key_storage=new_key_storage,
        )

    def _register_step_writes(
        self,
        write_ctx: StepWriteContext,
        outputs: _StepOutputs,
        slots: torch.Tensor,
        req_order: list[str],
        query_start: dict[str, int],
        num_sched: dict[str, int],
    ) -> None:
        """Publish request/slot ownership under the state lock, without executing."""
        for schedule, tensors in (
            (WriteSchedule.JOIN_NEXT_STEP, outputs.immediate),
            (WriteSchedule.JOIN_ON_FINISH, outputs.deferred),
        ):
            if not tensors:
                continue
            if schedule is WriteSchedule.JOIN_NEXT_STEP:
                self._register_immediate_write(
                    write_ctx, tuple(tensors.keys()), slots, req_order, query_start, num_sched
                )
                continue
            spans: list[tuple[int, int, int]] = []
            for req_id in req_order:
                start = query_start[req_id]
                end = start + num_sched[req_id]
                if start == end:
                    continue
                handle = self._request_tasks.deferred.get(req_id)
                if handle is None or not write_ctx.append(handle, start=start, end=end):
                    handle = write_ctx.register(
                        tid=self._request_tasks.alloc_tid(),
                        req_id=req_id,
                        write_n=self._request_tasks.increment_write_n(req_id),
                        schedule=schedule,
                        start=start,
                        end=end,
                    )
                    self._request_tasks.track(req_id, handle.tid)
                    self._request_tasks.deferred[req_id] = handle
                spans.append((handle.tid, start, end))
            self._claim_slots(slots, tuple(tensors.keys()), spans)

    def _register_immediate_write(
        self,
        write_ctx: StepWriteContext,
        keys: tuple[str, ...],
        slots: torch.Tensor,
        req_order: list[str],
        query_start: dict[str, int],
        num_sched: dict[str, int],
    ) -> None:
        """One immediate write for every request of the step.

        A write per request costs a slot-table update and a pool scatter per
        request on every step, which dominates decode batches.
        """
        written = [req_id for req_id in req_order if num_sched[req_id]]
        if not written:
            return
        start = query_start[written[0]]
        end = query_start[written[-1]] + num_sched[written[-1]]
        if end - start != sum(num_sched[req_id] for req_id in written):
            raise OmniPrefixCacheUnmatchError(f"step rows [{start}, {end}) are not one packed span")
        handle = write_ctx.register(
            tid=self._request_tasks.alloc_tid(),
            req_id=written[0],
            write_n=self._request_tasks.increment_write_n(written[0]),
            schedule=WriteSchedule.JOIN_NEXT_STEP,
            start=start,
            end=end,
        )
        for req_id in written:
            self._request_tasks.track(req_id, handle.tid)
        self._join_next_step_tids.append(handle.tid)
        self._claim_slots(slots, keys, [(handle.tid, start, end)])

    # ----------------------------------------------------- occupancy

    def _claim_slots(self, slots: torch.Tensor, keys: tuple[str, ...], spans: list[tuple[int, int, int]]) -> None:
        """Caller holds ``_state_lock``. Hand each ``(tid, start, end)`` span of
        ``slots`` to that write for ``keys``; a write that still owns some of
        them has those rows marked skipped. Slots are claimed only here, so
        pending reads of the reused rows are always copied aside first (COW).
        """
        if not spans:
            return
        if self._pending_reads:
            self._preserve_for_pending_reads(torch.cat([slots[start:end] for _, start, end in spans]), keys)
        for tid, start, end in spans:
            for old, key, stolen in self._slot_status.map_slots(slots[start:end], tid, keys):
                self._controller.mark_reassigned(old, key, stolen)

    def _preserve_for_pending_reads(self, new_slots: torch.Tensor, keys: tuple[str, ...]) -> None:
        """Caller holds ``_state_lock``. Copy still-valid committed rows into
        each pending ref before ``new_slots`` are claimed.

        Only COMMITTED rows at the reserved version need rescuing: the save
        barrier joins JOIN_NEXT_STEP writes to ``done`` and publish drains
        before claiming, and JOIN_ON_FINISH in-transit rows are read through
        ``staged_list`` task refs directly.
        """
        if not self._pending_reads:
            return
        new_slots = new_slots.to(device="cpu", dtype=torch.long)  # counts and status tables live on CPU
        keys = tuple(
            k for k in keys if (counts := self._pending_slot_refs.get(k)) is not None and bool(counts[new_slots].any())
        )
        if not keys:
            return
        for ref in self._pending_reads:
            if ref.key not in keys or ref.reserved_version is None or not self._pool.has_key(ref.key):
                continue
            reclaimed = torch.isin(ref.slots, new_slots)
            if ref.preserved:
                reclaimed &= ~torch.isin(ref.slots, torch.tensor(list(ref.preserved), dtype=torch.long))
            if not bool(reclaimed.any()):
                continue
            status = self._slot_status.get_slot_status(ref.key)
            idx = reclaimed.nonzero().flatten()
            slots = ref.slots[idx]
            valid = (status.state[slots] == _Occupancy.COMMITTED) & (
                status.slot_version[slots] == ref.reserved_version[idx]
            )
            if not bool(valid.any()):
                continue
            slots = slots[valid]
            rows = self._pool.rows(ref.key, slots)
            for j, s in enumerate(slots.tolist()):
                ref.preserved[s] = rows[j].clone()

    @torch.inference_mode()
    def _commit_drained_writes(self) -> None:
        """Fold completed/failed writes into occupancy. Caller holds ``_state_lock``.

        A failed write leaves rows absent behind hashes vLLM already
        published — unservable and unrecoverable, so fatal. The fatality is
        sticky: the drained record is one-shot and the first raise can land
        in a swallowed path (a prefetch Future dropped by discard_step), so
        every later entry must keep raising rather than serve zeros.
        """
        if self._fatal_write_failure is not None:
            raise OmniPrefixCacheUnmatchError(self._fatal_write_failure)
        failed = self._controller.drain_failed()
        if failed:
            self._fatal_write_failure = (
                f"prefix cache write failed for task(s) {failed}; cached rows lost behind published hashes"
            )
            raise OmniPrefixCacheUnmatchError(self._fatal_write_failure)
        drained = self._controller.drain_completed()
        if drained:
            self._slot_status.commit(drained)
            self._request_tasks.drop_completed(drained)

    # --------------------------------------------------- consume-once

    def _take_step_ctx(self, step_id: int) -> _StepContext:
        """Pop the context for this step id (exactly once). Caller holds ``_state_lock``."""
        ctx = self._step_ctxs.pop(step_id, None)
        if ctx is None:
            raise OmniPrefixCacheUnmatchError(
                f"step context {step_id} missing (have {sorted(self._step_ctxs)}); already consumed or never saved"
            )
        return ctx

    def _release_step_staging(self, ctx: _StepContext) -> None:
        if ctx.d2h_snapshot is not None:
            ctx.d2h_snapshot.release()

    # -------------------------------------------------- slot ref / fetch

    def _get_hit_slots(self, hit_upto: int, hit_blocks: list[int], read_start: int = 0) -> torch.Tensor:
        """Hit block ids → KV slot ids of ``[read_start, hit_upto)``. Alignment
        is checked at ``new_step_starts``. Does not require ``_state_lock``.
        """
        bs = self._config.block_size
        block_ids = torch.tensor(hit_blocks, dtype=torch.int64)
        return (block_ids.unsqueeze(1) * bs + torch.arange(bs)).reshape(-1)[read_start:hit_upto]

    def _slot_ref(self, slots: torch.Tensor, key: str, req_id: str) -> _SlotRef:
        """Caller holds ``_state_lock``. Pin a ``_SlotRef`` for `slots` (no data movement).

        Rows still being written win over the CPU pool: they may not have
        landed yet, and a pool read would return zero/stale values.
        JOIN_NEXT_STEP tasks go in ``join_tids`` (wait-then-pool at
        fetch). JOIN_ON_FINISH tasks stay as refs for fetch_host.

        Hidden rejects any empty hole (prefetch skips; materialize
        raises). Other keys only need a source — holes fall to the pool.

        The ref is registered in ``_pending_reads`` so a write that later
        reuses one of these slots copies the old row aside first (COW). Reads
        are planned synchronously under the lock at hit time (prefetch runs at
        ``new_step_starts`` / publish), before the block can be reused, so this
        registration always precedes the reuse. ``_fetch_source`` unregisters.
        """
        status = self._slot_status.get_slot_status(key)
        states = status.state[slots]
        tids = status.tids[slots]
        reserved_version = status.slot_version[slots].clone()
        staged_mask = states == _Occupancy.IN_TRANSIT

        staged: list[tuple[WriteTaskHandle, torch.Tensor]] = []
        join_tids: list[int] = []
        for tid in {int(t) for t in tids[staged_mask].tolist()}:
            task = self._controller.lookup(tid) if tid != 0 else None
            if task is None:
                _raise_unreadable_hit(req_id, key, f"in-transit entry {tid} cannot serve them")
            if task.schedule is WriteSchedule.JOIN_NEXT_STEP:
                join_tids.append(task.tid)
            else:
                staged.append((task, staged_mask & (tids == tid)))

        already_staged = self._pool.has_key(key)
        has_source = already_staged or bool(staged) or bool(join_tids)
        if is_hidden_key(key):
            n_abs = int((states == _Occupancy.ABSENT).sum())
            if n_abs or not has_source:
                _raise_unreadable_hit(req_id, key, f"{n_abs} absent slots")
        absent = states == _Occupancy.ABSENT
        ref = _SlotRef(
            slots=slots,
            key=key,
            req_id=req_id,
            already_staged=already_staged,
            staged_list=staged,
            join_tids=join_tids,
            reserved_version=reserved_version,
            absent=absent if bool(absent.any()) else None,
        )
        self._pending_reads.append(ref)
        self._count_pending_slots(ref, 1)
        return ref

    def _count_pending_slots(self, ref: _SlotRef, delta: int) -> None:
        """Caller holds ``_state_lock``. Add `delta` to the pending-ref count of `ref`'s slots."""
        counts = self._pending_slot_refs.get(ref.key)
        if counts is None:
            # Updated in and out of inference mode (hit planning vs. prefetch release).
            with torch.inference_mode(False):
                counts = self._pending_slot_refs[ref.key] = torch.zeros(self._slot_status.num_slots, dtype=torch.int32)
        slots = ref.slots.to(torch.long)
        counts.index_add_(0, slots, torch.full((slots.numel(),), delta, dtype=torch.int32))

    def _apply_preserved_rows(self, src: _SlotRef, out: torch.Tensor) -> torch.Tensor:
        """Write ``src.preserved`` rows over the matching slots in ``out``."""
        if not src.preserved:
            return out
        for i, s in enumerate(src.slots.tolist()):
            row = src.preserved.get(int(s))
            if row is not None:
                out[i] = row
        return out

    def _unregister_pending_read(self, src: _SlotRef) -> None:
        """Drop ``src`` from ``_pending_reads``. Identity, not dataclass eq
        (tensors in the ref make ``==`` unusable). Safe if already removed."""
        with self._state_lock:
            n = len(self._pending_reads)
            self._pending_reads = [ref for ref in self._pending_reads if ref is not src]
            if len(self._pending_reads) < n:
                self._count_pending_slots(src, -1)

    def _fetch_source(self, src: _SlotRef) -> torch.Tensor:
        """Fetch a planned row source (execute phase, no lock).

        One key is one schedule: ``join_tids`` (JOIN_NEXT_STEP) and
        ``staged_list`` (JOIN_ON_FINISH) do not coexist. Immediate: wait
        ``done``, drain, read the pool. Deferred: pool rows already
        written, overlay ``fetch_host`` on the still-in-progress mask.
        Slots a later write reused are served from ``src.preserved``
        (copied under the lock before that write claimed them).
        """
        try:
            return self._fetch_source_inner(src)
        finally:
            self._unregister_pending_read(src)

    def _pool_rows(self, src: _SlotRef) -> torch.Tensor:
        """Pool rows for ``src``; slots absent at plan time read as zeros."""
        rows = self._pool.rows(src.key, src.slots)
        if src.absent is not None:
            rows[src.absent] = 0
        return rows

    def _fetch_source_inner(self, src: _SlotRef) -> torch.Tensor:
        # For JOIN_NEXT_STEP, wait `done`, drain, read the pool
        if src.join_tids:
            self._controller.join(src.join_tids)
            with self._state_lock:
                self._commit_drained_writes()
            joined = self._apply_preserved_rows(src, self._pool_rows(src))
            self._ensure_not_reassigned(
                src.slots,
                src.key,
                req_id=src.req_id,
                planned_version=src.reserved_version,
                preserved_slots=src.preserved,
            )
            return joined

        # For JOIN_ON_FINISH, pool rows already written, overlay `fetch_host`
        n = int(src.slots.numel())
        out: torch.Tensor | None = None
        if src.already_staged:
            out = self._pool_rows(src)
        in_transit = None
        for task, mask in src.staged_list:
            try:
                rows = self._controller.fetch_host(task, src.slots[mask], src.key)
            except KeyError:
                _raise_unreadable_hit(
                    src.req_id,
                    src.key,
                    f"entry {task.tid} (req {task.req_id}, write_n {task.write_n}) cannot serve them",
                )
            if out is None:
                out = torch.zeros((n, rows.shape[-1]), dtype=rows.dtype)
            out[mask] = rows
            in_transit = mask if in_transit is None else in_transit | mask
        if out is not None:
            out = self._apply_preserved_rows(src, out)
        self._ensure_not_reassigned(
            src.slots,
            src.key,
            in_transit_mask=in_transit,
            req_id=src.req_id,
            planned_version=src.reserved_version,
            preserved_slots=src.preserved,
        )
        if out is None:
            _raise_unreadable_hit(src.req_id, src.key, "no source")
        return out

    def _ensure_not_reassigned(
        self,
        slots: torch.Tensor,
        key: str,
        *,
        in_transit_mask: torch.Tensor | None = None,
        req_id: str = "?",
        planned_version: torch.Tensor | None = None,
        preserved_slots: dict[int, torch.Tensor] | None = None,
    ) -> None:
        """Takes ``_state_lock``. Post-fetch check: rows read unlocked may
        have been given to a newer write between plan and read (block reuse).

        vLLM frees a request's blocks when it finishes or is aborted, one
        step before the terminal lifecycle event reaches us, and may reuse them at
        once. A planned ``_SlotRef`` is registered in ``_pending_reads``;
        the reusing write copy-on-writes those COMMITTED rows into
        ``preserved`` before it claims the slots. Those slots are safe.
        A version mismatch with no preserved copy means the pool rows are
        a newer tenant's — raise for live and finished alike, never serve
        them.

        ``planned_version`` is the per-slot version captured at plan time.
        ``in_transit_mask`` excludes JOIN_ON_FINISH slots this task itself
        still serves through ``fetch_host``.
        """
        with self._state_lock:
            status = self._slot_status.get_slot_status(key)
            if planned_version is not None:
                violated = status.slot_version[slots] != planned_version
            else:
                violated = status.state[slots] == _Occupancy.IN_TRANSIT
            if in_transit_mask is not None:
                violated &= ~in_transit_mask
            if preserved_slots:
                for i, s in enumerate(slots.tolist()):
                    if int(s) in preserved_slots:
                        violated[i] = False
            if not bool(violated.any()):
                return
        _raise_unreadable_hit(
            req_id,
            key,
            f"{int(violated.sum())} hit slots reassigned before this delayed read (block reuse)",
        )

    # ---------------------------------------------------------- merge

    def _merge_cached_for_req(
        self,
        ctx: _StepContext,
        req_id: str,
        key: str,
        current_cpu: torch.Tensor,
        hit_sources: dict[tuple[str, str], _SlotRef | Future],
    ) -> torch.Tensor:
        """Hit prefix + this step's rows for one (req, key).

        No hit → this step's slice only. Prefetch Future → write the
        slice into the reserved tail. Else cat(fetch, new).
        """
        start, end = ctx.spans[req_id]
        new_rows = current_cpu[min(end, start + ctx.trims.get(req_id, 0)) : end]
        src = hit_sources.get((req_id, key))
        if src is None:
            return new_rows
        if isinstance(src, Future):
            # Prefetched during the forward, prefix already in place; only
            # this step's rows land here. result() re-raises fetch/validation
            # errors — unread hits still raise after the thread hop.
            merged = src.result()
            merged[merged.shape[0] - new_rows.shape[0] :] = new_rows
            return merged
        cached = self._fetch_source(src)
        return torch.cat([cached, new_rows], dim=0)

    def _merge_uncached_mm(
        self,
        ctx: _StepContext,
        req_ids: list[str],
        cached_keys: set[str],
        mm_out: dict[str, dict[str, Any]],
    ) -> None:
        """Write leftover mm that is not a pool key into mm_out.

        No hit concat: leftover mm was already copied to CPU at save
        (``ctx.mm_cpu_snapshot``). cached_keys already went through
        _merge_cached_for_req. ``req_ids`` is a subset of ``ctx.spans``.
        """
        leftover = {k: v for k, v in ctx.mm_cpu_snapshot.items() if k not in cached_keys and not is_hidden_key(k)}
        if not leftover:
            return
        from vllm_omni.utils.mm_outputs import to_payload_element

        order = list(ctx.spans)
        total_length = sum(e - s for s, e in ctx.spans.values())
        for key, val in leftover.items():
            per_req: dict[str, Any] = {}
            for req_id in req_ids:
                idx = order.index(req_id)
                start, end = ctx.spans[req_id]
                per_req[req_id] = to_payload_element(
                    val,
                    idx,
                    start=start,
                    end=end,
                    pass_lists_through=True,
                    seq_len=total_length,
                )
            mm_out[key] = per_req
