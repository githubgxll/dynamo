# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""ABot-World causal DMD pipeline with offline and realtime inference."""

from __future__ import annotations

import math
import os
import warnings
from collections.abc import Callable, Iterable, Iterator, Sequence
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar, cast

import numpy as np
import PIL.Image
import PIL.ImageOps
import torch
import torch.nn.functional as F
from diffusers.utils.torch_utils import randn_tensor
from torch import nn
from transformers import AutoTokenizer, UMT5Config, UMT5EncoderModel
from vllm.distributed import get_tensor_model_parallel_world_size

from vllm_omni.diffusion.data import DiffusionOutput, OmniDiffusionConfig
from vllm_omni.diffusion.distributed.autoencoders.autoencoder_kl_wan import DistributedAutoencoderKLWan
from vllm_omni.diffusion.distributed.utils import get_local_device
from vllm_omni.diffusion.forward_context import set_forward_context_denoise_step_idx
from vllm_omni.diffusion.interaction.mixin import InteractionMixin
from vllm_omni.diffusion.interaction.types import ChunkMediaSpec
from vllm_omni.diffusion.model_loader.diffusers_loader import DiffusersPipelineLoader
from vllm_omni.diffusion.models.interface import SupportImageInput, SupportsComponentDiscovery
from vllm_omni.diffusion.models.progress_bar import ProgressBarMixin
from vllm_omni.diffusion.models.wan2_2.pipeline_wan2_2 import retrieve_latents
from vllm_omni.diffusion.offloader import sequential_offload_component
from vllm_omni.diffusion.offloader.config import OffloadStrategy, offload_enabled, resolve_offload
from vllm_omni.diffusion.profiler.diffusion_pipeline_profiler import DiffusionPipelineProfilerMixin
from vllm_omni.diffusion.request import OmniDiffusionRequest
from vllm_omni.diffusion.worker.input_batch import InputBatch
from vllm_omni.diffusion.worker.request_batch import DiffusionRequestBatch
from vllm_omni.diffusion.worker.utils import StepRequestState
from vllm_omni.experimental.ar_diffusion import ARDiffusionChunkMetadata
from vllm_omni.experimental.ar_diffusion.capability import (
    ARDiffusionCrossAttentionKVSpec,
    ARDiffusionKVBranchSpec,
    ARDiffusionKVCacheSpec,
)
from vllm_omni.experimental.ar_diffusion.streaming_decode import StreamingDecodeState, WanStreamingDecoder

from .abot_world_transformer import (
    ABotAttentionCache,
    ABotTransformerCache,
    ABotWorldCausalTransformer3DModel,
)
from .actions import CAMERA_ACTION_SCRIPT_KEY, PREPROCESSED_CAMERA_ACTION_SCRIPT_KEY
from .interaction import ABotCameraSession
from .taew2_2 import TAEW2Decoder

if TYPE_CHECKING:
    from tqdm.std import tqdm as TqdmProgressBar

    from vllm_omni.experimental.ar_diffusion.kv_cache.state import (
        ARDiffusionKVState,
    )

ABOT_DMD_TIMESTEPS = (1000, 750, 500, 250)
_WINDOW_FRAMES = 21
_MAX_RAW_FRAMES = 117
_MAX_SEQUENCE_LENGTH = 512
_REFERENCE_RESOLUTION = 512
_MAX_SOURCE_IMAGE_PIXELS = 4096 * 4096
_DEFAULT_HEIGHT = 512
_DEFAULT_WIDTH = 832
_PAGED_KV_BLOCK_ALIGNMENT = 16
_SOURCE_IMAGE_ERROR = (
    "Unable to load multi_modal_data.image; expected a decodable image within 4096 * 4096 source pixels."
)
_ACTION_CONTROL_DIM = 32


def _wan_decode_cache_bytes(decoder: nn.Module, height: int, width: int, dtype: torch.dtype) -> int:
    """Bound Wan2.2 causal features without allocating or running the decoder.

    Every cached convolution input retains at most two temporal slices. Count
    residual inputs at their own spatial stage, not decoder weights or outputs.
    This is checked against real streaming state in the two-session benchmark.
    """
    area = height * width
    elements = decoder.conv_in.in_channels * area
    for resnet in decoder.mid_block.resnets:
        elements += (resnet.conv1.in_channels + resnet.conv2.in_channels) * area
    for block in decoder.up_blocks:
        for resnet in block.resnets:
            elements += (resnet.conv1.in_channels + resnet.conv2.in_channels) * area
        if block.upsampler is not None:
            if block.upsampler.mode == "upsample3d":
                elements += block.upsampler.time_conv.in_channels * area
            area *= 4
    elements += decoder.conv_out.in_channels * area
    # CUDA autocast can retain FP32 normalized activations even when the VAE
    # weights are BF16. Admission must budget those features, not weight dtype.
    return 2 * elements * max(dtype.itemsize, torch.float32.itemsize)


def _paged_kv_tokens_per_frame(
    height: int,
    width: int,
    *,
    vae_scale_factor: int,
    patch_height: int,
    patch_width: int,
) -> int:
    """Return one frame's DiT token count and enforce FA page alignment."""
    divisor_h = vae_scale_factor * patch_height
    divisor_w = vae_scale_factor * patch_width
    if height % divisor_h or width % divisor_w:
        raise ValueError(
            "height/width must align with the VAE and DiT patch sizes: "
            f"height must be divisible by {divisor_h}, width by {divisor_w}."
        )
    tokens_per_frame = (height // divisor_h) * (width // divisor_w)
    if tokens_per_frame % _PAGED_KV_BLOCK_ALIGNMENT:
        raise ValueError(
            "ABot FlashAttention paged KV requires tokens_per_frame to be a "
            f"multiple of {_PAGED_KV_BLOCK_ALIGNMENT}, got {tokens_per_frame} "
            f"for {height}x{width}. Use 512x832 for the bundled Wan2.2 VAE."
        )
    return tokens_per_frame


def _validate_latent_channel_contract(
    *,
    vae_z_dim: int,
    transformer_in_channels: int,
    transformer_out_channels: int,
) -> None:
    """Reject a Wan VAE/DiT mismatch before the first expensive forward."""
    if vae_z_dim != transformer_in_channels or vae_z_dim != transformer_out_channels:
        raise ValueError(
            "ABot latent channel mismatch: "
            f"VAE z_dim={vae_z_dim}, transformer in/out="
            f"{transformer_in_channels}/{transformer_out_channels}. "
            "ABot-World-0-5B-LF requires the 48-channel Wan2.2 TI2V-5B VAE."
        )


def _validate_latent_tensor(
    latent: torch.Tensor,
    *,
    expected_channels: int,
    source: str,
) -> None:
    if latent.ndim != 5:
        raise RuntimeError(
            f"{source} must produce [batch, channels, frames, height, width], got shape {tuple(latent.shape)}."
        )
    if latent.shape[1] != expected_channels:
        raise RuntimeError(
            f"{source} produced {latent.shape[1]} latent channels, expected "
            f"{expected_channels} for ABot-World-0-5B-LF. Verify that "
            "Wan2.2_VAE.pth is the TI2V-5B 48-channel checkpoint."
        )


@dataclass(frozen=True)
class _ABotRequestInputs:
    prompt: str
    image: PIL.Image.Image | torch.Tensor
    reference_images: tuple[PIL.Image.Image | torch.Tensor, ...] | None
    camera_action_script: tuple[tuple[tuple[str, ...], ...], ...] | None
    height: int
    width: int
    num_frames: int
    num_latent_frames: int
    num_frame_per_block: int
    output_type: str
    max_sequence_length: int
    flow_shift: float
    generator: torch.Generator


def _resolve_local_model_path(model: str) -> str:
    """Require an already-downloaded local ABot checkpoint."""

    if not os.path.isdir(model):
        raise FileNotFoundError(
            f"ABot-World requires a local checkpoint directory, got {model!r}. "
            "Download the complete repository first and pass its local path."
        )
    return os.path.abspath(model)


def _validate_local_model_files(model_path: str, *, vae_backend: str = "wan") -> None:
    if vae_backend not in {"wan", "taew2_2"}:
        raise ValueError("abot_vae must be 'wan' or 'taew2_2'.")
    required_files = (
        "config.json",
        "diffusion_pytorch_model.safetensors",
        "models_t5_umt5-xxl-enc-bf16.pth",
        "Wan2.2_VAE.pth",
    )
    if vae_backend == "taew2_2":
        required_files += ("taew2_2.pth",)
    missing = [name for name in required_files if not os.path.isfile(os.path.join(model_path, name))]
    if not os.path.isdir(os.path.join(model_path, "google", "umt5-xxl")):
        missing.append("google/umt5-xxl/")
    if missing:
        raise FileNotFoundError("ABot-World checkpoint is incomplete; missing: " + ", ".join(missing))


def _convert_wan_umt5_encoder_state_dict(
    source: dict[str, torch.Tensor], *, num_layers: int
) -> dict[str, torch.Tensor]:
    """Convert the original Wan T5 encoder names to Transformers UMT5."""

    converted: dict[str, torch.Tensor] = {
        "shared.weight": source["token_embedding.weight"],
        "encoder.embed_tokens.weight": source["token_embedding.weight"],
        "encoder.final_layer_norm.weight": source["norm.weight"],
    }
    consumed = {"token_embedding.weight", "norm.weight"}
    mappings = {
        "norm1.weight": "layer.0.layer_norm.weight",
        "attn.q.weight": "layer.0.SelfAttention.q.weight",
        "attn.k.weight": "layer.0.SelfAttention.k.weight",
        "attn.v.weight": "layer.0.SelfAttention.v.weight",
        "attn.o.weight": "layer.0.SelfAttention.o.weight",
        "pos_embedding.embedding.weight": "layer.0.SelfAttention.relative_attention_bias.weight",
        "norm2.weight": "layer.1.layer_norm.weight",
        "ffn.gate.0.weight": "layer.1.DenseReluDense.wi_0.weight",
        "ffn.fc1.weight": "layer.1.DenseReluDense.wi_1.weight",
        "ffn.fc2.weight": "layer.1.DenseReluDense.wo.weight",
    }
    for index in range(num_layers):
        source_prefix = f"blocks.{index}"
        target_prefix = f"encoder.block.{index}"
        for source_suffix, target_suffix in mappings.items():
            source_name = f"{source_prefix}.{source_suffix}"
            converted[f"{target_prefix}.{target_suffix}"] = source[source_name]
            consumed.add(source_name)
    unexpected = set(source) - consumed
    if unexpected:
        raise KeyError(f"Unexpected keys in Wan UMT5 encoder checkpoint: {sorted(unexpected)[:10]}")
    return converted


def _positive_finite_flow_shift(value: object) -> float:
    if isinstance(value, bool):
        raise ValueError("flow_shift must be a positive finite number.")
    try:
        flow_shift = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("flow_shift must be a positive finite number.") from exc
    if not math.isfinite(flow_shift) or flow_shift <= 0:
        raise ValueError("flow_shift must be a positive finite number.")
    return flow_shift


def _build_shifted_flow_schedule(*, flow_shift: float) -> tuple[tuple[float, float], ...]:
    base_sigmas = torch.tensor(ABOT_DMD_TIMESTEPS, dtype=torch.float64) / 1000
    shifted_numerators = flow_shift * base_sigmas
    shifted_sigmas = shifted_numerators / ((1.0 - base_sigmas) + shifted_numerators)
    warped_timesteps = shifted_sigmas * 1000
    return tuple(
        (float(ts), float(sigma)) for ts, sigma in zip(warped_timesteps.tolist(), shifted_sigmas.tolist(), strict=True)
    )


def _validate_parallel_config(od_config: OmniDiffusionConfig) -> None:
    if not getattr(od_config, "enforce_eager", False):
        warnings.warn(
            "ABot-World realtime requires enforce_eager=True; enforce_eager=False enters the "
            "torch.compiler.cudagraph_mark_step_begin() path and may produce NaNs or black frames. "
            "Enable --enforce-eager.",
            UserWarning,
            stacklevel=2,
        )
    if getattr(od_config, "quantization_config", None) is not None:
        raise NotImplementedError("ABot-World does not support quantization.")
    parallel_config = getattr(od_config, "parallel_config", None)
    if parallel_config is None:
        return
    unsupported = {
        "pipeline_parallel_size": "pipeline parallelism",
        "sequence_parallel_size": "sequence parallelism",
        "cfg_parallel_size": "CFG parallelism",
        "vae_patch_parallel_size": "VAE parallelism",
    }
    for field, feature in unsupported.items():
        size = getattr(parallel_config, field, 1) or 1
        if size > 1:
            raise NotImplementedError(f"ABot-World does not support {feature} ({field}={size}).")


def _decode_source_image(image: PIL.Image.Image) -> PIL.Image.Image:
    try:
        return image.convert("RGB")
    except (OSError, SyntaxError, ValueError, PIL.Image.DecompressionBombError):
        raise ValueError(_SOURCE_IMAGE_ERROR) from None


def _load_source_image(path: str | os.PathLike[str]) -> PIL.Image.Image:
    try:
        source_image = PIL.Image.open(path)
    except (OSError, SyntaxError, ValueError, PIL.Image.DecompressionBombError):
        raise ValueError(_SOURCE_IMAGE_ERROR) from None
    try:
        return _decode_source_image(source_image)
    finally:
        source_image.close()


def get_abot_world_pre_process_func(
    od_config: OmniDiffusionConfig,
) -> Callable[[OmniDiffusionRequest], OmniDiffusionRequest]:
    del od_config

    def pre_process_func(request: OmniDiffusionRequest) -> OmniDiffusionRequest:
        prompt = request.prompt
        if not isinstance(prompt, dict):
            raise ValueError("ABot-World requires a prompt mapping containing multi_modal_data.image.")
        multi_modal_data = prompt.get("multi_modal_data") or {}
        if not isinstance(multi_modal_data, dict):
            raise ValueError("prompt.multi_modal_data must be a mapping.")

        image = multi_modal_data.get("image")
        if image is None:
            raise ValueError("ABot-World requires exactly one image in multi_modal_data.image.")
        if isinstance(image, (str, os.PathLike)):
            image = _load_source_image(image)
        elif isinstance(image, PIL.Image.Image):
            image = _decode_source_image(image)
        elif not isinstance(image, torch.Tensor):
            raise ValueError("multi_modal_data.image must be a PIL image, tensor, or file path.")

        reference_images = multi_modal_data.get("reference_images")
        resolved_refs: list[PIL.Image.Image | torch.Tensor] = []
        if reference_images is not None:
            if not isinstance(reference_images, (list, tuple)):
                raise ValueError("multi_modal_data.reference_images must be a list.")
            for ref in reference_images:
                if isinstance(ref, (str, os.PathLike)):
                    resolved_refs.append(_load_source_image(ref))
                elif isinstance(ref, PIL.Image.Image):
                    resolved_refs.append(_decode_source_image(ref))
                elif isinstance(ref, torch.Tensor):
                    resolved_refs.append(ref)
                else:
                    raise ValueError("Each reference image must be a PIL image, tensor, or file path.")

        extra_args = dict(getattr(request.sampling_params, "extra_args", None) or {})
        camera_action_script = extra_args.get(CAMERA_ACTION_SCRIPT_KEY)
        if camera_action_script is not None:
            from vllm_omni.diffusion.models.abot_world.actions import parse_abot_camera_action_script

            camera_action_script = parse_abot_camera_action_script(camera_action_script)
        updated_prompt = dict(prompt)
        updated_mmd = dict(multi_modal_data)
        updated_mmd["image"] = image
        if resolved_refs:
            updated_mmd["reference_images"] = tuple(resolved_refs)
        updated_prompt["multi_modal_data"] = updated_mmd
        request.prompt = updated_prompt
        extra_args[PREPROCESSED_CAMERA_ACTION_SCRIPT_KEY] = camera_action_script
        request.sampling_params.extra_args = extra_args
        return request

    return pre_process_func


def get_abot_world_post_process_func(od_config: OmniDiffusionConfig) -> Callable[..., Any]:
    del od_config
    from diffusers.video_processor import VideoProcessor

    video_processor = VideoProcessor(vae_scale_factor=16)

    def post_process_func(video, output_type="np", sampling_params=None):
        if isinstance(video, dict) and isinstance(video.get("payload"), dict):
            return video
        if sampling_params is not None:
            output_type = getattr(sampling_params, "output_type", None) or output_type
        if output_type == "latent":
            return video
        return {
            "payload": {"video": video_processor.postprocess_video(video, output_type=output_type)},
            "metadata": {},
        }

    return post_process_func


class ABotWorldCausalPipeline(
    nn.Module,
    SupportImageInput,
    SupportsComponentDiscovery,
    ProgressBarMixin,
    DiffusionPipelineProfilerMixin,
    InteractionMixin,
):
    """ABot-World I2V causal DMD pipeline."""

    _dit_modules: ClassVar[list[str]] = ["transformer"]
    _encoder_modules: ClassVar[list[str]] = ["text_encoder"]
    _module_offload: bool = False
    _vae_modules: ClassVar[list[str]] = ["vae"]
    dummy_run_num_frames: ClassVar[int] = 0
    _AR_BRANCH = "main"
    _AR_TEXT_CACHE = "text"
    supports_step_execution: ClassVar[bool] = True
    _PROFILER_TARGETS = [
        "prepare_encode",
        "denoise_step",
        "_commit_stepwise_kv",
        "_decode_realtime_chunk",
    ]

    def __init__(self, *, od_config: OmniDiffusionConfig, prefix: str = "") -> None:
        super().__init__()
        del prefix
        _validate_parallel_config(od_config)
        self.od_config = od_config
        self.device = get_local_device()
        dtype = getattr(od_config, "dtype", torch.bfloat16)
        model = od_config.model
        model_path = _resolve_local_model_path(model)
        model_config = getattr(od_config, "model_config", None) or {}
        self._vae_backend = model_config.get("abot_vae", "wan")
        _validate_local_model_files(model_path, vae_backend=self._vae_backend)
        managed_offload = offload_enabled(od_config)
        self._module_offload = resolve_offload(od_config).strategy is OffloadStrategy.MODEL_LEVEL

        self.weights_sources = [
            DiffusersPipelineLoader.ComponentSource(
                model_or_path=model_path,
                subfolder="",
                revision=None,
                prefix="transformer.",
                fall_back_to_pt=True,
            )
        ]

        # Tokenizer from bundled google/umt5-xxl (no HF fallback)
        tokenizer_path = os.path.join(model_path, "google", "umt5-xxl")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)

        # Text encoder
        self.text_encoder = self._load_text_encoder(model_path, dtype)
        if not managed_offload:
            self.text_encoder = self.text_encoder.to(self.device)

        # Both decoders use the original Wan image encoder and latent contract.
        self.vae_encoder = self._load_vae(model_path, dtype)
        if self._vae_backend == "taew2_2":
            self.vae = TAEW2Decoder(os.path.join(model_path, "taew2_2.pth"), dtype).to(self.device)
            self._streaming_decoder = self.vae
        else:
            self.vae = self.vae_encoder.to(self.device)
            self._streaming_decoder = WanStreamingDecoder(self.vae)
        self._streaming_decode_states: dict[str, StreamingDecodeState] = {}

        # Custom causal transformer
        self.transformer = self._create_transformer(model_path)

        _validate_latent_channel_contract(
            vae_z_dim=int(self.vae.config.z_dim),
            transformer_in_channels=int(self.transformer.config.in_channels),
            transformer_out_channels=int(self.transformer.config.out_channels),
        )

        self.vae_scale_factor_temporal = int(getattr(self.vae.config, "scale_factor_temporal", 4))
        self.vae_scale_factor_spatial = int(getattr(self.vae.config, "scale_factor_spatial", 16))
        self._num_frame_per_block = 3

        model_config = getattr(od_config, "model_config", None) or {}
        self._ar_height = int(model_config.get("ar_diffusion_height", _DEFAULT_HEIGHT))
        self._ar_width = int(model_config.get("ar_diffusion_width", _DEFAULT_WIDTH))
        self._ar_diffusion_kv_state: ARDiffusionKVState | None = None

        self.setup_diffusion_pipeline_profiler(
            profiler_targets=[
                "vae_encoder.encode",
                "_decode_realtime_chunk",
                "_generate_block",
                "text_encoder.forward",
                "tokenizer.forward",
            ],
            enable_diffusion_pipeline_profiler=od_config.enable_diffusion_pipeline_profiler,
        )

    def _load_text_encoder(self, model: str, dtype: torch.dtype) -> UMT5EncoderModel:
        encoder_pth = os.path.join(model, "models_t5_umt5-xxl-enc-bf16.pth")

        # Match the original Wan UMT5-XXL encoder checkpoint exactly.
        config = UMT5Config(
            d_model=4096,
            d_kv=64,
            d_ff=10240,
            num_layers=24,
            num_decoder_layers=24,
            num_heads=64,
            relative_attention_num_buckets=32,
            relative_attention_max_distance=128,
            dropout_rate=0.1,
            layer_norm_epsilon=1e-06,
            feed_forward_proj="gated-gelu",
            is_encoder_decoder=True,
            pad_token_id=0,
            eos_token_id=1,
            vocab_size=256384,
            tie_word_embeddings=False,
            scalable_attention=True,
        )

        if not os.path.isfile(encoder_pth):
            raise FileNotFoundError(f"UMT5 encoder checkpoint not found at {encoder_pth}")
        source = torch.load(encoder_pth, map_location="cpu", weights_only=True)
        if isinstance(source, dict) and isinstance(source.get("state_dict"), dict):
            source = source["state_dict"]
        converted = _convert_wan_umt5_encoder_state_dict(source, num_layers=config.num_layers)
        with torch.device("meta"):
            text_encoder = UMT5EncoderModel(config)
        text_encoder.load_state_dict(converted, strict=True, assign=True)
        return text_encoder.to(dtype=dtype)

    def _load_vae(self, model: str, dtype: torch.dtype) -> DistributedAutoencoderKLWan:
        # Load Wan2.2 VAE from bundled .pth (no HF fallback).
        vae_pth = os.path.join(model, "Wan2.2_VAE.pth")
        if os.path.isfile(vae_pth):
            return self._load_vae_from_local_pth(vae_pth, dtype)
        raise FileNotFoundError(f"Wan2.2_VAE.pth not found at {vae_pth}")

    @staticmethod
    def _load_vae_from_local_pth(vae_pth: str, dtype: torch.dtype) -> DistributedAutoencoderKLWan:
        state_dict = torch.load(vae_pth, map_location="cpu", weights_only=True)
        if isinstance(state_dict, dict) and isinstance(state_dict.get("state_dict"), dict):
            state_dict = state_dict["state_dict"]
        vae = DistributedAutoencoderKLWan.from_wan22_state_dict(state_dict).to(dtype=dtype)
        vae.init_distributed()
        return vae

    def _create_transformer(self, model: str) -> ABotWorldCausalTransformer3DModel:
        import json

        config_path = os.path.join(model, "config.json")
        if os.path.isfile(config_path):
            with open(config_path) as f:
                raw_config = json.load(f)
        else:
            raise FileNotFoundError(f"ABot-World config.json not found at {config_path}")
        return ABotWorldCausalTransformer3DModel.from_config(raw_config)

    # ── SupportsARDiffusionPipeline ──────────────────────────────────────

    def ar_diffusion_kv_cache_spec(self) -> ARDiffusionKVCacheSpec:
        cfg = self.transformer.config
        patch_h, patch_w = cfg.patch_size[1], cfg.patch_size[2]
        spatial = self.vae_scale_factor_spatial
        latent_h, latent_w = self._ar_height // spatial, self._ar_width // spatial
        tokens_per_frame = _paged_kv_tokens_per_frame(
            self._ar_height,
            self._ar_width,
            vae_scale_factor=spatial,
            patch_height=patch_h,
            patch_width=patch_w,
        )
        tp_size = get_tensor_model_parallel_world_size()
        num_local_heads = int(cfg.num_attention_heads) // tp_size

        horizon = (_MAX_RAW_FRAMES - 1) // self.vae_scale_factor_temporal + 1
        condition_bytes = (
            int(cfg.out_channels)
            * horizon
            * latent_h
            * latent_w
            * torch.empty((), dtype=self.transformer.dtype).element_size()
        )
        if self._vae_backend == "taew2_2":
            vae_cache_bytes = TAEW2Decoder.persistent_state_bytes(latent_h, latent_w, self.vae.dtype)
        else:
            vae_cache_bytes = _wan_decode_cache_bytes(self.vae.decoder, latent_h, latent_w, self.vae.dtype)
        # Stepwise state also retains prompt embeddings and the current action
        # tensor. They are outside the runner-owned self/cross-attention KV pools.
        condition_bytes += _MAX_SEQUENCE_LENGTH * int(cfg.text_dim) * self.transformer.dtype.itemsize
        condition_bytes += (
            _ACTION_CONTROL_DIM
            * self._num_frame_per_block
            * self._ar_height
            * self._ar_width
            * self.transformer.dtype.itemsize
        )
        return ARDiffusionKVCacheSpec(
            num_layers=int(cfg.num_layers),
            num_kv_heads=num_local_heads,
            head_size=int(cfg.attention_head_dim),
            tokens_per_frame=tokens_per_frame,
            frames_per_block=self._num_frame_per_block,
            window_frames=_WINDOW_FRAMES,
            sink_frames=0,
            kv_branches=(ARDiffusionKVBranchSpec(self._AR_BRANCH, 0),),
            session_capacity=2,
            cross_attention=(ARDiffusionCrossAttentionKVSpec(self._AR_TEXT_CACHE, _MAX_SEQUENCE_LENGTH),),
            model_owned_state_bytes_per_session=condition_bytes + vae_cache_bytes,
        )

    @contextmanager
    def bind_ar_diffusion_state(self, session_id: str, state: ARDiffusionKVState) -> Iterator[None]:
        if self._ar_diffusion_kv_state is not None:
            raise RuntimeError("ABot AR-Diffusion state is already bound.")
        if state.session_id != session_id:
            raise ValueError(f"Session mismatch: {state.session_id!r} != {session_id!r}.")
        self._ar_diffusion_kv_state = state
        try:
            yield
        finally:
            self._ar_diffusion_kv_state = None

    def reset_ar_diffusion_session(self, session_id: str) -> None:
        self.close_ar_diffusion_session(session_id)

    def close_ar_diffusion_session(self, session_id: str) -> None:
        state = self._streaming_decode_states.pop(session_id, None)
        if state is not None:
            state.release()

    # ── Request parsing ──────────────────────────────────────────────────

    def _parse_request(self, req: DiffusionRequestBatch) -> _ABotRequestInputs:
        if req.num_reqs != 1:
            raise ValueError("ABot-World supports a single prompt request.")
        sampling = req.sampling_params
        generator = getattr(sampling, "generator", None)
        if not isinstance(generator, torch.Generator):
            raise ValueError("ABot-World requires the runner-provided torch.Generator.")

        prompt_value = req.prompts[0]
        multi_modal_data: dict[str, Any]
        if isinstance(prompt_value, dict):
            prompt = prompt_value.get("prompt") or ""
            multi_modal_data = prompt_value.get("multi_modal_data") or {}
        else:
            prompt = str(prompt_value)
            multi_modal_data = {}

        image = multi_modal_data.get("image")
        if isinstance(image, (str, os.PathLike)):
            raise ValueError("file-path images must be materialized by pre-process.")
        if not isinstance(image, (PIL.Image.Image, torch.Tensor)):
            raise ValueError("multi_modal_data.image must be a PIL image or tensor.")
        if isinstance(image, PIL.Image.Image):
            source_width, source_height = image.size
        elif image.ndim == 3 and image.shape[0] == 3:
            source_height, source_width = image.shape[-2:]
        elif image.ndim == 4 and image.shape[:2] == (1, 3):
            source_height, source_width = image.shape[-2:]
        else:
            raise ValueError("tensor image must have shape [3, height, width] or [1, 3, height, width].")
        if source_height <= 0 or source_width <= 0:
            raise ValueError("source image dimensions must be positive.")
        if source_height * source_width > _MAX_SOURCE_IMAGE_PIXELS:
            raise ValueError("source image pixel count must not exceed 4096 * 4096.")

        ref_raw = multi_modal_data.get("reference_images")
        reference_images: tuple[PIL.Image.Image | torch.Tensor, ...] | None = None
        if ref_raw is not None:
            resolved = []
            for r in ref_raw:
                if isinstance(r, (str, os.PathLike)):
                    raise ValueError("file-path reference images must be materialized by pre-process.")
                resolved.append(r)
            reference_images = tuple(resolved)
        if reference_images:
            raise NotImplementedError(
                "ABot-World reference_images conditioning is not implemented; provide only multi_modal_data.image."
            )

        extra_args = getattr(sampling, "extra_args", None) or {}
        camera_action_script = extra_args.get(PREPROCESSED_CAMERA_ACTION_SCRIPT_KEY)
        flow_shift = _positive_finite_flow_shift(extra_args.get("flow_shift", 5.0))

        height = getattr(sampling, "height", None) or _DEFAULT_HEIGHT
        width = getattr(sampling, "width", None) or _DEFAULT_WIDTH
        if isinstance(height, bool) or not isinstance(height, int) or height <= 0:
            raise ValueError(f"height must be a positive integer, got {height!r}.")
        if isinstance(width, bool) or not isinstance(width, int) or width <= 0:
            raise ValueError(f"width must be a positive integer, got {width!r}.")
        patch_size = tuple(self.transformer.config.patch_size)
        _paged_kv_tokens_per_frame(
            height,
            width,
            vae_scale_factor=self.vae_scale_factor_spatial,
            patch_height=patch_size[1],
            patch_width=patch_size[2],
        )

        num_frames = getattr(sampling, "num_frames", None) or 9
        if isinstance(num_frames, bool) or not isinstance(num_frames, int) or num_frames <= 0:
            raise ValueError(f"num_frames must be a positive integer, got {num_frames!r}.")
        if num_frames > _MAX_RAW_FRAMES and not bool(getattr(self.od_config, "step_execution", False)):
            raise ValueError(f"num_frames must not exceed {_MAX_RAW_FRAMES}.")
        if (num_frames - 1) % self.vae_scale_factor_temporal:
            raise ValueError(f"(num_frames - 1) must be divisible by {self.vae_scale_factor_temporal}.")
        num_latent_frames = (num_frames - 1) // self.vae_scale_factor_temporal + 1
        rope_max_seq_len = int(getattr(self.transformer.config, "rope_max_seq_len", num_latent_frames))
        if num_latent_frames > rope_max_seq_len:
            raise ValueError(f"num_latent_frames must not exceed RoPE horizon {rope_max_seq_len}.")
        if num_latent_frames % self._num_frame_per_block:
            raise ValueError(
                f"num_latent_frames ({num_latent_frames}) must be divisible by {self._num_frame_per_block}."
            )

        max_sequence_length = getattr(sampling, "max_sequence_length", None) or _MAX_SEQUENCE_LENGTH
        if max_sequence_length != _MAX_SEQUENCE_LENGTH:
            raise ValueError(f"max_sequence_length must be exactly {_MAX_SEQUENCE_LENGTH}.")
        output_type = getattr(sampling, "output_type", None) or "np"
        if output_type not in {"latent", "np", "pt", "pil"}:
            raise ValueError("output_type must be one of 'latent', 'np', 'pt', or 'pil'.")

        return _ABotRequestInputs(
            prompt=prompt.strip(),
            image=image,
            reference_images=reference_images,
            camera_action_script=camera_action_script,
            height=height,
            width=width,
            num_frames=num_frames,
            num_latent_frames=num_latent_frames,
            num_frame_per_block=self._num_frame_per_block,
            output_type=output_type,
            max_sequence_length=max_sequence_length,
            flow_shift=flow_shift,
            generator=generator,
        )

    # ── Image / VAE helpers ──────────────────────────────────────────────

    def _prepare_image_tensor(self, image: PIL.Image.Image | torch.Tensor, *, height: int, width: int) -> torch.Tensor:
        if isinstance(image, PIL.Image.Image):
            image = PIL.ImageOps.fit(
                image.convert("RGB"),
                (width, height),
                method=PIL.Image.Resampling.LANCZOS,
            )
            arr = np.asarray(image, dtype=np.float32).copy()
            t = torch.from_numpy(arr).permute(2, 0, 1).unsqueeze(0) / 255.0
        else:
            t = image.detach()
            if t.ndim == 3:
                t = t.unsqueeze(0)
            t = t.to(dtype=torch.float32)
            if not torch.isfinite(t).all():
                raise ValueError("tensor image values must all be finite.")
            if t.max() > 1.0:
                t = t / 255.0
        if t.min() >= 0.0:
            t = t * 2.0 - 1.0
        if t.shape[-2:] != (height, width):
            t = F.interpolate(t, size=(height, width), mode="bicubic", align_corners=False)
        return t.to(device=self.device, dtype=torch.float32)

    def _vae_latent_stats(self, ref: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        shape = (1, -1, 1, 1, 1)
        mean_val = self.vae_encoder.config.latents_mean
        std_val = self.vae_encoder.config.latents_std
        if mean_val is None or std_val is None:
            return (
                torch.as_tensor(0.0, device=ref.device, dtype=ref.dtype),
                torch.as_tensor(1.0, device=ref.device, dtype=ref.dtype),
            )
        mean = torch.as_tensor(mean_val, device=ref.device, dtype=ref.dtype).view(*shape)
        std = torch.as_tensor(std_val, device=ref.device, dtype=ref.dtype).view(*shape)
        return mean, std

    def _decode_realtime_chunk(
        self,
        latents: torch.Tensor,
        cache: StreamingDecodeState | None,
    ) -> tuple[torch.Tensor, StreamingDecodeState]:
        """Decode one ABot chunk while keeping causal VAE state in the session."""
        decoder = self._streaming_decoder
        if cache is None:
            cache = decoder.new_decode_state("offline")
        if self._vae_backend == "wan":
            mean, std = self._vae_latent_stats(latents)
            latents = latents * std + mean
        try:
            return decoder.decode_chunk(latents.to(dtype=self.vae.dtype), cache), cache
        except Exception:
            cache.release()
            raise

    def _decode_session_chunk(self, latents: torch.Tensor, session_id: str) -> torch.Tensor:
        cache = self._streaming_decode_states.get(session_id)
        if cache is None:
            cache = self._streaming_decoder.new_decode_state(session_id)
            self._streaming_decode_states[session_id] = cache
        try:
            frames, _ = self._decode_realtime_chunk(latents, cache)
            return frames
        except Exception:
            self._streaming_decode_states.pop(session_id, None)
            raise

    @staticmethod
    def _format_video(frames: torch.Tensor, output_type: str) -> Any:
        from diffusers.video_processor import VideoProcessor

        return VideoProcessor(vae_scale_factor=16).postprocess_video(frames, output_type=output_type)

    def _encode_first_frame(
        self, image: PIL.Image.Image | torch.Tensor, height: int, width: int, dtype: torch.dtype
    ) -> torch.Tensor:
        """VAE-encode the first frame image into a single 48-channel latent frame."""
        img = self._prepare_image_tensor(image, height=height, width=width)
        video = img.unsqueeze(2)  # [1, 3, 1, H, W]
        self.vae_encoder.to(self.device)
        try:
            latent = retrieve_latents(
                self.vae_encoder.encode(video.to(dtype=self.vae_encoder.dtype)),
                sample_mode="argmax",
            )
        finally:
            if self._vae_backend == "taew2_2":
                self.vae_encoder.to("cpu")
                torch.accelerator.empty_cache()
        _validate_latent_tensor(
            latent,
            expected_channels=int(self.transformer.config.in_channels),
            source="Wan2.2 VAE encode",
        )
        mean, std = self._vae_latent_stats(latent)
        return ((latent - mean) / std).to(dtype=dtype)

    def _build_action_tensor(
        self,
        camera_actions: tuple[tuple[str, ...], ...] | None,
        num_latent_frames: int,
        height: int,
        width: int,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        """Build [1, 32, num_latent_frames, height, width] action tensor."""
        action_keys = ("w", "a", "s", "d", "i", "j", "k", "l")
        t = torch.zeros(1, num_latent_frames, len(action_keys), device=self.device, dtype=dtype)
        if camera_actions is not None:
            for fi, actions in enumerate(camera_actions):
                if fi >= num_latent_frames:
                    break
                for a in actions:
                    if a in action_keys:
                        t[0, fi, action_keys.index(a)] = 1.0
        # [1, F, 8] → [1, F, 1, 1, 8] → broadcast to [1, F, height, width, 8]
        t = t.unsqueeze(2).unsqueeze(2).expand(-1, -1, height, width, -1)
        # Permute to [1, 8, F, H, W], then repeat_interleave to get 32 channels
        t = t.permute(0, 4, 1, 2, 3).contiguous()  # [1, 8, F, H, W]
        t = t.repeat_interleave(4, dim=1)  # [1, 32, F, H, W]
        return t.to(dtype=dtype)

    def encode_prompt(self, prompt: str, *, max_sequence_length: int, dtype: torch.dtype) -> torch.Tensor:
        text_inputs = self.tokenizer(
            [" ".join(prompt.strip().split())],
            padding="max_length",
            max_length=max_sequence_length,
            truncation=True,
            add_special_tokens=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        input_ids = text_inputs.input_ids.to(self.device)
        attention_mask = text_inputs.attention_mask.to(self.device)
        embeds = self.text_encoder(input_ids, attention_mask).last_hidden_state
        embeds = embeds.to(device=self.device, dtype=dtype)
        return embeds * attention_mask.unsqueeze(-1).to(dtype=embeds.dtype)

    # ── Generation ───────────────────────────────────────────────────────

    def _ar_text_caches(
        self,
        prompt_embeds: torch.Tensor,
        *,
        invalidate: bool,
    ) -> list[ABotAttentionCache]:
        state = self._ar_diffusion_kv_state
        if state is None:
            raise RuntimeError("ABot AR text cache requested without a bound state.")
        if invalidate:
            state.clear_cross_attention()
        if not state.is_cross_attention_populated(self._AR_BRANCH, self._AR_TEXT_CACHE):
            # These projections bypass transformer.forward and its offload hook.
            residency = sequential_offload_component(self.transformer) if self._module_offload else nullcontext()
            with residency:
                projected_text = self.transformer.text_embedding(prompt_embeds)

                def layer_kv() -> Iterator[tuple[torch.Tensor, torch.Tensor]]:
                    for block in self.transformer.blocks:
                        cross_attention = block.cross_attn
                        key = cross_attention.norm_k(cross_attention.k(projected_text)).unflatten(
                            2,
                            (cross_attention.num_local_heads, cross_attention.head_dim),
                        )
                        value = cross_attention.v(projected_text).unflatten(
                            2,
                            (cross_attention.num_local_heads, cross_attention.head_dim),
                        )
                        yield key, value

                state.populate_cross_attention(self._AR_BRANCH, self._AR_TEXT_CACHE, layer_kv())
        return [
            ABotAttentionCache(
                key=layer["k"],
                value=layer["v"],
                end=prompt_embeds.shape[1],
                absolute_end=prompt_embeds.shape[1],
                last_start=0,
            )
            for layer in state.get_cross_attention_kv(self._AR_BRANCH, self._AR_TEXT_CACHE)
        ]

    def _ar_transformer_cache(
        self,
        *,
        latent: torch.Tensor,
        cross_attention: list[ABotAttentionCache],
        commit_current: bool,
    ) -> ABotTransformerCache:
        state = self._ar_diffusion_kv_state
        if state is None:
            raise RuntimeError("ABot AR cache requested without a bound state.")
        patch_frames, patch_height, patch_width = self.transformer.config.patch_size
        seq_len = (
            (latent.shape[2] // patch_frames) * (latent.shape[3] // patch_height) * (latent.shape[4] // patch_width)
        )
        return ABotTransformerCache(
            self_attention=state.get_kv_caches(
                self._AR_BRANCH,
                seq_len=seq_len,
                commit_current=commit_current,
            ),
            cross_attention=cross_attention,
        )

    def _generate_block(
        self,
        *,
        noise_latent: torch.Tensor,
        prompt_embeds: torch.Tensor,
        first_frame_latent: torch.Tensor | None,
        action_condition: torch.Tensor | None,
        start_frame: int,
        schedule: tuple[tuple[float, float], ...],
        generator: torch.Generator,
        cache: ABotTransformerCache | None,
        ar_cross_attention: list[ABotAttentionCache] | None,
        progress_bar: TqdmProgressBar[Any],
    ) -> torch.Tensor:
        out_channels = int(self.transformer.config.out_channels)
        current_latents = noise_latent
        replace_first = start_frame == 0 and first_frame_latent is not None

        for step_idx, (ts_val, sigma) in enumerate(schedule):
            if not self.od_config.enforce_eager:
                torch.compiler.cudagraph_mark_step_begin()
            set_forward_context_denoise_step_idx(step_idx)
            timestep = torch.full(
                (1, current_latents.shape[2]),
                float(ts_val),
                device=self.device,
                dtype=torch.float32,
            )
            if replace_first:
                timestep[:, 0] = 0

            # Replace first frame with clean latent at every DMD step
            if replace_first:
                current_latents[:, :, 0] = first_frame_latent[:, :, 0]

            current_cache = (
                self._ar_transformer_cache(
                    latent=current_latents,
                    cross_attention=cast(list[ABotAttentionCache], ar_cross_attention),
                    commit_current=False,
                )
                if ar_cross_attention is not None
                else cast(ABotTransformerCache, cache)
            )
            flow_pred = self.transformer(
                hidden_states=current_latents.to(dtype=self.transformer.dtype),
                timestep=timestep,
                encoder_hidden_states=prompt_embeds,
                cache=current_cache,
                start_frame=start_frame,
                update_cache=False,
                action_condition=action_condition,
            )
            flow_pred = flow_pred[:, :out_channels]

            x0 = current_latents - sigma * flow_pred.float()
            if step_idx + 1 < len(schedule):
                next_sigma = schedule[step_idx + 1][1]
                noise = randn_tensor(
                    current_latents.shape, generator=generator, device=self.device, dtype=torch.float32
                )
                current_latents = (1.0 - next_sigma) * x0 + next_sigma * noise
            else:
                current_latents = x0
            progress_bar.update()

        if replace_first:
            current_latents[:, :, 0] = first_frame_latent[:, :, 0]

        # Commit clean latents to KV cache (context_noise=0)
        commit_timestep = torch.zeros((1, current_latents.shape[2]), device=self.device, dtype=torch.float32)
        commit_cache = (
            self._ar_transformer_cache(
                latent=current_latents,
                cross_attention=cast(list[ABotAttentionCache], ar_cross_attention),
                commit_current=True,
            )
            if ar_cross_attention is not None
            else cast(ABotTransformerCache, cache)
        )
        _ = self.transformer(
            hidden_states=current_latents.to(dtype=self.transformer.dtype),
            timestep=commit_timestep,
            encoder_hidden_states=prompt_embeds,
            cache=commit_cache,
            start_frame=start_frame,
            update_cache=True,
            action_condition=action_condition,
        )
        if ar_cross_attention is not None:
            state = self._ar_diffusion_kv_state
            if state is None:
                raise RuntimeError("ABot AR state disappeared before KV commit.")
            state.commit_paged_context(self._AR_BRANCH)
        return current_latents

    def _require_bound_ar_state(self) -> None:
        if self._ar_diffusion_kv_state is None:
            raise RuntimeError("ABot step execution requires AR-Diffusion session binding.")

    def prepare_encode(self, state: StepRequestState, **kwargs: Any) -> StepRequestState:
        del kwargs
        self._require_bound_ar_state()
        req = DiffusionRequestBatch(
            requests=[
                OmniDiffusionRequest(
                    prompt=state.prompt,
                    sampling_params=state.sampling,
                    request_id=state.request_id,
                )
            ]
        )
        inputs = self._parse_request(req)
        if (inputs.height, inputs.width) != (self._ar_height, self._ar_width):
            raise ValueError("ABot stepwise resolution must match the fixed AR cache geometry.")
        total_chunks = inputs.num_latent_frames // inputs.num_frame_per_block
        if inputs.camera_action_script is not None and len(inputs.camera_action_script) != total_chunks:
            raise ValueError(
                "camera_action_script must contain one action chunk per generated chunk; "
                f"got {len(inputs.camera_action_script)} for {total_chunks} chunks."
            )
        dtype = self.transformer.dtype
        prompt_embeds = self.encode_prompt(inputs.prompt, max_sequence_length=inputs.max_sequence_length, dtype=dtype)
        state.prompt_embeds = prompt_embeds
        state.chunk_index = 0
        state.step_index = 0
        state.step_in_chunk = 0
        state.total_chunks = total_chunks
        state.chunk_num_steps = len(ABOT_DMD_TIMESTEPS)
        state.extra = {
            "inputs": inputs,
            "first_frame_latent": self._encode_first_frame(inputs.image, inputs.height, inputs.width, dtype),
            "schedule": _build_shifted_flow_schedule(flow_shift=inputs.flow_shift),
            "dtype": dtype,
        }
        self._ar_text_caches(prompt_embeds, invalidate=False)
        return state

    def _prepare_next_chunk(self, state: StepRequestState) -> None:
        inputs: _ABotRequestInputs = state.extra["inputs"]
        block_frames = inputs.num_frame_per_block
        start_frame = state.chunk_index * block_frames
        camera = state.interaction_sessions.get("camera")
        live_actions = camera.chunk_actions if isinstance(camera, ABotCameraSession) else None
        if inputs.camera_action_script is not None:
            if live_actions is not None:
                raise ValueError("Cannot use mid-generation camera interaction together with camera_action_script.")
            actions = inputs.camera_action_script[state.chunk_index]
        else:
            actions = live_actions
        state.extra["start_frame"] = start_frame
        state.extra["action_condition"] = self._build_action_tensor(
            actions, block_frames, inputs.height, inputs.width, state.extra["dtype"]
        )
        state.extra["ar_cross_attention"] = self._ar_text_caches(
            cast(torch.Tensor, state.prompt_embeds),
            invalidate=False,
        )
        latent_h = inputs.height // self.vae_scale_factor_spatial
        latent_w = inputs.width // self.vae_scale_factor_spatial
        state.latents = randn_tensor(
            (1, int(self.transformer.config.out_channels), block_frames, latent_h, latent_w),
            generator=inputs.generator,
            device=self.device,
            dtype=torch.float32,
        )
        state.timesteps = torch.tensor(
            [timestep for timestep, _ in state.extra["schedule"]], device=self.device, dtype=torch.float32
        )
        state.step_in_chunk = 0
        state.step_index = 0

    def denoise_step(
        self,
        input_batch: InputBatch,
        *,
        states: Sequence[StepRequestState] | None = None,
        **kwargs: Any,
    ) -> torch.Tensor | None:
        del input_batch, kwargs
        if states is None or len(states) != 1:
            raise ValueError("ABot step execution supports exactly one request.")
        self._require_bound_ar_state()
        state = states[0]
        latents = state.latents
        if latents is None:
            raise RuntimeError("ABot step execution requires prepared latents.")
        step = state.step_in_chunk
        ts_val, sigma = state.extra["schedule"][step]
        start_frame = int(state.extra["start_frame"])
        if start_frame == 0:
            latents[:, :, 0] = state.extra["first_frame_latent"][:, :, 0]
        set_forward_context_denoise_step_idx(step)
        timestep = torch.full((1, latents.shape[2]), ts_val, device=self.device, dtype=torch.float32)
        if start_frame == 0:
            timestep[:, 0] = 0
        cache = self._ar_transformer_cache(
            latent=latents,
            cross_attention=state.extra["ar_cross_attention"],
            commit_current=False,
        )
        flow_pred = self.transformer(
            hidden_states=latents.to(dtype=self.transformer.dtype),
            timestep=timestep,
            encoder_hidden_states=state.prompt_embeds,
            cache=cache,
            start_frame=start_frame,
            update_cache=False,
            action_condition=state.extra["action_condition"],
        )
        return flow_pred[:, : int(self.transformer.config.out_channels)]

    def step_scheduler(self, state: StepRequestState, noise_pred: torch.Tensor, **kwargs: Any) -> None:
        del kwargs
        latents = state.latents
        if latents is None:
            raise RuntimeError("ABot step execution requires prepared latents.")
        schedule = state.extra["schedule"]
        step = state.step_in_chunk
        _, sigma = schedule[step]
        x0 = latents - sigma * noise_pred.float()
        if step + 1 < len(schedule):
            next_sigma = schedule[step + 1][1]
            noise = randn_tensor(
                latents.shape,
                generator=state.extra["inputs"].generator,
                device=self.device,
                dtype=torch.float32,
            )
            state.latents = (1.0 - next_sigma) * x0 + next_sigma * noise
        else:
            state.latents = x0
        state.step_in_chunk += 1
        state.step_index = state.step_in_chunk

    def post_decode(self, state: StepRequestState, **kwargs: Any) -> DiffusionOutput:
        del kwargs
        self._require_bound_ar_state()
        latents = state.latents
        if latents is None:
            raise RuntimeError("ABot step execution requires prepared latents.")
        extra = state.extra
        start_frame = int(extra["start_frame"])
        if start_frame == 0:
            latents[:, :, 0] = extra["first_frame_latent"][:, :, 0]
        self._commit_stepwise_kv(state, latents)

        inputs: _ABotRequestInputs = extra["inputs"]
        if inputs.output_type == "latent":
            payload: dict[str, Any] = {"latents": latents}
        else:
            frames = self._decode_session_chunk(latents, state.request_id)
            payload = {"video": self._format_video(frames, inputs.output_type)}
        completed_chunk = state.chunk_index
        state.chunk_index += 1
        finished = state.request_denoise_completed
        return DiffusionOutput(
            output={
                "payload": payload,
                "metadata": {
                    "ar_diffusion": ARDiffusionChunkMetadata(
                        session_id=state.request_id,
                        request_id=state.request_id,
                        chunk_index=completed_chunk,
                    ).to_dict()
                },
            },
            stage_durations=self.stage_durations if hasattr(self, "stage_durations") else None,
            chunk_index=completed_chunk,
            total_chunks=state.total_chunks,
            finished=finished,
        )

    def peek_chunk_media(self, state: StepRequestState) -> ChunkMediaSpec:
        """Expose the next chunk's decoded frame count and latent block size."""
        num_latent_frames = self._num_frame_per_block
        num_media_frames = num_latent_frames * self.vae_scale_factor_temporal
        if state.chunk_index == 0:
            num_media_frames -= self.vae_scale_factor_temporal - 1
        fps = state.sampling.fps
        if fps is None or float(fps) <= 0:
            # Key actions are applied per chunk, not paced against wall-clock frames;
            # a unit chunk duration keeps the media spec valid without sampling.fps.
            fps = float(num_media_frames)
        return ChunkMediaSpec(
            num_media_frames=num_media_frames,
            fps=float(fps),
            num_latent_frames=num_latent_frames,
        )

    def prepare_next_chunk(self, state: StepRequestState) -> None:
        """Prepare the next AR block after chunk-boundary interaction apply."""
        if state.request_denoise_completed:
            return
        self._prepare_next_chunk(state)

    def _commit_stepwise_kv(self, state: StepRequestState, latents: torch.Tensor) -> None:
        extra = state.extra
        start_frame = int(extra["start_frame"])
        commit_cache = self._ar_transformer_cache(
            latent=latents,
            cross_attention=extra["ar_cross_attention"],
            commit_current=True,
        )
        _ = self.transformer(
            hidden_states=latents.to(dtype=self.transformer.dtype),
            timestep=torch.zeros((1, latents.shape[2]), device=self.device, dtype=torch.float32),
            encoder_hidden_states=state.prompt_embeds,
            cache=commit_cache,
            start_frame=start_frame,
            update_cache=True,
            action_condition=extra["action_condition"],
        )
        assert self._ar_diffusion_kv_state is not None
        self._ar_diffusion_kv_state.commit_paged_context(self._AR_BRANCH)

    def forward(self, req: DiffusionRequestBatch) -> DiffusionOutput:
        if self._ar_diffusion_kv_state is not None:
            raise ValueError(
                "ABot request mode does not run under ARDiffusionEngine session binding; "
                "enable step execution for AR-Diffusion serving."
            )
        inputs = self._parse_request(req)
        schedule = _build_shifted_flow_schedule(flow_shift=inputs.flow_shift)
        dtype = self.transformer.dtype
        out_channels = int(self.transformer.config.out_channels)
        block_frames = inputs.num_frame_per_block

        prompt_embeds = self.encode_prompt(inputs.prompt, max_sequence_length=inputs.max_sequence_length, dtype=dtype)
        latent_h = inputs.height // self.vae_scale_factor_spatial
        latent_w = inputs.width // self.vae_scale_factor_spatial

        first_frame_cond = self._encode_first_frame(inputs.image, inputs.height, inputs.width, dtype)
        cache = self.transformer.allocate_cache(
            batch_size=1,
            latent_height=latent_h,
            latent_width=latent_w,
            device=self.device,
            dtype=dtype,
        )
        total_steps = (inputs.num_latent_frames // block_frames) * len(ABOT_DMD_TIMESTEPS)
        generated_blocks: list[torch.Tensor] = []

        block_action = self._build_action_tensor(None, block_frames, inputs.height, inputs.width, dtype)

        with self.progress_bar(total=total_steps) as progress_bar:
            for local_start in range(0, inputs.num_latent_frames, block_frames):
                noise = randn_tensor(
                    (1, out_channels, block_frames, latent_h, latent_w),
                    generator=inputs.generator,
                    device=self.device,
                    dtype=torch.float32,
                )
                generated_blocks.append(
                    self._generate_block(
                        noise_latent=noise,
                        prompt_embeds=prompt_embeds,
                        first_frame_latent=first_frame_cond,
                        action_condition=block_action,
                        start_frame=local_start,
                        schedule=schedule,
                        generator=inputs.generator,
                        cache=cache,
                        ar_cross_attention=None,
                        progress_bar=progress_bar,
                    )
                )

        generated_latents = torch.cat(generated_blocks, dim=2)
        cache = None

        if inputs.output_type == "latent":
            output = generated_latents
        else:
            _validate_latent_tensor(
                generated_latents,
                expected_channels=int(self.vae.config.z_dim),
                source="ABot transformer",
            )
            output, _ = self._decode_realtime_chunk(generated_latents, None)
            if output.shape[2] != inputs.num_frames:
                raise RuntimeError(f"VAE decode mismatch: expected {inputs.num_frames} frames, got {output.shape[2]}.")

        return DiffusionOutput(
            output=output,
            stage_durations=self.stage_durations if hasattr(self, "stage_durations") else None,
        )

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        """Load only the root ABot generator into the custom transformer."""
        transformer_weights = (
            (name.removeprefix("transformer."), tensor) for name, tensor in weights if name.startswith("transformer.")
        )
        loaded = {f"transformer.{name}" for name in self.transformer.load_weights(transformer_weights)}
        loaded.update(f"vae.{name}" for name, _ in self.vae.named_parameters())
        loaded.update(f"vae_encoder.{name}" for name, _ in self.vae_encoder.named_parameters())
        loaded.update(f"text_encoder.{name}" for name, _ in self.text_encoder.named_parameters())
        return loaded
