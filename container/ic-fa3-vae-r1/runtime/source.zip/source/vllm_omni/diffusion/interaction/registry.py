# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Registry of mid-way interaction handlers during a diffusion generation.
A pipeline only declares the modalities that it supports.
And a pipeline can choose which handler for each modality (there can be more than one handler for a modality).

Outer key: pipeline architecture name (``od_config.model_class_name``).
Inner key: modality name (e.g. ``\"camera\"``).
"""

from __future__ import annotations

from vllm_omni.diffusion.interaction.modality_handlers.base import InteractionHandler
from vllm_omni.diffusion.interaction.modality_handlers.camera import SE3DeltaCameraHandler
from vllm_omni.diffusion.interaction.modality_handlers.prompt import PromptInteractionHandler
from vllm_omni.diffusion.interaction.modality_handlers.taomate_h3_prompt import TaoMateH3PromptInteractionHandler
from vllm_omni.diffusion.models.abot_world.interaction import ABotCameraInteractionHandler
from vllm_omni.diffusion.models.hy_nomas.interaction import (
    HyNomasCameraInteractionHandler,
    HyNomasPromptInteractionHandler,
)

STRUCTURED_HANDLER_REGISTRY: dict[str, dict[str, type[InteractionHandler]]] = {
    "HyNomasPipeline": {
        "prompt": HyNomasPromptInteractionHandler,
        "camera": HyNomasCameraInteractionHandler,
    },
    "HyNomasModularPipeline": {
        "prompt": HyNomasPromptInteractionHandler,
        "camera": HyNomasCameraInteractionHandler,
    },
    # Pipeline class name -> modality -> handler class.
    "HeliosPipeline": {
        "prompt": PromptInteractionHandler,
    },
    "HeliosPyramidPipeline": {
        "prompt": PromptInteractionHandler,
    },
    "LingBotWorldCausalDMDPipeline": {
        "camera": SE3DeltaCameraHandler,
    },
    # ABot conditions on discrete W/A/S/D/I/J/K/L key actions, not SE3 poses.
    "ABotWorldCausalPipeline": {
        "camera": ABotCameraInteractionHandler,
    },
    # TaoMate-H3 re-reads the prompt at every five-second request boundary; the
    # handler switches embeddings immediately (no cross-length interpolation).
    "TaoMateH3Pipeline": {
        "prompt": TaoMateH3PromptInteractionHandler,
    },
}
