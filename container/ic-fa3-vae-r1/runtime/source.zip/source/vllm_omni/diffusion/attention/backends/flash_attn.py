# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

import os
from collections.abc import Callable
from dataclasses import replace
from functools import cache, partial
from typing import NamedTuple

import torch
import torch.nn.functional as F
from vllm.logger import init_logger

from vllm_omni.diffusion.attention.backends.abstract import AttentionBackend, AttentionImpl, AttentionMetadata
from vllm_omni.diffusion.attention.backends.sdpa import _maybe_reshape_attn_mask
from vllm_omni.diffusion.attention.backends.utils.piecewise_attn import (
    piecewise_attn,
    run_paged_piecewise_plan,
)
from vllm_omni.diffusion.attention.capabilities import (
    AttentionComputation,
    CapabilityResult,
    CompilationMode,
    ExecutionContext,
    ExecutionPathResult,
    MaskMode,
    PackingMode,
    ParallelStrategy,
    SupportStatus,
)
from vllm_omni.diffusion.config import get_current_diffusion_config_or_none
from vllm_omni.platforms import current_omni_platform

logger = init_logger(__name__)


@cache
def _get_npu_compressed_causal_mask(device: torch.device) -> torch.Tensor:
    """Return the shared block mask used by NPU right-down causal attention."""
    return torch.triu(
        torch.ones((2048, 2048), dtype=torch.bool, device=device),
        diagonal=1,
    ).contiguous()


if not hasattr(torch.ops.vllm_omni, "fa4_dense_attention"):

    @torch.library.custom_op("vllm_omni::fa4_dense_attention", mutates_args=())
    def _fa4_dense_attention_op(
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        softmax_scale: float,
        causal: bool,
        deterministic: bool,
    ) -> torch.Tensor:
        from vllm_omni.diffusion.attention.backends.utils.fa import flash_attn_func

        if flash_attn_func is None:
            raise RuntimeError("CuTe FlashAttention-4 is unavailable")
        kwargs = {
            "causal": causal,
            "softmax_scale": softmax_scale,
        }
        if deterministic:
            kwargs["deterministic"] = True
        out = flash_attn_func(query, key, value, **kwargs)
        return out[0] if isinstance(out, tuple) else out

    @_fa4_dense_attention_op.register_fake
    def _fa4_dense_attention_fake(
        query,
        key,
        value,
        softmax_scale,
        causal,
        deterministic,
    ):
        # FA4 returns contiguous output even when Q is noncontiguous; V sets its head dimension.
        return query.new_empty((*query.shape[:-1], value.shape[-1]))


_fa4_dense_attention_op = torch.ops.vllm_omni.fa4_dense_attention


_PACKED_KEYS = ("cu_seqlens_q", "cu_seqlens_k", "max_seqlen_q", "max_seqlen_k")


class _FlashAttentionMetadataPlan(NamedTuple):
    attention_mask: torch.Tensor | None
    mask_mode: MaskMode
    full_attn_spans: list[list[tuple[int, int]]] | None
    extra: dict
    packing_mode: PackingMode


def _normalize_flash_attention_metadata(
    attn_metadata: AttentionMetadata | None,
) -> _FlashAttentionMetadataPlan:
    attention_mask = attn_metadata.attn_mask if attn_metadata is not None else None
    full_attn_spans = attn_metadata.full_attn_spans if attn_metadata is not None else None
    extra = attn_metadata.extra if attn_metadata is not None else {}
    published_mask_mode = extra.get("attention_mask_mode")
    if attention_mask is None:
        mask_mode = MaskMode.NONE
    elif published_mask_mode is None:
        mask_mode = MaskMode.UNKNOWN
    else:
        try:
            mask_mode = MaskMode(published_mask_mode)
        except ValueError as error:
            raise ValueError(f"Unknown attention_mask_mode {published_mask_mode!r}") from error
        if mask_mode is MaskMode.UNKNOWN:
            raise ValueError("attention_mask_mode='unknown' is reserved for unpublished semantics")
    # Piecewise dispatch takes precedence and does not consume packed metadata.
    present_packed_keys = [key for key in _PACKED_KEYS if key in extra] if full_attn_spans is None else []
    if present_packed_keys and len(present_packed_keys) != len(_PACKED_KEYS):
        missing = sorted(set(_PACKED_KEYS) - set(present_packed_keys))
        raise ValueError(f"Incomplete packed FlashAttention metadata; missing {missing}")

    packing_mode = PackingMode.NONE
    if present_packed_keys:
        cu_seqlens_q = extra["cu_seqlens_q"]
        packing_mode = PackingMode.MULTI_DOCUMENT if cu_seqlens_q.shape[0] > 3 else PackingMode.PACKED_PADDING
    return _FlashAttentionMetadataPlan(
        attention_mask=attention_mask,
        mask_mode=mask_mode,
        full_attn_spans=full_attn_spans,
        extra=extra,
        packing_mode=packing_mode,
    )


def _flash_attention_execution_path(
    context: ExecutionContext,
) -> ExecutionPathResult:
    if context.mask_mode is MaskMode.UNKNOWN:
        return ExecutionPathResult.unmigrated(
            "FLASH_ATTN",
            context,
            path="runtime_mask_dependent",
        )
    if not (
        context.platform == "cuda"
        and context.kernel_variant == "fa4"
        and context.dtype in {"bfloat16", "torch.bfloat16"}
        and context.causal is False
        and context.mask_mode is MaskMode.NONE
        and context.packing_mode is PackingMode.NONE
        and not context.piecewise
        and not context.paged_kv
        and context.kv_cache_dtype is None
        and context.parallel_strategy is ParallelStrategy.NONE
        and not context.outer_boundaries
    ):
        return ExecutionPathResult.unmigrated(
            "FLASH_ATTN",
            context,
            path="unverified",
        )

    return ExecutionPathResult(
        backend="FLASH_ATTN",
        path="fa4_dense",
        support=CapabilityResult.supported(),
        compilation_mode=CompilationMode.CUSTOM_OP,
        platform=context.platform,
        kernel_variant=context.kernel_variant,
        parallel_strategy=context.parallel_strategy,
    )


class FlashAttentionBackend(AttentionBackend):
    accept_output_buffer: bool = True
    supports_piecewise_spans: bool = True
    supports_paged_kv: bool = True

    @classmethod
    def supports_packed_mask_free(cls) -> bool:
        # CUDA: forward_cuda dispatches the packed cu_seqlens varlen path
        # before ever reading attn_mask. NPU: forward_fa_npu honors the
        # npu_attn_varlen opt-in and rebuilds the padding mask itself if the
        # packed contract fails. XPU: forward_xpu only takes the packed path
        # when attn_mask is None, so models must keep constructing it there.
        return current_omni_platform.is_cuda() or current_omni_platform.is_npu()

    @classmethod
    def supports_multi_doc_packed_varlen(cls, kv_cache_dtype: str | None = None) -> bool:
        # CUDA / ROCm / MUSA / XPU all dispatch ``_forward_varlen_packed`` ->
        # ``flash_attn_varlen_func`` over the caller's cu_seqlens without a
        # mask, so an arbitrary N-document packing keeps its boundaries.
        # NPU's forward path (``_resolve_packed_seq_npu``) only accepts a
        # ``[real, pad]`` two-document layout (cu_seqlens shape <= 3) and
        # otherwise falls back to a padding-mask rebuild that spans the whole
        # packed row, so N>=2 real documents would silently attend across
        # request boundaries; NPU stays False here.
        # The quantized path (``forward_fa_quant_cuda``) is a dense BSHD
        # kernel: ``_validate_quant_request_cuda`` rejects cu_seqlens
        # metadata, so a non-float effective policy must use the dense
        # fallback. Checked first so the answer is testable without an
        # accelerator.
        if kv_cache_dtype not in (None, "float", "auto"):
            return False
        if current_omni_platform.is_npu():
            return False
        from vllm_omni.diffusion.attention.backends.utils.fa import flash_attn_varlen_func

        return flash_attn_varlen_func is not None and (
            current_omni_platform.is_cuda()
            or current_omni_platform.is_rocm()
            or current_omni_platform.is_musa()
            or current_omni_platform.is_xpu()
        )

    @classmethod
    def supports_attention_mask(cls, attention_spec: object | None = None) -> bool:
        del attention_spec
        return True

    @classmethod
    def supports_dense_4d_mask(cls, attention_spec: object | None = None) -> bool:
        del attention_spec
        # CUDA/ROCm/MUSA route masked attention through the varlen wrapper,
        # which only accepts a 2D key-validity mask. Ascend feeds the dense
        # block mask to npu_fusion_attention and accepts 4D directly.
        return current_omni_platform.is_npu()

    @classmethod
    def supports_cross_kv_mask(cls, attention_spec: object | None = None) -> bool:
        del attention_spec
        if not current_omni_platform.is_cuda():
            return False
        from vllm_omni.diffusion.attention.backends.utils.fa import flash_attn_varlen_func

        return flash_attn_varlen_func is not None

    @classmethod
    def supports_cross_head_geometry(cls, q_heads: int, kv_heads: int) -> bool:
        return q_heads == kv_heads or (current_omni_platform.is_cuda() and kv_heads > 0 and q_heads % kv_heads == 0)

    @staticmethod
    def get_supported_head_sizes() -> list[int]:
        return [64, 96, 128, 192, 256]

    @staticmethod
    def get_name() -> str:
        return "FLASH_ATTN"

    @staticmethod
    def get_impl_cls() -> type["FlashAttentionImpl"]:
        return FlashAttentionImpl

    @classmethod
    def resolve_capabilities(cls, context: ExecutionContext) -> ExecutionPathResult:
        return _flash_attention_execution_path(replace(context, kernel_variant=None))


class FlashAttentionImpl(AttentionImpl[AttentionMetadata]):
    # Per-platform attention quantization support.
    # To enable a method on a new platform, add its OmniPlatformEnum value here
    # and handle kv_cache_dtype in the corresponding forward_{platform}().
    #
    # TODO(quant-backend): The quantized path currently lives inside
    # FlashAttentionImpl gated by ``attn_metadata.extra["kv_cache_dtype"]``.
    # Eventually extract it into a dedicated FlashAttentionQuantBackend so
    # backend selection decides quant.
    # Until then, model authors can opt a specific Attention layer out via
    # ``Attention(disable_kv_quant=True)``.
    _supported_kv_cache_dtypes = {
        "cuda": {"fp8"},
        "npu": {"fp8", "mxfp8", "mxfp4"},
    }

    def __init__(
        self,
        num_heads: int,
        head_size: int,
        softmax_scale: float,
        causal: bool = False,
        num_kv_heads: int | None = None,
        prefix: str = "",
        qkv_layout: str | None = None,
        backend_kwargs: dict | None = None,
        role: str = "self",
        **extra_impl_args,
    ) -> None:
        self.num_heads = num_heads
        self.causal = causal
        self.softmax_scale = softmax_scale
        self.qkv_layout = qkv_layout
        computation = extra_impl_args.get("computation", "cross" if role == "cross" else "self")
        self.is_cross_attn = AttentionComputation(computation) is AttentionComputation.CROSS
        from vllm_omni.diffusion.attention.backends.utils.fa import IS_AITER, IS_FLASH_ATTN_4

        self._kernel_variant = "fa4" if IS_FLASH_ATTN_4 else "aiter" if IS_AITER else None
        cfg = get_current_diffusion_config_or_none()
        self.fa_deterministic = bool(getattr(cfg, "fa_deterministic", False)) if cfg is not None else False
        if backend_kwargs:
            logger.warning("FlashAttentionImpl ignoring backend_kwargs: %s", list(backend_kwargs.keys()))

    def resolve_execution_path(
        self,
        context: ExecutionContext,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None,
    ) -> ExecutionPathResult:
        if context.platform == "npu":
            return self._resolve_npu_execution_path(context, query, key, attn_metadata)
        metadata = _normalize_flash_attention_metadata(attn_metadata)
        context = replace(
            context,
            kernel_variant=self._kernel_variant,
            dtype=str(query.dtype).removeprefix("torch."),
            causal=self.causal,
            mask_mode=metadata.mask_mode,
            packing_mode=metadata.packing_mode,
            piecewise=metadata.full_attn_spans is not None,
            kv_cache_dtype=metadata.extra.get("kv_cache_dtype"),
        )
        if context.platform == "rocm":
            return self._resolve_rocm_execution_path(context)
        result = _flash_attention_execution_path(context)
        if result.support.status is not SupportStatus.SUPPORTED:
            return result

        from vllm_omni.diffusion.attention.backends.utils.fa import validate_fa4_head_dims

        try:
            if query.dtype != key.dtype or query.dtype != value.dtype:
                raise ValueError("Q, K, and V dtypes must match")
            if query.device != key.device or query.device != value.device:
                raise ValueError("Q, K, and V devices must match")
            if query.shape[-1] != key.shape[-1]:
                raise ValueError("Q and K head dimensions must match")
            verified = validate_fa4_head_dims(query.shape[-1], value.shape[-1], 16 // value.element_size())
        except (AssertionError, ValueError) as error:
            return replace(
                result,
                support=CapabilityResult.unsupported(f"FA4: {error} Select compatible inputs or another backend."),
            )
        if not verified:
            return replace(
                result,
                support=CapabilityResult.unmigrated("Selected FA4 kernel has no available head-dimension validator"),
                compilation_mode=CompilationMode.EAGER_ONLY,
            )
        return result

    @staticmethod
    def _resolve_rocm_execution_path(context: ExecutionContext) -> ExecutionPathResult:
        """Describe AITER dispatch; device and compiler validation is pending."""
        result = ExecutionPathResult.unmigrated("FLASH_ATTN", context, path="rocm_unverified")
        if (
            context.kernel_variant != "aiter"
            or context.parallel_strategy is not ParallelStrategy.NONE
            or context.outer_boundaries
            or context.paged_kv
            or context.piecewise
            or context.kv_cache_dtype is not None
        ):
            return result
        if context.packing_mode is not PackingMode.NONE:
            path = "rocm_packed_varlen"
        elif context.mask_mode is MaskMode.UNKNOWN:
            path = "rocm_runtime_mask_dependent"
        elif context.mask_mode is not MaskMode.NONE:
            path = "rocm_masked_varlen"
        else:
            path = "rocm_dense"
        return replace(
            result,
            path=path,
            support=CapabilityResult.unmigrated("AITER routing only; kernel and compilation validation require ROCm"),
        )

    def _resolve_npu_execution_path(
        self,
        context: ExecutionContext,
        query: torch.Tensor,
        key: torch.Tensor,
        attn_metadata: AttentionMetadata | None,
    ) -> ExecutionPathResult:
        """Describe existing MindIE routing without claiming hardware validation.

        NPU packing has its own opt-in and [real, pad] contract. In particular,
        incomplete packed metadata can fall back to a mask, so CUDA metadata
        normalization must not run here. No tensor values are inspected.
        """
        context = replace(context, kernel_variant="mindiesd")
        result = ExecutionPathResult.unmigrated("FLASH_ATTN", context, path="npu_unverified")
        extra = attn_metadata.extra if attn_metadata else {}
        if (
            context.parallel_strategy is not ParallelStrategy.NONE
            or context.outer_boundaries
            or context.paged_kv
            or extra.get("kv_cache_dtype") not in (None, "float", "auto")
        ):
            return result

        # Match forward_fa_npu: spans take precedence over the global causal flag.
        if attn_metadata is not None and attn_metadata.full_attn_spans is not None:
            return replace(
                result,
                path="npu_piecewise",
                support=CapabilityResult.unmigrated(
                    "NPU piecewise routing only; kernel and compilation validation require Ascend"
                ),
            )

        if self.causal:
            return result

        path = "npu_masked" if attn_metadata is not None and attn_metadata.attn_mask is not None else "npu_dense"
        if extra.get("npu_attn_varlen", False):
            if self._resolve_packed_seq_npu(query, key, extra) is not None:
                path = (
                    "npu_prefix_kv_slice"
                    if os.environ.get("MINDIE_SD_FA_TYPE") == "ascend_laser_attention"
                    else "npu_packed_varlen"
                )
            else:
                # This route may reject the request if neither an explicit mask
                # nor usable valid_kv_length is supplied; it is not support.
                path = "npu_masked_fallback"
        return replace(
            result,
            path=path,
            support=CapabilityResult.unmigrated("NPU routing only; kernel and compilation validation require Ascend"),
        )

    def _warn_fa_deterministic_non_dense(self, path: str) -> None:
        if not self.fa_deterministic:
            return
        logger.warning_once(
            "fa_deterministic=True is ignored on the %s FlashAttention path; "
            "only the dense flash_attn_func path passes deterministic=True.",
            path,
        )

    @staticmethod
    def _unwrap_flash_output(out: torch.Tensor | tuple[torch.Tensor, ...]) -> torch.Tensor:
        # FA3 may return (out, lse), FA2 returns out
        return out[0] if isinstance(out, tuple) else out

    @staticmethod
    def _flash_wrapper(q, k, v, *, attn_func, **kwargs):
        return FlashAttentionImpl._unwrap_flash_output(attn_func(q, k, v, **kwargs))

    @staticmethod
    def _flash_varlen_wrapper(q, k, v, *, attn_func, causal, softmax_scale, **kwargs):
        """Call a varlen-only FlashAttention backend for a dense segment."""
        del kwargs
        from vllm_omni.diffusion.attention.backends.utils.fa import vllm_varlen_version_kwargs

        batch_size, q_len = q.shape[:2]
        k_len = k.shape[1]
        cu_seqlens_q = torch.arange(0, (batch_size + 1) * q_len, q_len, dtype=torch.int32, device=q.device)
        cu_seqlens_k = torch.arange(0, (batch_size + 1) * k_len, k_len, dtype=torch.int32, device=q.device)
        out = attn_func(
            q=q.flatten(0, 1),
            k=k.flatten(0, 1),
            v=v.flatten(0, 1),
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            max_seqlen_q=q_len,
            max_seqlen_k=k_len,
            causal=causal,
            softmax_scale=softmax_scale,
            **vllm_varlen_version_kwargs(attn_func),
        )
        out = FlashAttentionImpl._unwrap_flash_output(out)
        return out.reshape(batch_size, q_len, *out.shape[1:])

    def _forward_varlen_masked(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        from vllm_omni.diffusion.attention.backends.utils.fa import (
            _index_first_axis,
            _pad_input,
            _unpad_input,
            _upad_input,
            flash_attn_varlen_func,
            vllm_varlen_version_kwargs,
        )

        if flash_attn_varlen_func is None:
            raise ImportError("Masked variable-length attention requires flash_attn_varlen_func")
        assert attention_mask.ndim == 2, "attention_mask must be 2D, (batch_size, seq_len)"
        batch_size, query_length = query.shape[:2]
        if not self.is_cross_attn and query_length == key.size(1):
            q, k, v, indices_q, (cu_seq_lens_q, cu_seq_lens_k), (max_length_q, max_length_k) = _upad_input(
                query, key, value, attention_mask, query_length, _unpad_input
            )
        else:
            # Cross-attention: the mask covers keys only, so keep every query row.
            k, indices_k, cu_seq_lens_k, max_length_k, _ = _unpad_input(key, attention_mask)
            v = _index_first_axis(value, indices_k)
            q = query.flatten(0, 1)
            cu_seq_lens_q = torch.arange(
                0, (batch_size + 1) * query_length, query_length, dtype=torch.int32, device=query.device
            )
            max_length_q = query_length
            indices_q = None

        out_unpad = flash_attn_varlen_func(
            q,
            k,
            v,
            cu_seqlens_q=cu_seq_lens_q,
            cu_seqlens_k=cu_seq_lens_k,
            max_seqlen_q=max_length_q,
            max_seqlen_k=max_length_k,
            **{
                "causal": self.causal,
                "softmax_scale": self.softmax_scale,
                **vllm_varlen_version_kwargs(flash_attn_varlen_func),
            },
        )
        out_unpad = self._unwrap_flash_output(out_unpad)
        if indices_q is None:
            return out_unpad.reshape(batch_size, query_length, *out_unpad.shape[1:])
        return _pad_input(out_unpad, indices_q, batch_size, query_length)

    def _forward_varlen_packed(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        *,
        cu_seqlens_q: torch.Tensor,
        cu_seqlens_k: torch.Tensor,
        max_seqlen_q: int,
        max_seqlen_k: int,
    ) -> torch.Tensor:
        """Run FlashAttention directly on an already packed sequence.

        Some diffusion transformers already maintain exact packed-document
        boundaries. Reusing those boundaries avoids rebuilding boolean masks
        and gathering/scattering Q/K/V in every attention layer.
        """
        from vllm_omni.diffusion.attention.backends.utils.fa import (
            flash_attn_varlen_func,
            vllm_varlen_version_kwargs,
        )

        if flash_attn_varlen_func is None:
            raise ImportError("Packed variable-length attention requires flash_attn_varlen_func")
        if query.shape[0] != 1 or key.shape[0] != 1 or value.shape[0] != 1:
            raise ValueError("Packed variable-length attention currently requires batch size 1")

        out = flash_attn_varlen_func(
            q=query.flatten(0, 1),
            k=key.flatten(0, 1),
            v=value.flatten(0, 1),
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            max_seqlen_q=max_seqlen_q,
            max_seqlen_k=max_seqlen_k,
            causal=self.causal,
            softmax_scale=self.softmax_scale,
            **vllm_varlen_version_kwargs(flash_attn_varlen_func),
        )
        out = self._unwrap_flash_output(out)
        return out.reshape_as(query)

    def _forward_varlen_dense(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
    ) -> torch.Tensor:
        """Common wrapper for calling flash_attn_varlen_func for XPU and CUDA in vLLM.

        NOTE: careful to keep the kwargs on these aligned and to pass everything as a keyword
        argument, because some of the args differ positionally at the moment.

        https://github.com/vllm-project/vllm/blob/v0.20.0/vllm/vllm_flash_attn/flash_attn_interface.py#L176
        https://github.com/vllm-project/vllm/blob/v0.20.0/vllm/_xpu_ops.py#L310
        """
        from vllm_omni.diffusion.attention.backends.utils.fa import (
            flash_attn_varlen_func,
            vllm_varlen_version_kwargs,
        )

        if flash_attn_varlen_func is None:
            raise ImportError("Dense variable-length attention requires flash_attn_varlen_func")
        batch_size, q_len = query.size()[:2]
        k_len = key.size(1)
        cu_seqlens_q = torch.arange(0, (batch_size + 1) * q_len, step=q_len, dtype=torch.int32, device=query.device)
        cu_seqlens_k = torch.arange(0, (batch_size + 1) * k_len, step=k_len, dtype=torch.int32, device=query.device)
        # b s ... -> (b s) ...
        query = query.flatten(0, 1)
        key = key.flatten(0, 1)
        value = value.flatten(0, 1)

        out = flash_attn_varlen_func(
            q=query,
            k=key,
            v=value,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            max_seqlen_q=q_len,
            max_seqlen_k=k_len,
            causal=self.causal,
            softmax_scale=self.softmax_scale,
            **vllm_varlen_version_kwargs(flash_attn_varlen_func),
        )
        out = self._unwrap_flash_output(out)
        # (b s) h d -> b s h d
        return out.reshape(batch_size, q_len, *out.shape[1:])

    def forward_paged(self, paged_kv_context) -> torch.Tensor:
        """Run platform-native paged attention through the Omni backend.

        ``DiffusionPagedAttentionAdapter`` owns BlockTables and prepares the
        rank-local native cache context.  The adapter no longer performs the
        attention call itself; this method is the backend-owned execution
        boundary.  Its native layer wrapper keeps vLLM version-specific cache
        and kernel details out of Omni's common ``Attention`` layer. CUDA uses
        the native vLLM FlashAttention writer/kernel contract. Ascend writes
        the complete K/V span once before its piecewise FIA calls.
        """

        layer = getattr(paged_kv_context, "layer", None)
        if layer is None:
            raise TypeError("paged_kv_context must expose a native diffusion attention layer")
        kv_cache = getattr(layer, "kv_cache", None)
        if kv_cache is None:
            raise RuntimeError(f"Native KV cache is not bound for diffusion layer {layer.layer_name!r}")
        native_impl = getattr(layer, "impl", None)
        if native_impl is None:
            raise RuntimeError(f"Native attention implementation is not bound for diffusion layer {layer.layer_name!r}")
        prewrite_kv = current_omni_platform.requires_diffusion_paged_kv_prewrite()
        forward_updates_cache = layer.attn_backend.forward_includes_kv_cache_update
        # Match vLLM's split update/attention contract. Once K/V has been
        # written by do_kv_cache_update(), decoder attention consumes the
        # paged cache and does not need segment-local K/V tensors. In
        # particular, this avoids packing the same K/V projection view once
        # for every piecewise segment.
        read_kv_from_cache = not forward_updates_cache or prewrite_kv
        # The GPU/default path preserves native cache-update ownership. Ascend
        # prewrites through vLLM-Ascend's normal-layout writer so piecewise FIA
        # segments do not repeatedly scatter the same layer K/V.
        if not forward_updates_cache or prewrite_kv:
            cache_update = getattr(native_impl, "do_kv_cache_update", None)
            if not callable(cache_update):
                raise RuntimeError(
                    f"Native attention implementation for {layer.layer_name!r} cannot update the KV cache"
                )
            cache_update(
                layer,
                paged_kv_context.key_write,
                paged_kv_context.value_write,
                kv_cache,
                paged_kv_context.slot_mapping,
            )

        def run_native_attention(
            query: torch.Tensor,
            key: torch.Tensor | None,
            value: torch.Tensor | None,
            native_metadata,
            output: torch.Tensor | None,
        ) -> torch.Tensor:
            if output is None:
                output = torch.empty(
                    (query.shape[0], layer.num_heads, layer.head_size_v),
                    dtype=query.dtype,
                    device=query.device,
                )
            return native_impl.forward(
                layer,
                query,
                None if read_kv_from_cache else key,
                None if read_kv_from_cache else value,
                kv_cache,
                native_metadata,
                output,
            )

        if paged_kv_context.piecewise_plan is not None:
            # Identical CFG rows can execute as one batched call per piece.
            # Keep that batch layout through the piecewise runner so Q/K/V use
            # strided slices instead of indexed gathers and results can be
            # concatenated in row-major order.
            use_homogeneous_batch = paged_kv_context.piecewise_plan.homogeneous_batch_shape is not None
            output = None
            if not use_homogeneous_batch:
                output = torch.empty(
                    (paged_kv_context.query.shape[0], layer.num_heads, layer.head_size_v),
                    dtype=paged_kv_context.query.dtype,
                    device=paged_kv_context.query.device,
                )
            output = run_paged_piecewise_plan(
                paged_kv_context.query,
                None if read_kv_from_cache else paged_kv_context.key_write,
                None if read_kv_from_cache else paged_kv_context.value_write,
                paged_kv_context.piecewise_plan,
                paged_kv_context.piecewise_native_metadata,
                run_native_attention,
                output_buffer=output,
                use_homogeneous_batch=use_homogeneous_batch,
            )
        else:
            output = run_native_attention(
                paged_kv_context.query,
                paged_kv_context.key_write,
                paged_kv_context.value_write,
                paged_kv_context.native_metadata,
                None,
            )
        return paged_kv_context.restore_output(output)

    def forward_cuda(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        """CUDA/ROCm/MUSA flash attention implementation."""
        from vllm_omni.diffusion.attention.backends.utils.fa import (
            HAS_FLASH_ATTN,
            IS_FLASH_ATTN_4,
            dense_flash_attn_func_for,
            flash_attn_func,
            flash_attn_varlen_func,
        )

        if not HAS_FLASH_ATTN:
            raise ImportError(
                "FlashAttentionBackend requires Flash Attention. "
                "Please use a CUDA vLLM build or install flash-attention/flash-attn. "
                "Otherwise, use SDPA backend by setting DIFFUSION_ATTENTION_BACKEND=TORCH_SDPA"
            )

        metadata_plan = _normalize_flash_attention_metadata(attn_metadata)
        attention_mask = metadata_plan.attention_mask
        full_attn_spans = metadata_plan.full_attn_spans
        extra = metadata_plan.extra

        kv_quant_method = extra.get("kv_cache_dtype")
        if kv_quant_method not in (None, "float", "auto"):
            if kv_quant_method != "fp8":
                raise ValueError(
                    f"CUDA FLASH_ATTN supports only 'fp8' attention precision, got {kv_quant_method!r}. "
                    "Use the NPU backend for mxfp8/mxfp4 or set diffusion_kv_cache_dtype='auto'."
                )
            return self.forward_fa_quant_cuda(query, key, value, attn_metadata)

        # Try piecewise attention
        if full_attn_spans is not None:
            self._warn_fa_deterministic_non_dense("piecewise")
            logger.debug("Using piecewise Flash Attention for mixed causal/full mask")
            if flash_attn_func is not None:
                attn_func = partial(
                    FlashAttentionImpl._flash_wrapper,
                    attn_func=flash_attn_func,
                )
            elif flash_attn_varlen_func is not None:
                attn_func = partial(
                    FlashAttentionImpl._flash_varlen_wrapper,
                    attn_func=flash_attn_varlen_func,
                )
            else:
                raise ImportError("Piecewise FlashAttention requires a dense or varlen FlashAttention function")

            return piecewise_attn(
                query,
                key,
                value,
                full_attn_spans,
                self.softmax_scale,
                attn_func,
                query_ranges=None if attn_metadata is None else attn_metadata.query_ranges,
            )

        if metadata_plan.packing_mode is not PackingMode.NONE:
            self._warn_fa_deterministic_non_dense("packed-varlen")
            return self._forward_varlen_packed(
                query,
                key,
                value,
                cu_seqlens_q=extra["cu_seqlens_q"],
                cu_seqlens_k=extra["cu_seqlens_k"],
                max_seqlen_q=extra["max_seqlen_q"],
                max_seqlen_k=extra["max_seqlen_k"],
            )

        use_masked_path = False
        if attention_mask is not None:
            use_masked_path = (
                torch.any(~attention_mask)
                if metadata_plan.mask_mode is MaskMode.UNKNOWN
                else metadata_plan.mask_mode is not MaskMode.NONE
            )
        if use_masked_path:
            self._warn_fa_deterministic_non_dense("masked-varlen")
            return self._forward_varlen_masked(
                query,
                key,
                value,
                attention_mask,
            )

        # optional_fa3_fwd_dense_func is consulted only here so masked/packed/
        # piecewise/FP8 keep the vLLM varlen dispatcher. FP16 skips fa3-fwd.
        dense_attn_func = dense_flash_attn_func_for(query.dtype)
        if dense_attn_func is not None:
            if IS_FLASH_ATTN_4:
                return _fa4_dense_attention_op(
                    query,
                    key,
                    value,
                    self.softmax_scale,
                    self.causal,
                    self.fa_deterministic,
                )
            fa_kwargs = {
                "causal": self.causal,
                "softmax_scale": self.softmax_scale,
            }
            if self.fa_deterministic:
                fa_kwargs["deterministic"] = True
            out = dense_attn_func(query, key, value, **fa_kwargs)
            return self._unwrap_flash_output(out)

        self._warn_fa_deterministic_non_dense("dense-varlen-fallback")
        return self._forward_varlen_dense(
            query,
            key,
            value,
        )

    def _validate_quant_request_cuda(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None,
    ) -> None:
        extra = attn_metadata.extra if attn_metadata else {}
        reason = None
        if any(name in extra for name in ("cu_seqlens_q", "cu_seqlens_k")):
            reason = "packed/varlen metadata requires the float attention path"
        elif attn_metadata is not None and attn_metadata.full_attn_spans is not None:
            reason = "piecewise attention requires the float attention path"
        elif attn_metadata is not None and attn_metadata.attn_mask is not None:
            reason = "caller masks require the float attention path"
        elif query.ndim != 4:
            reason = "expected four-dimensional (batch, seq, heads, head_dim) query input"
        elif key.ndim != 4 or value.ndim != 4:
            reason = "expected four-dimensional (batch, seq, heads, head_dim) key/value inputs"
        elif query.device != key.device or query.device != value.device:
            reason = "Q/K/V must be on the same CUDA device"
        elif query.shape[0] != key.shape[0] or query.shape[0] != value.shape[0]:
            reason = "Q/K/V batch sizes must match"
        elif query.shape[1] <= 0 or key.shape[1] <= 0:
            reason = "Q/K/V sequence lengths must be positive"
        elif key.shape[1] != value.shape[1] or key.shape[2] != value.shape[2]:
            reason = "K/V sequence lengths and head counts must match"
        elif query.shape[-1] != key.shape[-1] or query.shape[-1] != value.shape[-1]:
            reason = "Q/K/V head dimensions must match"
        elif query.shape[-1] <= 0 or query.shape[-1] % 16 != 0 or query.shape[-1] > 256:
            reason = f"FA3 FP8 requires positive head_dim divisible by 16 and <= 256, got {query.shape[-1]}"
        elif (
            query.dtype not in (torch.bfloat16, torch.float16) or key.dtype != query.dtype or value.dtype != query.dtype
        ):
            reason = (
                "FA3 FP8 requires matching bfloat16 or float16 Q/K/V inputs, "
                f"got {query.dtype}, {key.dtype}, {value.dtype}"
            )
        if reason is None:
            reason = self._fa3_fp8_device_unsupported_reason(query.device)
        if reason is None:
            from vllm_omni.diffusion.attention.backends.utils.fa import (
                FLASH_ATTN_SUPPORTS_FP8,
                flash_attn_func,
                flash_attn_varlen_func,
                resolve_vllm_flash_attn_version,
            )

            if not FLASH_ATTN_SUPPORTS_FP8 or (flash_attn_func is None and flash_attn_varlen_func is None):
                reason = "the selected diffusion FlashAttention implementation has no FA3 FP8 support"
            elif flash_attn_func is None:
                try:
                    resolve_vllm_flash_attn_version(3)
                except RuntimeError as error:
                    reason = str(error)
        if reason is not None:
            raise ValueError(
                f"CUDA attention precision 'fp8' is unavailable: {reason}. "
                "Set diffusion_kv_cache_dtype to 'auto', or select a backend with fp8 "
                "support. Automatic precision fallback is not performed."
            )

    @staticmethod
    def _fa3_fp8_device_unsupported_reason(device: torch.device) -> str | None:
        """Device gate for the FA3 FP8 kernels (Hopper SM90 only).

        Extracted as a static method so CPU tests can mock the hardware probe.
        """
        if device.type != "cuda":
            return f"FA3 FP8 requires a CUDA device, got {device.type}"
        capability = torch.cuda.get_device_capability(device)
        if capability[0] != 9:
            return f"FA3 FP8 kernels require SM90 (Hopper); current device is SM{capability[0]}{capability[1]}"
        return None

    @staticmethod
    def _fa3_fp8_num_splits(kv_seq_len: int) -> int:
        """Bound long FP8 reductions using FA3's split-combine path."""
        # fa3-fwd 0.0.3 loses constant-V accuracy with long single splits.
        # At most 2560 KV tokens per split keeps the tested 19K/75K cases
        # within their original tolerance; short inputs keep one split.
        required_splits = (kv_seq_len + 2559) // 2560
        return 1 << (required_splits - 1).bit_length()

    def forward_fa_quant_cuda(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        """FP8 (e4m3) FlashAttention-3 path for CUDA (SM90).

        vLLM rotates Q/K with a normalized Hadamard transform, then computes
        one dynamic scale for each of Q, K and V on every forward. Omni adapts
        dense BSHD tensors for FA3. No calibration or stored state is involved.
        """
        self._validate_quant_request_cuda(query, key, value, attn_metadata)
        from vllm import _custom_ops as ops

        from vllm_omni.diffusion.attention.backends.utils.fa import flash_attn_func, flash_attn_varlen_func

        batch_size, q_len = query.size()[:2]
        k_len = key.size(1)
        q_heads, head_dim = query.shape[2:]
        kv_heads = key.size(2)
        if q_heads < 1 or kv_heads < 1 or q_heads % kv_heads:
            raise ValueError(
                "FA3 FP8 requires positive Q/KV head counts with Q heads divisible by KV heads; "
                f"got {q_heads} Q heads and {kv_heads} KV heads"
            )
        # Spread Q/K outliers before FP8 rounding. The same orthogonal
        # transform preserves QK^T; V and the output basis stay unchanged.
        # For non-power-of-two head sizes (e.g. 96), rotate equal power-of-two
        # blocks within each head, never across head or token boundaries.
        rotation_dim = head_dim & -head_dim

        def rotate(x: torch.Tensor) -> torch.Tensor:
            rows = x.reshape(-1, rotation_dim).contiguous()
            # vLLM 0.31's masked Hadacore tail can read an incomplete tile.
            # Pad whole rows to its two-chunk (512-element) launch tile;
            # discard only padded rows, preserving each head's transform.
            padding = -rows.shape[0] % (512 // rotation_dim)
            if padding:
                rows = F.pad(rows, (0, 0, 0, padding))
            rotated = ops.hadacore_transform(rows, inplace=False)
            return rotated[: x.numel() // rotation_dim].reshape_as(x)

        # The upstream dynamic per-tensor op computes and returns the scale
        # used for its FP8 conversion. Q/K/V each have an independent scale;
        # no head reordering or GQA-specific scale grouping is needed.
        q_input = rotate(query).reshape(batch_size * q_len, -1)
        k_input = rotate(key).reshape(batch_size * k_len, -1)
        v_input = value.reshape(batch_size * k_len, -1)
        # vLLM 0.31's quantizer accepts strided rows and writes contiguous FP8
        # output. Only the last input dimension must be contiguous; preserving
        # row strides avoids copying V slices from a fused QKV projection.
        q_fp8, q_descale = ops.scaled_fp8_quant(q_input if q_input.stride(-1) == 1 else q_input.contiguous())
        k_fp8, k_descale = ops.scaled_fp8_quant(k_input if k_input.stride(-1) == 1 else k_input.contiguous())
        v_fp8, v_descale = ops.scaled_fp8_quant(v_input if v_input.stride(-1) == 1 else v_input.contiguous())

        fp8_kwargs = dict(
            deterministic=self.fa_deterministic,
            num_splits=self._fa3_fp8_num_splits(k_len),
            # FA3 indexes descales by sequence and KV head. Broadcast each
            # tensor's scalar scale to that interface, including for GQA/MQA.
            q_descale=q_descale.expand(batch_size, kv_heads),
            k_descale=k_descale.expand(batch_size, kv_heads),
            v_descale=v_descale.expand(batch_size, kv_heads),
        )
        if flash_attn_func is not None:
            fp8_attn = partial(flash_attn_func, **fp8_kwargs)
        else:
            assert flash_attn_varlen_func is not None  # Checked by _validate_quant_request_cuda.
            fp8_attn = partial(
                self._flash_varlen_wrapper,
                attn_func=partial(flash_attn_varlen_func, fa_version=3, **fp8_kwargs),
            )
        out = fp8_attn(
            q=q_fp8.view(batch_size, q_len, q_heads, head_dim),
            k=k_fp8.view(batch_size, k_len, kv_heads, head_dim),
            v=v_fp8.view(batch_size, k_len, kv_heads, head_dim),
            softmax_scale=self.softmax_scale,
            causal=self.causal,
        )
        # FA3 FP8 returns BF16; preserve the dtype expected by the model's projection.
        return self._unwrap_flash_output(out).to(query.dtype)

    def forward_xpu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        """XPU flash attention implementation."""
        from vllm_omni.diffusion.attention.backends.utils.fa import (
            HAS_FLASH_ATTN,
            flash_attn_varlen_func,
        )

        if not HAS_FLASH_ATTN:
            raise ImportError(
                "FlashAttentionBackend requires Flash Attention. "
                "Please assure vllm-xpu-kernels properly installed. "
                "Otherwise, use SDPA backend by setting DIFFUSION_ATTENTION_BACKEND=TORCH_SDPA"
            )

        metadata_plan = _normalize_flash_attention_metadata(attn_metadata)
        attention_mask = metadata_plan.attention_mask

        # Spans take precedence over attn_mask, matching forward_cuda.
        if metadata_plan.full_attn_spans is not None:
            return piecewise_attn(
                query,
                key,
                value,
                metadata_plan.full_attn_spans,
                self.softmax_scale,
                partial(FlashAttentionImpl._flash_varlen_wrapper, attn_func=flash_attn_varlen_func),
                query_ranges=None if attn_metadata is None else attn_metadata.query_ranges,
            )

        # Packed cu_seqlens dispatch mirrors forward_cuda. Only take it when
        # no attn_mask rides along: callers that still build a padding mask
        # (e.g. [real, pad] packed layouts on backends without
        # supports_packed_mask_free) must keep the masked path below.
        if metadata_plan.packing_mode is not PackingMode.NONE and attention_mask is None:
            self._warn_fa_deterministic_non_dense("packed-varlen")
            return self._forward_varlen_packed(
                query,
                key,
                value,
                cu_seqlens_q=metadata_plan.extra["cu_seqlens_q"],
                cu_seqlens_k=metadata_plan.extra["cu_seqlens_k"],
                max_seqlen_q=metadata_plan.extra["max_seqlen_q"],
                max_seqlen_k=metadata_plan.extra["max_seqlen_k"],
            )

        if attention_mask is not None and torch.any(~attention_mask):
            return self._forward_varlen_masked(
                query,
                key,
                value,
                attention_mask,
            )

        return self._forward_varlen_dense(
            query,
            key,
            value,
        )

    def forward_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        """NPU attention implementation using mindiesd."""

        extra = attn_metadata.extra if attn_metadata else {}
        method = extra.get("kv_cache_dtype")
        if method not in (None, "float", "auto"):
            return self.forward_fa_quant_npu(query, key, value, attn_metadata)
        return self.forward_fa_npu(query, key, value, attn_metadata)

    @staticmethod
    def _load_quant_runtime(method: str) -> Callable[..., torch.Tensor]:
        if method not in ("fp8", "mxfp8", "mxfp4"):
            raise ValueError(f"Unsupported NPU attention quantization method {method!r}.")
        from mindiesd import quant_attention

        return quant_attention

    def _validate_quant_request(
        self,
        method: str,
        query: torch.Tensor,
        attn_metadata: AttentionMetadata | None,
    ) -> None:
        extra = attn_metadata.extra if attn_metadata else {}
        reason = None
        if self.causal:
            reason = "causal quantized FA is not supported"
        elif any(name in extra for name in ("cu_seqlens_q", "cu_seqlens_k")) or extra.get("npu_attn_varlen"):
            reason = "packed/varlen metadata requires the float attention path"
        elif attn_metadata is not None and attn_metadata.full_attn_spans is not None:
            reason = "piecewise attention requires the float attention path"
        elif attn_metadata is not None and attn_metadata.attn_mask is not None:
            reason = "caller masks require the float attention path"
        elif method in ("fp8", "mxfp8", "mxfp4") and (
            query.ndim != 4 or query.shape[-1] <= 0 or query.shape[-1] & (query.shape[-1] - 1)
        ):
            reason = "generated Hadamard rotations require a four-dimensional input and power-of-two head size"
        if reason is not None:
            raise ValueError(
                f"NPU attention precision {method!r} is unavailable: {reason}. "
                "Set diffusion_kv_cache_dtype to a supported method, or set it to "
                "'auto'. Automatic precision fallback is not performed."
            )

    def forward_fa_quant_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        extra = attn_metadata.extra if attn_metadata else {}
        method = extra.get("kv_cache_dtype", "fp8")
        layout = self.qkv_layout or "BSND"
        self._validate_quant_request(method, query, attn_metadata)
        try:
            runtime = self._load_quant_runtime(method)
        except ImportError as exc:
            raise ImportError(
                f"NPU attention precision {method!r} requires a compatible MindIE-SD "
                "quant Runtime. Install a compatible MindIE-SD build, select another "
                "diffusion_kv_cache_dtype, or set it to 'auto'. Automatic precision "
                "fallback is not performed."
            ) from exc
        kwargs = dict(precision=method, layout=layout, scale=self.softmax_scale)
        # Apply Omni's deterministic Q/K rotation before every Dense quantized path.
        if method in ("fp8", "mxfp8", "mxfp4"):
            from vllm_omni.platforms.npu.quant.kv_quant_npu import get_quant_attention_rotation

            rotation = get_quant_attention_rotation(query.device, query.dtype, query.shape[-1])
            kwargs.update(q_rot=rotation, k_rot=rotation)
        logger.info_once("NPU attention uses MindIE-SD %s Runtime, layout=%s.", method, layout)
        # Execution errors propagate. Never retry with another precision.
        return runtime(query, key, value, **kwargs)

    @staticmethod
    def _npu_fusion_attention(
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        *,
        atten_mask: torch.Tensor | None,
        sparse_mode: int,
        softmax_scale: float,
        inner_precise: int = 0,
    ) -> torch.Tensor:
        """Run ``torch_npu.npu_fusion_attention`` on BSND tensors.

        ``atten_mask`` follows Ascend's convention (True = masked out). When it
        is ``None`` the sparse mode has no effect and full attention is
        computed, so no mask needs to be materialized.
        """
        import torch_npu

        return torch_npu.npu_fusion_attention(
            query.contiguous(),
            key.contiguous(),
            value.contiguous(),
            head_num=query.shape[2],
            input_layout="BSND",
            atten_mask=atten_mask,
            scale=float(softmax_scale),
            keep_prob=1.0,
            inner_precise=inner_precise,
            sparse_mode=sparse_mode,
        )[0]

    def forward_fa_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        # Piecewise block-causal attention takes precedence, mirroring
        # ``forward_cuda``: the caller emitted ``full_attn_spans`` instead of a
        # mask, so the generic mask handling below cannot express it.
        if attn_metadata is not None and attn_metadata.full_attn_spans is not None:
            return self._forward_piecewise_npu(query, key, value, attn_metadata)

        attention_mask = attn_metadata.attn_mask if attn_metadata else None
        if self.causal:
            if attention_mask is None:
                # The compressed upper-triangular mask with sparse_mode=3
                # applies FlashAttention's bottom-right causal alignment when
                # Sq != Skv without materializing the full attention matrix.
                npu_attention_mask = _get_npu_compressed_causal_mask(query.device)
                sparse_mode = 3
                # Explicitly enable invalid-row handling for Sq > Skv. Equal
                # and shorter query sequences have no fully causal-masked rows.
                inner_precise = 2 if query.shape[1] > key.shape[1] else 0
            else:
                # A custom keep-mask cannot be combined with the compressed
                # sparse_mode=3 mask. Materialize the composed block-mask and
                # use allMask mode instead. The explicit mask follows the
                # framework convention (True=keep), while npu_fusion_attention
                # uses True=block.
                explicit_keep_mask = _maybe_reshape_attn_mask(
                    query,
                    key,
                    attention_mask,
                    mask_mode="full_qk",
                ).to(device=query.device, dtype=torch.bool)
                query_positions = torch.arange(query.shape[1], device=query.device).unsqueeze(1)
                key_positions = torch.arange(key.shape[1], device=query.device).unsqueeze(0)
                causal_block_mask = key_positions > query_positions + (key.shape[1] - query.shape[1])
                npu_attention_mask = (causal_block_mask | ~explicit_keep_mask).contiguous()
                sparse_mode = 1
                # An explicit mask can create fully masked rows regardless of
                # the Sq/Skv relationship.
                inner_precise = 2

            return self._npu_fusion_attention(
                query,
                key,
                value,
                atten_mask=npu_attention_mask,
                sparse_mode=sparse_mode,
                softmax_scale=self.softmax_scale,
                inner_precise=inner_precise,
            )

        from mindiesd import attention_forward

        # Opt-in mask-free paths (mirror the CUDA cu_seqlens behavior): the
        # model marks extra["npu_attn_varlen"] and carries packed metadata, so
        # the padding document is excluded without reading or materializing
        # the quadratic full_qk mask.
        #   - default: packed varlen via mindiesd attention_forward_varlen;
        #   - when MINDIE_SD_FA_TYPE=ascend_laser_attention: prefix K/V
        #     slicing via mindiesd attention_forward (so the env-selected op
        #     type is honored; the TND varlen op cannot be).
        extra = attn_metadata.extra if attn_metadata else {}
        if extra.get("npu_attn_varlen", False):
            if os.environ.get("MINDIE_SD_FA_TYPE") == "ascend_laser_attention":
                out = self._forward_prefix_kv_slice_npu(query, key, value, extra)
            else:
                out = self._forward_varlen_packed_npu(query, key, value, extra)
            if out is not None:
                return out
        if attention_mask is None and extra.get("npu_attn_varlen", False):
            # Models skip mask construction when this opt-in is set
            # (FlashAttentionBackend.supports_packed_mask_free). The packed
            # paths above declined (contract mismatch), so rebuild the padding
            # mask here to keep the masked fallback correct.
            used = extra.get("valid_kv_length")
            if not isinstance(used, int) or not 0 < used <= query.shape[1]:
                raise ValueError(
                    "npu_attn_varlen packed metadata is unusable and no attn_mask "
                    f"was constructed (valid_kv_length={used!r}, seq_len={query.shape[1]}); "
                    "refusing to run unmasked attention over padding rows."
                )
            attention_mask = torch.arange(query.shape[1], device=query.device)[None] < used

        # NPU aclnnFlashAttentionScore requires mask shape to be one of:
        # [B, N, Sq, Skv], [B, 1, Sq, Skv], [1, 1, Sq, Skv], or [Sq, Skv]
        # But the incoming mask is 2D [B, S] — reshape to [B, 1, 1, S]
        # So reuse SDPA's mask reshape logic: [B, S] -> [B, 1, Sq, Skv]
        attention_mask = _maybe_reshape_attn_mask(query, key, attention_mask, mask_mode="full_qk")

        layout = self.qkv_layout or "BNSD"
        return attention_forward(
            query,
            key,
            value,
            attn_mask=attention_mask,
            opt_mode="manual",
            op_type="fused_attn_score",
            layout=layout,
        )

    def _npu_piecewise_attn_func(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        *,
        causal: bool,
        softmax_scale: float,
    ) -> torch.Tensor:
        """``attn_func`` for ``piecewise_attn`` on Ascend.

        Both segment kinds run on ``npu_fusion_attention``:
          - causal segments (text runs) carry the shared compressed
            (2048, 2048) mask with ``sparse_mode=3`` (rightDownCausal).
            ``piecewise_attn`` gives causal segments ``kv_end == q_end`` in
            global coordinates, so they always satisfy ``Sq <= Skv``;
            bottom-right alignment reproduces FlashAttention's
            ``attn(Q[:, s:e], K[:, :e], causal=True)`` contract for both
            ``Sq < Skv`` and ``Sq == Skv``.
          - full segments (condition/target image blocks) pass no mask —
            ``sparse_mode`` is ignored when ``atten_mask`` is ``None`` — so
            they are plain bidirectional attention over the truncated K/V
            prefix.

        Inputs follow the model-side ``(B, S, H, D)`` convention == BSND.
        """
        if causal:
            atten_mask = _get_npu_compressed_causal_mask(query.device)
            sparse_mode = 3
        else:
            atten_mask = None
            sparse_mode = 0
        return self._npu_fusion_attention(
            query,
            key,
            value,
            atten_mask=atten_mask,
            sparse_mode=sparse_mode,
            softmax_scale=softmax_scale,
        )

    def _forward_piecewise_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_metadata: AttentionMetadata,
    ) -> torch.Tensor:
        """Piecewise block-causal attention on Ascend, mirroring ``forward_cuda``.

        Same segment plan as the CUDA path (``piecewise_attn``); only the
        per-segment kernel differs (``npu_fusion_attention`` instead of
        ``flash_attn_func``).
        """
        self._warn_fa_deterministic_non_dense("piecewise-npu")
        logger.debug("Using piecewise NPU attention for mixed causal/full mask")
        return piecewise_attn(
            query,
            key,
            value,
            attn_metadata.full_attn_spans,
            self.softmax_scale,
            self._npu_piecewise_attn_func,
            query_ranges=attn_metadata.query_ranges,
        )

    def _resolve_packed_seq_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        extra: dict,
    ) -> tuple[list[int], list[int]] | None:
        """Resolve packed document boundaries (cumulative end offsets per doc).

        Returns (seq_q, seq_k), e.g. ([used_q, total_q], [used_k, total_k]),
        or None unless the metadata matches the exact contract MiniMax-H3
        produces:
          - q/k/v are [1, T, N, D] (BSND, single packed batch);
          - cu_seqlens describe a [real, pad] two-document packing, with the
            padding document as a strict suffix;
          - max_seqlen_q/k are Python ints equal to the real document length
            (so boundaries are derived without any device sync).
        """
        if self.causal:
            return None
        packed_keys = ("cu_seqlens_q", "cu_seqlens_k", "max_seqlen_q", "max_seqlen_k")
        if any(k not in extra for k in packed_keys):
            return None
        cu_q, cu_k = extra["cu_seqlens_q"], extra["cu_seqlens_k"]
        used_q, used_k = extra["max_seqlen_q"], extra["max_seqlen_k"]
        if query.shape[0] != 1 or key.shape[0] != 1:
            return None
        if not isinstance(used_q, int) or not isinstance(used_k, int):
            return None
        total_q, total_k = query.shape[1], key.shape[1]
        # .shape is host-side metadata: counting documents never syncs.
        if cu_q.shape[0] != cu_k.shape[0] or cu_q.shape[0] > 3:
            return None
        if not (0 < used_q <= total_q) or not (0 < used_k <= total_k):
            return None
        if used_q == total_q and used_k == total_k:
            # No padding document: one full-length document.
            return [total_q], [total_k]
        if cu_q.shape[0] == 3 and used_q >= total_q - used_q and used_k >= total_k - used_k:
            # [real, pad] packing: the real document must be the longer one
            # (consistent with the max_seqlen naming).
            return [used_q, total_q], [used_k, total_k]
        return None

    def _forward_varlen_packed_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        extra: dict,
    ) -> torch.Tensor | None:
        """Packed varlen attention on NPU via mindiesd attention_forward_varlen.

        Returns None (caller falls back to the mask path) when the packed
        contract does not hold; see _resolve_packed_seq_npu.
        """
        resolved = self._resolve_packed_seq_npu(query, key, extra)
        if resolved is None:
            return None
        seq_q, seq_k = resolved

        from mindiesd import attention_forward_varlen

        q = query.squeeze(0)  # [T, N, D] == TND
        k = key.squeeze(0)
        v = value.squeeze(0)
        # attention_forward_varlen wants cu_seqlens as host lists of cumulative
        # offsets and forwards cu[1:] as actual_seq_qlen/actual_seq_kvlen.
        out = attention_forward_varlen(
            q,
            k,
            v,
            [0, *seq_q],
            [0, *seq_k],
            softmax_scale=self.softmax_scale,
        )
        return out.unsqueeze(0)

    def _forward_prefix_kv_slice_npu(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        extra: dict,
    ) -> torch.Tensor | None:
        """Mask-free attention by slicing K/V to the valid prefix (zero-copy
        views), then mindiesd attention_forward without a mask.

        Same numerical contract as the varlen path: the padding document is a
        strict suffix, so dropping it from K/V is identical to masking it out.
        Query keeps full length; outputs on padding rows are never consumed
        downstream. Returns None when the packed contract does not hold.

        Used when MINDIE_SD_FA_TYPE=ascend_laser_attention: the TND varlen op
        cannot honor the env-selected op type, while attention_forward can.

        The laser kernel stores unscaled S=QK^T in an fp16 GM workspace, so
        bf16 activations with large outliers overflow 65504 into ±inf and the
        affected rows turn NaN. Models may opt into exact power-of-two input
        pre-scaling via extra["laser_input_scale"] (see abstract.py): q/k/v
        are divided by the factor, the kernel scale_value is multiplied by its
        square, and the output is scaled back. Absent or invalid factor means
        no pre-scaling.
        """
        resolved = self._resolve_packed_seq_npu(query, key, extra)
        if resolved is None:
            return None
        _, seq_k = resolved
        used_k = seq_k[0]  # real document length (first cumulative end)

        from mindiesd import attention_forward

        # mindiesd always takes BSND input regardless of `layout`; the arg
        # selects the op-internal layout and laser only supports BNSD, so do
        # NOT forward the model's qkv_layout ("BSND" for MiniMax-H3) here.
        layout = "BNSD"
        key = key[:, :used_k]
        value = value[:, :used_k]

        input_scale_raw = extra.get("laser_input_scale")
        if isinstance(input_scale_raw, (int, float)) and input_scale_raw > 1:
            input_scale = float(input_scale_raw)
        else:
            input_scale = 1.0
        preserve_input_range = input_scale > 1
        if preserve_input_range:
            query = query / input_scale
            key = key / input_scale
            value = value / input_scale
        scale = self.softmax_scale
        if preserve_input_range:
            scale *= input_scale**2

        def _postprocess(out: torch.Tensor) -> torch.Tensor:
            return out * input_scale if preserve_input_range else out

        return _postprocess(
            attention_forward(
                query,
                key,
                value,
                attn_mask=None,
                opt_mode="manual",
                op_type="fused_attn_score",  # MINDIE_SD_FA_TYPE env overrides this
                layout=layout,
                scale=scale,
            )
        )
