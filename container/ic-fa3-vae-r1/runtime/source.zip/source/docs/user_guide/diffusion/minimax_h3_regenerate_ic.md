# Open-H3-Regenerate-2K-IC

This native pipeline regenerates a high-resolution video from a completed H3
draft and its caption. It uses the published Ref2VA transformer, HyperFlow,
Sharp, latent upscaler and IC adapter through Omni's model loader and worker
groups. It does not launch an external Diffusers service.

The implementation is under development. Local CPU tensor and Gloo tests do
not establish H100 capacity, production readiness, visual quality or speed.
Full-weight Linux, eight-GPU and complete 15-second qualification are required.

## Supported development profile

The first profile is deliberately restricted so that mathematical parity and
resource use can be checked before enabling additional combinations.

| Setting | Required value |
| --- | --- |
| Pipeline | `MiniMaxH3RegenerateICPipeline` |
| Worker group | Eight GPUs, one request and one output |
| DiT | BF16 blocks, preserved published FP32 roots |
| Weight sharding | HSDP shard8, replicate1; full per-rank loading |
| Sequence parallelism | Ulysses8, Ring1; TP1, PP1, CFG1, DP1 |
| Video VAE | FP32, native SDPA, spatial tile8, 256-pixel tile/64-pixel overlap |
| Text encoder | Owner-only Qwen with explicit text-encoder layerwise offload |
| Omni attention | Explicit `TORCH_SDPA`, without role overrides or schedules |
| Sampler | `up3`, three evaluations, guidance1, Sharp1 |
| Input | One complete 24 FPS draft: 124, 360 or 362 frames |

Select text-encoder offload using
`diffusion_offload_config={"mode":"layer","components":["text_encoder"]}`.
Select attention using
`diffusion_attention_config={"default":{"backend":"TORCH_SDPA"}}`.
The active Torch backend reports its name as `SDPA`. The published bundle's
FA3 revision is provenance metadata; it does not certify the active Omni kernel.

Broadcast weight loading, pre-sharded checkpoints, Host Weight Runtime,
quantization, graph capture, caches, dynamic LoRA and other VAE modes are rejected
by this profile. Its resource requirements must be measured with complete
weights; setting these degrees does not prove that a workload fits.

## Model assets

Use the complete published IC bundle, including its root configuration,
`base_model/transformer_ref`, video VAE, text encoder/tokenizer/processor,
HyperFlow, Sharp, latent upscaler and IC adapter. The standard non-IC release is
not interchangeable with this bundle. Model-class discovery uses the published
root configuration identity; it does not identify IC from a directory name.

The local bundle validator checks metadata, required file closure and authorized
paths. Strict tensor loading separately checks missing, unexpected, duplicate,
shape and dtype mismatches. Metadata validation alone does not load or validate
the model tensors.

For local bundles with symlinked shared assets, pass the permitted directories
through `additional_config.ic_trusted_asset_roots`. Configuration files inside
the bundle cannot authorize their own external paths.

### Extra requirement for 15-second inputs

The release's `silence_audio_124f.safetensors` covers only 124 frames. Longer
requests need one of the following explicit inputs:

- `additional_config.ic_audio_vae_path`: a complete Diffusers
  `AutoencoderKLMiniMaxH3Audio` component from the pinned H3 base release. The
  pipeline encodes a zero waveform of the actual duration.
- `additional_config.ic_silence_assets`: separate, correctly normalized silence
  assets for the requested frame counts, each with its path and SHA256.

The per-channel audio latent lengths are 207, 600 and 603 for 124, 360 and 362
video frames respectively. A 362-frame AudioVAE encoding can produce one extra
step; the pipeline trims each channel's time axis before packing. It never
repeats, interpolates or zero-pads the 124-frame latent to qualify a longer input.
Native-format audio checkpoints need conversion and validation before they can
serve as the Diffusers component.

## Prepared launch configuration

The following is a development recipe, not an accepted hardware result. Save it
as `ic8-sdpa.yaml` and replace the AudioVAE directory with the verified component.
Stage parallelism fields are flat because the stage factory reads them before
constructing the terminal diffusion configuration.

```yaml
distributed_executor_backend: mp
dtype: bfloat16
stages:
  - stage_id: 0
    devices: "0,1,2,3,4,5,6,7"
    model_class_name: MiniMaxH3RegenerateICPipeline
    diffusion_load_format: default
    max_num_seqs: 1
    enforce_eager: true
    cache_backend: none
    hsdp_weight_load_strategy: full
    enable_broadcast_weight_load: false
    vae_use_tiling: true
    data_parallel_size: 1
    tensor_parallel_size: 1
    pipeline_parallel_size: 1
    text_encoder_tp_size: 1
    cfg_parallel_size: 1
    ulysses_degree: 8
    ring_degree: 1
    allgather_degree: 1
    use_hsdp: true
    hsdp_shard_size: 8
    hsdp_replicate_size: 1
    vae_patch_parallel_size: 8
    vae_parallel_mode: tile
    diffusion_attention_config:
      default:
        backend: TORCH_SDPA
    diffusion_offload_config:
      mode: layer
      components: [text_encoder]
    additional_config:
      ic_audio_vae_path: /models/pinned-h3-base/audio_vae
    default_sampling_params:
      num_frames: 1
      num_inference_steps: 3
      guidance_scale: 1.0
      fps: 24.0
```

After verifying the complete IC bundle and actual target parser:

```bash
vllm serve "$IC_ROOT" --omni \
  --model-class-name MiniMaxH3RegenerateICPipeline \
  --diffusion-load-format default --deploy-config ic8-sdpa.yaml \
  --num-gpus 8 --init-timeout 1800 --stage-init-timeout 1800 \
  --host 0.0.0.0 --port 8000
```

The existing Videos API accepts the draft as the `source_video` multipart file
field. A first integration request should explicitly use `num_frames=124`,
`size=2560x1440`, `fps=24`, `num_inference_steps=3`, `guidance_scale=1`, a fixed
`seed`, and `extra_params={"regenerate_sampler":"up3","sharp":1}`. Use a matching
360/362-frame source and explicit frame count for the long qualification.

The shared offline `text_to_video.py` runner can use the same deploy file and
`--extra-body` for `source_video`, `regenerate_sampler` and `sharp`. Repeat the
HSDP/SP/VAE, attention and offload CLI settings there: that runner forwards its
legacy CLI defaults as overrides. It saves pre-encoded MP4 output verbatim,
preserving the soundtrack. No model-specific Python example is required.

## Request and output contract

Provide the caption and one `source_video`. HTTP input follows the existing
`prompt["multi_modal_data"]["source_video"]` path. Offline requests may instead
use `sampling_params.extra_args["source_video"]`. Conflicting paths are rejected.
Request knobs `regenerate_sampler` and `sharp` currently accept the fixed up3
recipe. The source must have complete, continuous CFR timestamps at 24 FPS.

| Source canvas | Output canvas |
| --- | --- |
| 1344x768 | 2560x1440 |
| 1280x768 | 2400x1440 |

The output preserves the supported source canvas without implicit cropping.
The 2400x1440 case is not evidence of 2560x1440 capacity. The default
`num_frames=1` is the shared caller's sentinel for reading the entire source;
explicit frame counts must match it. A 360-frame source is exactly 15 seconds;
362 frames are 15.0833 seconds. The true frame count is retained independently
of the VAE latent shape. Specify `num_frames` for an explicit duration check;
`seconds` does not retime the draft and does not override this model's default
full-source sentinel in the shared HTTP parameter resolver.

Seeds are integers in Torch's `manual_seed` range. Omni-created single
`torch.Generator` objects are accepted as seed carriers through `initial_seed()`;
the pipeline does not consume their state or reproduce arbitrary advanced
generator state. Conflicting explicit and generator seeds are rejected. The
video posterior uses the CPU seed, while the denoiser uses the author's separate
seed reduction and random-draw order.

Reference images, source-audio conditioning, masks, continuation, external target
latents and multiple outputs are not supported in this first profile. The source
soundtrack is retained only for delivery: after video encoding, it is padded or
trimmed to the complete output duration and muxed without shortening the video.
The returned result uses Omni's existing encoded-video payload and metadata.

## Same-video multi-GPU VAE

Both encoding and decoding use the existing `DistributedVaeExecutor` and
`DistributedVaeMixin`. Each GPU processes overlapping spatial tiles from the
same video. Original Diffusers tiling, stitching and temporal blending remain
the reference algorithms; the clip is not split into independent generations.

Encoding merges posterior moments before one owner-side CPU-generator sample,
then broadcasts the normalized latent. Sampling each tile independently would
change the reference distribution.

Long decoding uses `decode_reference_to_cpu()`: spatial tile results are merged
per temporal clip, temporal overlap is blended on the original device, and only
the owner transfers finalized frames to CPU. The owner returns FP32 CPU pixels;
other ranks return `None`. The inherited `decode()` preserves its ordinary
device-return contract and is not the long-video memory-saving API.

Both 360 and 362 frames encode to T107; the reference decoder returns 362 frames
from T107. The 360-frame request therefore explicitly trims two trailing frames.
Do not infer the requested duration from T107 alone.

## Qualification sequence

Before enabling the model in a service, verify:

1. Actual Linux imports, source origins, complete assets and strict tensor loads.
2. Same-input VAE moments, fixed-seed posterior and decoded pixels against the
   original tiled VAE, with actual encode/decode work on every rank.
3. Full T107 and 2560x1440 capacity, owner CPU output, final frames, all-rank GPU
   peaks and host-memory peaks.
4. Full IC loading, HSDP/SP execution and a matched 124-frame author baseline.
5. Complete 360/362-frame IC, VAE replay with IC weights resident, repeated
   requests, full media decoding and visual review.
6. Separately measured performance, with an excluded warmup and matched inputs.

Generic engine dummy warmup is disabled because it has no source video. A real
draft-based warmup is still required and is excluded from performance results.

Component CPU/Gloo tests cover numerical and communication contracts. They do
not replace NCCL, complete-weight HSDP execution, long-video memory tests or
manual inspection of identity, motion, lip sync, seams and colour.

See the [VAE parallelism guide](parallelism/vae_parallelism.md) and the
[VAE executor design](../../design/feature/vae_parallel.md) for the shared
infrastructure.
