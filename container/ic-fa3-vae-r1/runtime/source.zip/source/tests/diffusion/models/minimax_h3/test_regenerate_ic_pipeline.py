# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""CPU request/loading/media boundaries, not published-model or engine qualification."""

from __future__ import annotations

import ast
import importlib.util
import io
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType

import pytest
import torch
from torch import nn

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


@pytest.fixture(scope="module")
def pipeline():
    # An isolated package loads the real relative implementation without
    # bootstrapping vLLM or pretending that the full engine imported on CPU.
    folder = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion/models/minimax_h3"
    package = ModuleType("_test_ic_pipeline_package")
    package.__path__ = [str(folder)]
    sys.modules[package.__name__] = package
    name = package.__name__ + ".pipeline_minimax_h3_regenerate_ic"
    spec = importlib.util.spec_from_file_location(name, folder / "pipeline_minimax_h3_regenerate_ic.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        yield module
    finally:
        for key in list(sys.modules):
            if key == package.__name__ or key.startswith(package.__name__ + "."):
                sys.modules.pop(key, None)


@dataclass
class ParallelContract:
    data_parallel_size: int = 1
    tensor_parallel_size: int = 1
    pipeline_parallel_size: int = 1
    text_encoder_tp_size: int = 1
    cfg_parallel_size: int = 1
    ulysses_degree: int = 8
    ring_degree: int = 1
    allgather_degree: int = 1
    sequence_parallel_size: int = 8
    hsdp_shard_size: int = 8
    hsdp_replicate_size: int = 1
    vae_patch_parallel_size: int = 8
    use_hsdp: bool = True
    vae_parallel_mode: str = "tile"


@dataclass
class AttentionSpecContract:
    backend: str = "TORCH_SDPA"

    def backend_kwargs(self):
        return None


@dataclass
class AttentionContract:
    default: AttentionSpecContract | None = field(default_factory=AttentionSpecContract)
    per_role: dict[str, AttentionSpecContract] = field(default_factory=dict)


@dataclass
class RuntimeContract:
    """Only validator inputs; this deliberately is not a fake Omni config import."""

    parallel_config: ParallelContract = field(default_factory=ParallelContract)
    dtype: torch.dtype = torch.bfloat16
    enable_broadcast_weight_load: bool = False
    hsdp_weight_load_strategy: str = "full"
    host_weight_runtime_mode: str = "disabled"
    quantization_config: object = None
    lora_path: str | None = None
    cache_backend: str | None = "none"
    cache_strategy: str = "none"
    enable_prompt_embed_cache: bool = False
    enable_prefix_caching: bool = False
    diffusion_use_graph: bool = False
    diffusion_attention_config: AttentionContract = field(default_factory=AttentionContract)
    diffusion_attention_schedule: object = None
    diffusion_load_format: str = "default"


@pytest.mark.parametrize(
    "field_name,value",
    [
        ("data_parallel_size", 2),
        ("tensor_parallel_size", 2),
        ("pipeline_parallel_size", 2),
        ("text_encoder_tp_size", 2),
        ("cfg_parallel_size", 2),
        ("ulysses_degree", 4),
        ("ring_degree", 2),
        ("allgather_degree", 2),
        ("sequence_parallel_size", 4),
        ("hsdp_shard_size", 4),
        ("hsdp_replicate_size", 2),
        ("vae_patch_parallel_size", 1),
        ("use_hsdp", False),
        ("vae_parallel_mode", "batch"),
        ("sequence_parallel_size", True),
    ],
)
def test_reject_unqualified_parallelism(pipeline, field_name, value):
    config = RuntimeContract()
    setattr(config.parallel_config, field_name, value)
    with pytest.raises(ValueError):
        pipeline.validate_ic_runtime_config(config)


@pytest.mark.parametrize(
    "field_name,value",
    [
        ("dtype", torch.float16),
        ("enable_broadcast_weight_load", True),
        ("hsdp_weight_load_strategy", "pre_sharded"),
        ("host_weight_runtime_mode", "auto"),
        ("quantization_config", object()),
        ("lora_path", "another-adapter"),
        ("cache_backend", "cache_dit"),
        ("cache_strategy", "tea_cache"),
        ("enable_prompt_embed_cache", True),
        ("enable_prefix_caching", True),
        ("diffusion_use_graph", True),
        ("diffusion_attention_schedule", object()),
        ("diffusion_load_format", "diffusers"),
        ("diffusion_load_format", "dummy"),
    ],
)
def test_reject_unqualified_runtime(pipeline, field_name, value):
    config = RuntimeContract()
    setattr(config, field_name, value)
    with pytest.raises(ValueError):
        pipeline.validate_ic_runtime_config(config)


def test_explicit_correctness_attention_required(pipeline):
    config = RuntimeContract()
    pipeline.validate_ic_runtime_config(config)
    config.diffusion_attention_config.default = None
    with pytest.raises(ValueError, match="explicit TORCH_SDPA"):
        pipeline.validate_ic_runtime_config(config)
    config.diffusion_attention_config.default = AttentionSpecContract("FLASH_ATTN_3_HUB")
    with pytest.raises(ValueError, match="explicit TORCH_SDPA"):
        pipeline.validate_ic_runtime_config(config)
    config.diffusion_attention_config.default = AttentionSpecContract()
    config.diffusion_attention_config.per_role["self"] = AttentionSpecContract()
    with pytest.raises(ValueError, match="without overrides"):
        pipeline.validate_ic_runtime_config(config)


@dataclass
class SamplingContract:
    extra_args: dict[str, object] = field(default_factory=dict)
    num_outputs_per_prompt: int = 1
    lora_request: object = None
    latents: object = None
    audio_latents: object = None
    fps: float | None = None
    height: int | None = None
    width: int | None = None
    generator: object = None
    seed: int | None = None
    frame_rate: float | None = None
    attention_schedule: object = None
    attention_sigma_schedule: object = None
    enable_frame_interpolation: bool = False


def test_http_and_offline_source_routes(pipeline, tmp_path):
    source = tmp_path / "source.mp4"
    source.write_bytes(b"only path resolution is under test")
    params = SamplingContract()
    prompt = {"prompt": "", "multi_modal_data": {"source_video": str(source)}}
    path, caption, extra = pipeline.resolve_ic_request(prompt, params)
    assert path == source.resolve() and caption == "" and extra == {}
    params.extra_args["source_video"] = str(source)
    assert pipeline.resolve_ic_request({"prompt": "test"}, params)[:2] == (source.resolve(), "test")
    other = tmp_path / "other.mp4"
    other.touch()
    params.extra_args["source_video"] = str(other)
    with pytest.raises(ValueError, match="conflicting"):
        pipeline.resolve_ic_request(prompt, params)


@pytest.mark.parametrize("media", [{"source_audio": "x"}, {"image": "x"}, {"video": "x"}])
def test_reject_unimplemented_modalities(pipeline, tmp_path, media):
    source = tmp_path / "source.mp4"
    source.touch()
    with pytest.raises(ValueError, match="only a source_video"):
        pipeline.resolve_ic_request({"multi_modal_data": {"source_video": str(source), **media}}, SamplingContract())


@pytest.mark.parametrize(
    "name", ["source_audio", "video_noise_mask", "audio_noise_mask", "control", "continue_from", "latent_cache"]
)
def test_reject_unimplemented_extra_inputs(pipeline, tmp_path, name):
    source = tmp_path / "source.mp4"
    source.touch()
    with pytest.raises(ValueError, match="does not support"):
        pipeline.resolve_ic_request(
            {"multi_modal_data": {"source_video": str(source)}}, SamplingContract(extra_args={name: "x"})
        )


@pytest.mark.parametrize("height,width,out_height,out_width", [(768, 1344, 1440, 2560), (768, 1280, 1440, 2400)])
def test_canvas_preserved_without_implicit_crop(pipeline, height, width, out_height, out_width):
    params = SamplingContract()
    assert pipeline.resolve_ic_output_size(height, width, params) == (out_height, out_width)
    params.height, params.width = out_height, out_width
    assert pipeline.resolve_ic_output_size(height, width, params) == (out_height, out_width)
    params.width = 1920
    with pytest.raises(ValueError, match="without implicit cropping"):
        pipeline.resolve_ic_output_size(height, width, params)


def test_unqualified_source_canvas_rejected(pipeline):
    with pytest.raises(ValueError, match="only 1344x768"):
        pipeline.resolve_ic_output_size(720, 1280, SamplingContract())


@pytest.mark.parametrize(
    "name,value",
    [
        ("generator", object()),
        ("frame_rate", 30.0),
        ("fps", True),
        ("attention_schedule", [object()]),
        ("enable_frame_interpolation", True),
    ],
)
def test_reject_ignored_request_controls(pipeline, tmp_path, name, value):
    source = tmp_path / "source.mp4"
    source.touch()
    params = SamplingContract()
    setattr(params, name, value)
    with pytest.raises(ValueError):
        pipeline.resolve_ic_request({"multi_modal_data": {"source_video": str(source)}}, params)


@pytest.mark.parametrize("seed", [0, 42, -1, -(1 << 63), (1 << 62) + 9, (1 << 64) - 1])
def test_seed_carrier_matches_torch_seed_range_without_consuming_state(pipeline, seed):
    generator = torch.Generator(device="cpu").manual_seed(seed)
    torch.randn(3, generator=generator)  # A carrier can be advanced; its state is not IC's sampling state.
    original_state = generator.get_state().clone()
    params = SamplingContract(seed=seed, generator=generator)
    assert pipeline.resolve_ic_seed(params) == seed
    assert torch.equal(generator.get_state(), original_state)
    params.seed = None
    assert pipeline.resolve_ic_seed(params) == seed % (1 << 64)
    assert torch.equal(generator.get_state(), original_state)


def test_seed_none_defaults_and_generator_conflict(pipeline):
    assert pipeline.resolve_ic_seed(SamplingContract()) == 0
    assert pipeline.resolve_ic_seed(SamplingContract(seed=42)) == 42
    params = SamplingContract(seed=41, generator=torch.Generator(device="cpu").manual_seed(42))
    with pytest.raises(ValueError, match="conflicts"):
        pipeline.resolve_ic_seed(params)


@pytest.mark.parametrize("seed", [True, False, 42.0, "42", -(1 << 63) - 1, 1 << 64])
def test_invalid_seed_rejected(pipeline, seed):
    with pytest.raises(ValueError, match="torch.manual_seed range"):
        pipeline.resolve_ic_seed(SamplingContract(seed=seed))


@pytest.mark.parametrize("carrier", [[], [torch.Generator(device="cpu")], object()])
def test_non_single_generator_rejected(pipeline, carrier):
    with pytest.raises(ValueError, match="one torch.Generator"):
        pipeline.resolve_ic_seed(SamplingContract(generator=carrier))


def test_real_diffusers_factory_precision_and_context_restore(pipeline):
    previous = torch.get_default_dtype()
    config = dict(
        num_attention_heads=1,
        attention_head_dim=6,
        hidden_size=6,
        num_layers=1,
        num_refiner_layers=0,
        ffn_dim=4,
        in_channels=2,
        audio_in_channels=2,
        patch_size=(1, 1, 1),
        text_dim=4,
        freq_dim=4,
        time_embed_hidden_dim=6,
        time_embed_dim=4,
        rope_freq_dim=1,
    )
    base = pipeline.build_ic_base_transformer(config)
    assert torch.get_default_dtype() == previous
    for name, value in base.named_parameters():
        expected = torch.float32 if name.split(".")[0] in pipeline._FP32_ROOTS else torch.bfloat16
        assert value.device.type == "cpu" and value.dtype == expected
        assert not value.requires_grad
    assert base.rope.inv_freq.dtype == torch.float32
    pipeline._validate_native_attention(base, "tiny real base")
    assert base.transformer_blocks[0].attn.processor._attention_backend.value == "native"
    pipeline.MiniMaxH3ICTransformer(base).validate_precision()
    base.transformer_blocks[0].attn.processor._attention_backend = None
    with pytest.raises(RuntimeError, match="explicitly bound Diffusers native"):
        pipeline._validate_native_attention(base, "tiny real base")
    with pytest.raises(RuntimeError, match="controlled"):
        with pipeline._cpu_default_dtype(torch.bfloat16):
            assert torch.get_default_dtype() == torch.bfloat16
            raise RuntimeError("controlled")
    assert torch.get_default_dtype() == previous


def test_strict_real_component_weight_coverage(pipeline):
    module = nn.Sequential(nn.Linear(3, 2, dtype=torch.bfloat16), nn.Linear(2, 1, dtype=torch.float32))
    weights = {name: torch.full_like(value, 0.25) for name, value in module.state_dict().items()}
    assert pipeline.consume_ic_component_weights(module, weights.items()) == set(weights)
    for name, value in module.state_dict().items():
        torch.testing.assert_close(value, weights[name], rtol=0, atol=0)
    with pytest.raises(ValueError, match="missing"):
        pipeline.consume_ic_component_weights(module, list(weights.items())[:-1])
    with pytest.raises(ValueError, match="duplicate"):
        pipeline.consume_ic_component_weights(module, [*weights.items(), next(iter(weights.items()))])
    with pytest.raises(ValueError, match="shape/dtype"):
        pipeline.consume_ic_component_weights(module, [("0.weight", torch.zeros(2, 3, dtype=torch.float32))])
    with pytest.raises(ValueError, match="shape/dtype"):
        pipeline.consume_ic_component_weights(module, [("0.weight", torch.zeros(2, 4, dtype=torch.bfloat16))])
    with pytest.raises(ValueError, match="unexpected"):
        pipeline.consume_ic_component_weights(module, [("not-a-key", torch.zeros(1))])


def test_text_encoder_uses_inner_feature_model(pipeline):
    conditioner = nn.Module()
    conditioner.model = nn.Linear(2, 2, dtype=torch.bfloat16)
    conditioner.lm_head = nn.Linear(2, 3, dtype=torch.bfloat16)
    encoder = pipeline._ICTextEncoder(conditioner, torch.device("cpu"))
    assert encoder.model is conditioner.model
    with pytest.raises(RuntimeError, match="layerwise hooks"):
        encoder._block_groups()
    encoder._omni_layerwise_enabled = True
    encoder._omni_layerwise_block_groups = [[conditioner.model]]
    assert encoder._block_groups() == [[conditioner.model], [conditioner.lm_head]]
    stub = pipeline._ICTextEncoder(None, torch.device("cpu"))
    assert not stub.is_loaded and stub._block_groups() == []
    stub.load_to_device()
    stub.offload_to_cpu()
    with pytest.raises(RuntimeError, match="output owner"):
        _ = stub.model


def test_hsdp_entry_preserves_version_counters_and_disables_autocast(pipeline, monkeypatch):
    instance = pipeline.MiniMaxH3RegenerateICPipeline.__new__(pipeline.MiniMaxH3RegenerateICPipeline)
    nn.Module.__init__(instance)
    instance.device = torch.device("cpu")
    sentinel = object()

    def inspect_context(self, request):
        assert request is sentinel
        assert not torch.is_inference_mode_enabled()
        assert not torch.is_grad_enabled()
        assert not torch.is_autocast_enabled("cpu")
        value = torch.ones(1)
        assert value._version == 0
        return value

    monkeypatch.setattr(pipeline.MiniMaxH3RegenerateICPipeline, "_forward", inspect_context)
    with torch.autocast("cpu", dtype=torch.bfloat16):
        output = instance(sentinel)
    assert output.item() == 1
    assert instance.supports_request_cancellation


def test_real_io_support_consumer_skips_inapplicable_text_only_dummy(pipeline):
    # Execute the actual, unmodified consumer definition. This isolated
    # registry-lookup seam is not a claim that the full engine imported.
    root = Path(__file__).resolve().parents[4]
    file = root / "vllm_omni/diffusion/io_support.py"
    tree = ast.parse(file.read_text(encoding="utf-8"))
    consumer = next(
        node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "get_dummy_run_num_frames"
    )

    class ClassLookup:
        @staticmethod
        def _try_load_model_cls(name):
            assert name == "MiniMaxH3RegenerateICPipeline"
            return pipeline.MiniMaxH3RegenerateICPipeline

    def reject_default_audio_fallback(name):
        raise AssertionError("IC must explicitly opt out before generic dummy defaults")

    namespace = {"DiffusionModelRegistry": ClassLookup, "supports_audio_output": reject_default_audio_fallback}
    exec(compile(ast.Module(body=[consumer], type_ignores=[]), str(file), "exec"), namespace)
    assert namespace["get_dummy_run_num_frames"]("MiniMaxH3RegenerateICPipeline", False) == 0
    assert namespace["get_dummy_run_num_frames"]("MiniMaxH3RegenerateICPipeline", True) == 0


@dataclass
class WorldContract:
    world_size: int = 2
    cpu_group: object = None


@pytest.fixture
def real_errors(monkeypatch):
    file = Path(__file__).resolve().parents[4] / "vllm_omni/errors.py"
    spec = importlib.util.spec_from_file_location("vllm_omni.errors", file)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, spec.name, module)
    spec.loader.exec_module(module)
    return module


def test_agreement_preserves_client_status_on_owner_and_peer(pipeline, real_errors, monkeypatch):
    instance = pipeline.MiniMaxH3RegenerateICPipeline.__new__(pipeline.MiniMaxH3RegenerateICPipeline)
    nn.Module.__init__(instance)
    instance.world = WorldContract()

    def owner_gather(result, message, *, group):
        assert group is None
        result[:] = [message, None]

    monkeypatch.setattr(torch.distributed, "all_gather_object", owner_gather)
    with pytest.raises(real_errors.OmniClientError) as owner:
        with instance._agreement("request", client_errors=True):
            raise ValueError("bad source canvas")
    assert owner.value.status_code == 400

    def peer_gather(result, message, *, group):
        assert message is None
        result[:] = [("OmniClientError: bad source canvas", 400, "BadRequestError"), None]

    monkeypatch.setattr(torch.distributed, "all_gather_object", peer_gather)
    with pytest.raises(real_errors.OmniClientError) as peer:
        with instance._agreement("request", client_errors=True):
            pass
    assert peer.value.status_code == owner.value.status_code
    assert peer.value.error_type == owner.value.error_type
    assert str(peer.value) == str(owner.value)


def test_agreement_keeps_model_failure_as_server_failure(pipeline, real_errors, monkeypatch):
    instance = pipeline.MiniMaxH3RegenerateICPipeline.__new__(pipeline.MiniMaxH3RegenerateICPipeline)
    nn.Module.__init__(instance)
    instance.world = WorldContract()

    def gather(result, message, *, group):
        result[:] = [message, None]

    monkeypatch.setattr(torch.distributed, "all_gather_object", gather)
    with pytest.raises(ValueError, match="missing model asset") as failure:
        with instance._agreement("asset"):
            raise ValueError("missing model asset")
    assert not isinstance(failure.value, real_errors.OmniClientError)


def test_effective_attention_registry_alias_contract(pipeline):
    class RuntimeSDPA:
        @staticmethod
        def get_name():
            return "SDPA"

    attention = nn.Module()
    attention.backend_explicit = True
    attention.backend_pref = "TORCH_SDPA"
    attention.attn_backend = RuntimeSDPA
    block = nn.Module()
    block.attn = nn.Module()
    block.attn.processor = nn.Module()
    block.attn.processor.attention = attention
    base = nn.Module()
    base.transformer_blocks = nn.ModuleList([block])
    base.token_refiner = nn.Module()
    wrapper = nn.Module()
    wrapper.model = base
    instance = pipeline.MiniMaxH3RegenerateICPipeline.__new__(pipeline.MiniMaxH3RegenerateICPipeline)
    nn.Module.__init__(instance)
    instance.transformer = wrapper
    instance._validate_effective_attention()
    attention.backend_explicit = False
    with pytest.raises(RuntimeError, match="effective local attention"):
        instance._validate_effective_attention()


@pytest.fixture
def real_media_modules(monkeypatch):
    folder = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion"
    logger_module = ModuleType("vllm.logger")
    logger_module.init_logger = logging.getLogger
    monkeypatch.setitem(sys.modules, "vllm.logger", logger_module)
    loaded = {}
    for suffix, file in (("cancellation", "cancellation.py"), ("utils.media_utils", "utils/media_utils.py")):
        name = "vllm_omni.diffusion." + suffix
        spec = importlib.util.spec_from_file_location(name, folder / file)
        assert spec is not None and spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        monkeypatch.setitem(sys.modules, name, module)
        spec.loader.exec_module(module)
        loaded[suffix] = module
    return loaded


def test_real_mp4_encode_preserves_real_frames_and_pixels(pipeline, real_media_modules, monkeypatch):
    import av

    frames = 22

    def reject_owner_collective(**kwargs):
        raise AssertionError("owner-only encoding must not enter cancellation collectives")

    monkeypatch.setattr(real_media_modules["cancellation"], "check_request_cancellation", reject_owner_collective)
    pixels = torch.full((1, 3, frames, 32, 64), 0.75, dtype=torch.float32)
    mean = torch.tensor(pipeline.IC_PIXEL_MEAN).view(1, 3, 1, 1, 1)
    std = torch.tensor(pipeline.IC_PIXEL_STD).view(1, 3, 1, 1, 1)
    normalized = (pixels - mean) / std
    result = pipeline.MiniMaxH3RegenerateICPipeline._encode_mp4(normalized, audio_from=None, frames=frames)
    assert real_media_modules["utils.media_utils"].count_mp4_frames(result) == frames
    with av.open(io.BytesIO(result)) as container:
        assert container.streams.video[0].average_rate == 24
        decoded = list(container.decode(video=0))
        assert len(decoded) == frames
        observed = torch.from_numpy(decoded[-1].to_ndarray(format="rgb24")).float().mean()
        assert abs(observed.item() - 191) < 4
    bad = normalized.clone()
    bad[0, 0, 0, 0, 0] = float("nan")
    with pytest.raises(ValueError, match="finite FP32 CPU"):
        pipeline.MiniMaxH3RegenerateICPipeline._encode_mp4(bad, audio_from=None, frames=frames)


def test_postprocessor_preserves_encoded_protocol(pipeline):
    payload = {"payload": {"video": [b"video"], "audio": [None]}, "metadata": {"video": {"frame_counts": [362]}}}
    assert pipeline.minimax_h3_ic_post_process(payload) is payload
