# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Real CPU WORLD2 collectives for H3 VAE ownership and failure recovery.

Network layers are tiny deterministic operators. Executor, tensor storage,
spawn processes, gather/broadcast and CPU error agreement are real. This is
not a CUDA/NCCL or production shape qualification test.
"""

from __future__ import annotations

import ast
import hashlib
import json
import multiprocessing
import socket
import sys
import time
import traceback
from collections.abc import Callable
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field
from datetime import timedelta
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest
import torch
import torch.distributed as dist

from tests.diffusion.models.minimax_h3.test_distributed_diffusers_vae import _decode_reference, _ReferenceVae

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


def _load_definitions(path, name, dependencies):
    """Avoid serving-stack imports while retaining original definitions."""
    parsed = ast.parse(path.read_text(encoding="utf-8"))
    definitions = [node for node in parsed.body if isinstance(node, (ast.ClassDef, ast.FunctionDef))]
    tree = ast.Module(
        body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *definitions],
        type_ignores=[],
    )
    module = ModuleType(name)
    module.__file__ = str(path)
    module.__dict__.update(dependencies)
    sys.modules[name] = module
    exec(compile(ast.fix_missing_locations(tree), str(path), "exec"), module.__dict__)
    return module


def _make_vae(root):
    from diffusers.models.autoencoders.vae import DiagonalGaussianDistribution
    from diffusers.models.modeling_outputs import AutoencoderKLOutput

    executor_path = root / "vllm_omni/diffusion/distributed/autoencoders/distributed_vae_executor.py"
    executor = _load_definitions(
        executor_path,
        "_h3_real_gloo_executor",
        {
            "Callable": Callable,
            "contextmanager": contextmanager,
            "dataclass": dataclass,
            "field": field,
            "torch": torch,
            "dist": dist,
            "logger": SimpleNamespace(warning=lambda *args, **kwargs: None),
            "get_world_group": lambda: SimpleNamespace(device_group=dist.group.WORLD, cpu_group=dist.group.WORLD),
        },
    )
    adapter_path = root / "vllm_omni/diffusion/models/minimax_h3/distributed_diffusers_vae.py"
    adapter = _load_definitions(
        adapter_path,
        "_h3_real_gloo_adapter",
        {
            "torch": torch,
            "dist": dist,
            "nullcontext": nullcontext,
            "AutoencoderKLMiniMaxH3": _ReferenceVae,
            "DistributedVaeMixin": executor.DistributedVaeMixin,
            "DistributedOperator": executor.DistributedOperator,
            "GridSpec": executor.GridSpec,
            "TileTask": executor.TileTask,
            "DiagonalGaussianDistribution": DiagonalGaussianDistribution,
            "AutoencoderKLOutput": AutoencoderKLOutput,
            "apply_forward_hook": lambda function: function,
        },
    )
    model = adapter.DistributedAutoencoderKLMiniMaxH3()
    model.init_distributed()
    model.set_parallel_size(2, mode="tile")
    return model, adapter, executor_path, adapter_path


def _worker(rank, port, directory):
    directory = Path(directory)
    report_path = directory / f"rank-{rank}.json"
    report = {"rank": rank, "status": "STARTED", "phases": []}

    def save():
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    def begin(name):
        report["active_phase"] = name
        save()

    try:
        begin("initialize")
        torch.set_num_threads(1)
        dist.init_process_group(
            "gloo",
            init_method=f"tcp://127.0.0.1:{port}",
            rank=rank,
            world_size=2,
            timeout=timedelta(seconds=20),
        )
        root = Path(__file__).resolve().parents[4]
        vae, adapter, executor_path, adapter_path = _make_vae(root)
        report.update(
            backend=dist.get_backend(),
            world_size=dist.get_world_size(),
            torch_version=torch.__version__,
            executor_sha256=hashlib.sha256(executor_path.read_bytes()).hexdigest(),
            adapter_sha256=hashlib.sha256(adapter_path.read_bytes()).hexdigest(),
        )
        latent = torch.linspace(-0.5, 0.5, 2 * 7 * 8 * 11).reshape(1, 2, 7, 8, 11)

        def healthy_request(name, *, single_tile=False):
            begin(name)
            vae.reset_tile_work_counts()
            size = (1, 2, 17, 4, 4) if single_tile else (1, 2, 34, 16, 22)
            pixels = torch.linspace(-0.3, 0.7, torch.tensor(size).prod().item()).reshape(size)
            generator = torch.Generator().manual_seed(901)
            rng_before = generator.get_state().clone()
            actual = vae.encode_reference(pixels, generator=generator)
            reference = _ReferenceVae().encode(pixels, return_dict=False)[0]
            sampled = reference.sample(generator=torch.Generator().manual_seed(901))
            mean = torch.tensor(vae.config.latents_mean).view(1, -1, 1, 1, 1)
            std = torch.tensor(vae.config.latents_std).view(1, -1, 1, 1, 1)
            expected = ((sampled - mean) / std).bfloat16()
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)
            if rank != 0:
                assert torch.equal(generator.get_state(), rng_before)
            else:
                assert not torch.equal(generator.get_state(), rng_before)
            encode_count = vae.get_tile_work_counts()["encode"]
            counts = [torch.zeros((), dtype=torch.int64) for _ in range(2)]
            dist.all_gather(counts, torch.tensor(encode_count, dtype=torch.int64))
            observed = [int(value) for value in counts]
            assert observed == [1, 0] if single_tile else all(value > 0 for value in observed)
            decoded = vae.decode_to_cpu(latent)
            if rank == 0:
                assert decoded is not None and decoded.device.type == "cpu"
                torch.testing.assert_close(decoded, _decode_reference(_ReferenceVae(), latent), rtol=0, atol=0)
                assert decoded.shape == (1, 3, 22, 16, 22)
            else:
                assert decoded is None
            record = {
                "name": name,
                "status": "PASSED",
                "encode_counts": observed,
                "local_work": vae.get_tile_work_counts(),
                "nonowner_rng_unchanged": rank != 0,
                "output_owned": decoded is not None,
            }
            report["phases"].append(record)
            save()
            dist.barrier()

        healthy_request("normal_spatial_encode_sample_decode")
        healthy_request("one_tile_empty_rank", single_tile=True)

        for failure in ("rank1_tile", "owner_posterior", "owner_cpu_copy"):
            begin(failure)
            original_encoder = vae.encoder
            original_posterior = adapter.DiagonalGaussianDistribution
            original_to = torch.Tensor.to
            error = None
            try:
                if failure == "rank1_tile" and rank == 1:

                    def fail_tile(_value):
                        raise RuntimeError("injected rank1 tile forward failure")

                    vae.encoder = fail_tile
                if failure == "owner_posterior":

                    class FailurePosterior(original_posterior):
                        def sample(self, generator=None):
                            raise MemoryError("injected owner posterior failure")

                    adapter.DiagonalGaussianDistribution = FailurePosterior
                if failure == "owner_cpu_copy" and rank == 0:

                    def fail_copy(value, *args, **kwargs):
                        if kwargs.get("device") == "cpu" and kwargs.get("copy") is True:
                            raise MemoryError("injected owner CPU copy failure")
                        return original_to(value, *args, **kwargs)

                    torch.Tensor.to = fail_copy
                if failure == "owner_cpu_copy":
                    vae.decode_to_cpu(latent)
                else:
                    vae.encode_reference(torch.zeros(1, 2, 17, 16, 22), generator=torch.Generator().manual_seed(91))
            except RuntimeError as caught:
                error = str(caught)
            finally:
                vae.encoder = original_encoder
                adapter.DiagonalGaussianDistribution = original_posterior
                torch.Tensor.to = original_to
            assert error is not None, f"rank {rank} did not receive {failure}"
            expected_stage = {
                "rank1_tile": "tile decode",
                "owner_posterior": "reference posterior sampling",
                "owner_cpu_copy": "CPU decode temporal output",
            }[failure]
            assert expected_stage in error, error
            error_count = torch.ones((), dtype=torch.int32)
            dist.all_reduce(error_count)
            assert error_count.item() == 2
            report["phases"].append({"name": failure, "status": "AGREED_ERROR", "error": error})
            save()
            dist.barrier()
            healthy_request(f"recovery_after_{failure}")
        report["status"] = "PASSED"
    except Exception:
        report["status"] = "FAILED"
        report["error"] = traceback.format_exc()
        raise
    finally:
        save()
        if dist.is_initialized():
            dist.destroy_process_group()


@pytest.mark.skipif(not dist.is_available() or not dist.is_gloo_available(), reason="Gloo is unavailable")
def test_two_rank_gloo_tile_ownership_error_agreement_and_recovery(tmp_path):
    """Bound the whole worker run, including failed collective cleanup."""
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    context = multiprocessing.get_context("spawn")
    processes = [context.Process(target=_worker, args=(rank, port, str(tmp_path))) for rank in range(2)]
    try:
        for process in processes:
            process.start()
        deadline = time.monotonic() + 60
        while any(process.is_alive() for process in processes) and time.monotonic() < deadline:
            for process in processes:
                process.join(timeout=0.05)
        reports = [json.loads(path.read_text(encoding="utf-8")) for path in sorted(tmp_path.glob("rank-*.json"))]
        assert not any(process.is_alive() for process in processes), f"Gloo worker deadline exceeded: {reports}"
        assert [process.exitcode for process in processes] == [0, 0], reports
        assert len(reports) == 2
        assert all(report["status"] == "PASSED" for report in reports), reports
        assert all(report["backend"] == "gloo" and report["world_size"] == 2 for report in reports)
        assert all(len(report["phases"]) == 8 for report in reports)
    finally:
        for process in processes:
            if process.is_alive():
                process.terminate()
        for process in processes:
            process.join(timeout=5)
            if process.is_alive():
                process.kill()
                process.join(timeout=5)
