# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""CPU math and real Gloo protocol tests; no H100/kernel/performance qualification."""

from __future__ import annotations

import copy
import importlib.util
import logging
import sys
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import timedelta
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
import torch.nn.functional as F
from torch import nn

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]
ROOT = Path(__file__).resolve().parents[4]
ATTENTION_PATH = "vllm_omni/diffusion/models/minimax_h3/regenerate_ic_attention.py"


def _load_file(name, path, patch):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    patch.setitem(sys.modules, name, module)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def adapter_module(monkeypatch):
    module = _load_file("_test_h3_ic_attention", ATTENTION_PATH, monkeypatch)
    monkeypatch.setattr(module, "_get_omni_forward_context", lambda: None)
    return module


class DenseAttention(nn.Module):
    """Numerical test dependency with the same BSHD contract as Omni local Attention."""

    def __init__(self):
        super().__init__()
        self.lengths = []

    def forward(self, q, k, v):
        self.lengths.append((q.shape[1], k.shape[1], v.shape[1]))
        return F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)).transpose(1, 2)


class InjectedFailureAttention(nn.Module):
    def forward(self, q, k, v):
        raise RuntimeError("symmetric injected local attention failure")


@dataclass
class HookScope:
    """Only the existing Omni forward-context fields touched by actual SP hooks."""

    sp_original_seq_len: int | None = 2
    sp_padding_size: int = 1
    _sp_shard_depth: int = 3
    _sp_equal_pad_stack: list[bool] = field(default_factory=lambda: [False])
    sp_shard_metadata: dict[str, int] = field(default_factory=dict)


def _tiny_model(heads=56):
    from diffusers.models.transformers.transformer_minimax_h3 import MiniMaxH3Transformer3DModel

    return MiniMaxH3Transformer3DModel(
        num_attention_heads=heads,
        attention_head_dim=8,
        hidden_size=12,
        num_layers=2,
        num_refiner_layers=1,
        ffn_dim=16,
        in_channels=2,
        audio_in_channels=2,
        patch_size=(1, 1, 1),
        text_dim=4,
        freq_dim=4,
        time_embed_hidden_dim=12,
        time_embed_dim=8,
        rope_freq_dim=1,
    )


def _inputs():
    return dict(
        hidden_states=torch.randn(1, 3, 2),
        audio_hidden_states=torch.randn(1, 1, 2),
        encoder_hidden_states=torch.randn(1, 3, 4),
        timestep=torch.tensor([0.2, 0.7, 1.0]),
        timestep_indices=torch.tensor([2, 2, 0, 1, 0, 2, 0]),
        token_tags=torch.tensor([1, 1, 0, 2, 0, 1, 0]),
        position_ids=torch.arange(21, dtype=torch.float32).view(7, 3) / 5,
        video_indices=torch.tensor([2, 4, 6]),
        audio_indices=torch.tensor([3]),
        text_indices=torch.tensor([0, 1, 5]),
    )


def test_metadata_padding_preserves_all_original_rows_and_distinct_times(adapter_module):
    original = _inputs()
    before = {name: value.clone() for name, value in original.items()}
    position, times, tags, valid = adapter_module.prepare_ic_sequence_parallel_inputs(
        original["position_ids"], original["timestep_indices"], original["token_tags"], world_size=8
    )
    assert valid == 7
    assert position.shape == (8, 3) and times.shape == tags.shape == (8,)
    for padded, name in ((position, "position_ids"), (times, "timestep_indices"), (tags, "token_tags")):
        torch.testing.assert_close(padded[:valid], before[name])
        assert bool((padded[valid:] == 0).all())
    for name in before:
        torch.testing.assert_close(original[name], before[name])
    adapter_module.validate_ic_sequence_indices(
        valid, original["video_indices"], original["audio_indices"], original["text_indices"]
    )


@pytest.mark.parametrize("world_size", [0, -1, True, 1.5])
def test_reject_invalid_world_size(adapter_module, world_size):
    data = _inputs()
    with pytest.raises(ValueError, match="positive integer"):
        adapter_module.prepare_ic_sequence_parallel_inputs(
            data["position_ids"], data["timestep_indices"], data["token_tags"], world_size=world_size
        )


def test_reject_misaligned_metadata_and_padding_indices(adapter_module):
    data = _inputs()
    with pytest.raises(ValueError, match="matching position_ids"):
        adapter_module.prepare_ic_sequence_parallel_inputs(
            data["position_ids"], data["timestep_indices"][:-1], data["token_tags"], world_size=8
        )
    with pytest.raises(ValueError, match="original valid"):
        adapter_module.validate_ic_sequence_indices(7, torch.tensor([7]), data["audio_indices"], data["text_indices"])
    position, times, tags, valid = adapter_module.prepare_ic_sequence_parallel_inputs(
        data["position_ids"], data["timestep_indices"], data["token_tags"], world_size=1
    )
    assert position is data["position_ids"] and times is data["timestep_indices"] and tags is data["token_tags"]
    assert valid == 7


def test_scoped_length_restores_after_nested_call_and_failure(adapter_module):
    assert adapter_module._VALID_SEQUENCE_LENGTH.get() is None
    with adapter_module.ic_sequence_parallel_context(7):
        with pytest.raises(RuntimeError, match="injected"):
            with adapter_module.ic_sequence_parallel_context(3):
                assert adapter_module._VALID_SEQUENCE_LENGTH.get() == 3
                raise RuntimeError("injected")
        assert adapter_module._VALID_SEQUENCE_LENGTH.get() == 7
    assert adapter_module._VALID_SEQUENCE_LENGTH.get() is None


def test_full_single_rank_model_matches_diffusers_and_keeps_refiner(adapter_module):
    torch.manual_seed(2301)
    model = _tiny_model()
    reference = copy.deepcopy(model)
    refiner = model.token_refiner.refiner_blocks[0].attn.processor
    for block in model.transformer_blocks:
        block.attn.set_processor(
            adapter_module.MiniMaxH3ICAttnProcessor(56, 8, world_size=1, attention=DenseAttention())
        )
    data = _inputs()
    with torch.no_grad():
        expected, actual = reference(**data), model(**data)
    torch.testing.assert_close(actual.sample, expected.sample, rtol=2e-6, atol=2e-6)
    torch.testing.assert_close(actual.audio_sample, expected.audio_sample, rtol=2e-6, atol=2e-6)
    assert model.token_refiner.refiner_blocks[0].attn.processor is refiner


def test_single_rank_attention_and_unsupported_masks(adapter_module):
    torch.manual_seed(2312)
    model = _tiny_model(heads=2)
    block = model.transformer_blocks[0]
    reference = copy.deepcopy(block.attn)
    dense = DenseAttention()
    processor = adapter_module.MiniMaxH3ICAttnProcessor(2, 8, world_size=1, attention=dense)
    hidden = torch.randn(1, 7, 12)
    rotary = model.rope(torch.randn(7, 3))
    with torch.no_grad():
        expected = reference(hidden, rotary)
        actual = processor(reference, hidden, rotary)
    torch.testing.assert_close(actual, expected, rtol=2e-6, atol=2e-6)
    assert dense.lengths == [(7, 7, 7)]
    with pytest.raises(ValueError, match="masks are unsupported"):
        processor(reference, hidden, rotary, torch.ones(7, dtype=torch.bool))
    with pytest.raises(ValueError, match="divide"):
        adapter_module.MiniMaxH3ICAttnProcessor(56, 8, world_size=3, attention=dense)


def test_missing_scope_mismatched_shard_and_bad_rope_reject_before_collectives(adapter_module):
    model = _tiny_model(heads=2)
    attention = model.transformer_blocks[0].attn
    processor = adapter_module.MiniMaxH3ICAttnProcessor(2, 8, world_size=2, attention=DenseAttention())
    hidden = torch.randn(1, 4, 12)
    with pytest.raises(RuntimeError, match="scoped valid"):
        processor(attention, hidden)
    with adapter_module.ic_sequence_parallel_context(5), pytest.raises(ValueError, match="shard shape"):
        processor(attention, hidden)
    single = adapter_module.MiniMaxH3ICAttnProcessor(2, 8, world_size=1, attention=DenseAttention())
    with pytest.raises(ValueError, match="RoPE"):
        single(attention, hidden, (torch.ones(3, 6), torch.zeros(3, 6)))


def test_fused_qkv_matches_diffusers(adapter_module):
    torch.manual_seed(2313)
    attention = _tiny_model(heads=2).transformer_blocks[0].attn
    attention.fuse_projections()
    reference = copy.deepcopy(attention)
    attention.set_processor(adapter_module.MiniMaxH3ICAttnProcessor(2, 8, world_size=1, attention=DenseAttention()))
    hidden = torch.randn(1, 7, 12)
    with torch.no_grad():
        torch.testing.assert_close(attention(hidden), reference(hidden), rtol=2e-6, atol=2e-6)


@contextmanager
def _cpu_omni_runtime(world_size, rank):
    """Load actual Omni hooks/collectives, isolating unrelated CUDA/vLLM import setup.

    Only coordinator accessors/logger/platform and forward-context accessors
    are test dependencies. No tensor math, SP hooks or all-to-all are replaced.
    """
    with pytest.MonkeyPatch.context() as patch:
        packages = (
            "vllm",
            "vllm_omni",
            "vllm_omni.diffusion",
            "vllm_omni.diffusion.distributed",
            "vllm_omni.diffusion.hooks",
            "vllm_omni.diffusion.models",
            "vllm_omni.diffusion.models.minimax_h3",
        )
        for name in packages:
            package = ModuleType(name)
            package.__path__ = []
            patch.setitem(sys.modules, name, package)
        logger = ModuleType("vllm.logger")
        logger.init_logger = logging.getLogger
        patch.setitem(sys.modules, logger.__name__, logger)
        platform = ModuleType("vllm_omni.platforms")
        platform.current_omni_platform = SimpleNamespace(synchronize=lambda: None)
        patch.setitem(sys.modules, platform.__name__, platform)
        group = SimpleNamespace(
            world_size=world_size,
            rank_in_group=rank,
            ulysses_world_size=world_size,
            ulysses_rank=rank,
            ulysses_group=dist.group.WORLD,
            ring_world_size=1,
            allgather_world_size=1,
        )

        def gather(tensor, dim):
            outputs = [torch.empty_like(tensor) for _ in range(world_size)]
            dist.all_gather(outputs, tensor.contiguous())
            return torch.cat(outputs, dim=dim)

        group.all_gather = gather
        parallel = ModuleType("vllm_omni.diffusion.distributed.parallel_state")
        parallel.get_sp_group = lambda: group
        parallel.get_sequence_parallel_world_size = lambda: world_size
        parallel.get_sequence_parallel_rank = lambda: rank
        patch.setitem(sys.modules, parallel.__name__, parallel)
        context = ModuleType("vllm_omni.diffusion.forward_context")
        scope = HookScope()
        context.is_forward_context_available = lambda: True
        context.get_forward_context = lambda: scope
        context.get_ulysses_mode = lambda default="strict": default
        patch.setitem(sys.modules, context.__name__, context)
        for name, path in (
            ("distributed.sp_plan", "distributed/sp_plan.py"),
            ("distributed.sp_sharding", "distributed/sp_sharding.py"),
            ("distributed.comm", "distributed/comm.py"),
            ("hooks.base", "hooks/base.py"),
            ("hooks.sequence_parallel", "hooks/sequence_parallel.py"),
        ):
            _load_file("vllm_omni.diffusion." + name, "vllm_omni/diffusion/" + path, patch)
        adapter = _load_file("vllm_omni.diffusion.models.minimax_h3.regenerate_ic_attention", ATTENTION_PATH, patch)
        patch.setattr(adapter, "_local_attention", lambda *_args: DenseAttention())
        yield adapter


def test_actual_sp_plan_and_fail_closed_hook_checks():
    with _cpu_omni_runtime(8, 0) as adapter:
        from vllm_omni.diffusion.distributed.sp_plan import SequenceParallelConfig, validate_sp_plan
        from vllm_omni.diffusion.hooks.sequence_parallel import apply_sequence_parallel

        wrapper = nn.Module()
        wrapper.model = _tiny_model()
        adapter.install_ic_sequence_parallel(wrapper, expected_world_size=8)
        validate_sp_plan(wrapper._sp_plan)
        assert all("token_refiner" not in path for path in wrapper._sp_plan)
        with pytest.raises(RuntimeError, match="hook is missing"):
            adapter.assert_ic_sequence_parallel_ready(wrapper)
        apply_sequence_parallel(wrapper, SequenceParallelConfig(ulysses_degree=8), wrapper._sp_plan)
        adapter.assert_ic_sequence_parallel_ready(wrapper)
        hook = wrapper.model.norm_out._hook_registry.get_hook("sp_input---model.norm_out")
        original_config = hook.config
        hook.config = SequenceParallelConfig(ulysses_degree=2)
        with pytest.raises(RuntimeError, match="metadata or degree"):
            adapter.assert_ic_sequence_parallel_ready(wrapper)
        hook.config = original_config
        wrapper.model.norm_out._hook_registry.remove_hook("sp_input---model.norm_out")
        with pytest.raises(RuntimeError, match="model.norm_out"):
            adapter.assert_ic_sequence_parallel_ready(wrapper)


def test_group_topology_and_diffusers_parallelism_are_rejected():
    with _cpu_omni_runtime(8, 0) as adapter:
        group = adapter._get_sp_group()
        group.ring_world_size = 2
        wrapper = nn.Module()
        wrapper.model = _tiny_model()
        with pytest.raises(RuntimeError, match="pure Ulysses"):
            adapter.install_ic_sequence_parallel(wrapper, expected_world_size=8)
        group.ring_world_size = 1
        wrapper.model._parallel_config = object()
        with pytest.raises(RuntimeError, match="must not be enabled together"):
            adapter.install_ic_sequence_parallel(wrapper, expected_world_size=8)


def _gloo_worker(rank, world_size, init_file, output_directory):
    torch.set_num_threads(1)
    dist.init_process_group(
        "gloo",
        init_method=Path(init_file).resolve().as_uri(),
        rank=rank,
        world_size=world_size,
        timeout=timedelta(seconds=45),
    )
    try:
        with _cpu_omni_runtime(world_size, rank) as adapter:
            from vllm_omni.diffusion.distributed.sp_plan import SequenceParallelConfig
            from vllm_omni.diffusion.hooks.sequence_parallel import apply_sequence_parallel

            torch.manual_seed(2317)
            wrapper = nn.Module()
            wrapper.model = _tiny_model()
            reference = copy.deepcopy(wrapper.model)
            original_refiner = wrapper.model.token_refiner.refiner_blocks[0].attn.processor
            data = _inputs()
            original_data = {key: value.clone() for key, value in data.items()}
            adapter.install_ic_sequence_parallel(wrapper, expected_world_size=world_size)
            apply_sequence_parallel(wrapper, SequenceParallelConfig(ulysses_degree=world_size), wrapper._sp_plan)
            adapter.assert_ic_sequence_parallel_ready(wrapper)
            position, times, tags, valid = adapter.prepare_ic_sequence_parallel_inputs(
                data["position_ids"], data["timestep_indices"], data["token_tags"], world_size=world_size
            )
            adapter.validate_ic_sequence_indices(
                valid, data["video_indices"], data["audio_indices"], data["text_indices"]
            )
            data.update(position_ids=position, timestep_indices=times, token_tags=tags)
            scope = adapter._get_omni_forward_context()
            outer_stack = scope._sp_equal_pad_stack
            with torch.no_grad(), adapter.ic_sequence_parallel_context(valid):
                actual = wrapper.model(**data)
            assert scope.sp_original_seq_len == 2 and scope.sp_padding_size == 1
            assert scope._sp_shard_depth == 3 and scope._sp_equal_pad_stack is outer_stack
            with torch.no_grad():
                expected = reference(**original_data)
            torch.testing.assert_close(actual.sample, expected.sample, rtol=3e-6, atol=3e-6)
            torch.testing.assert_close(actual.audio_sample, expected.audio_sample, rtol=3e-6, atol=3e-6)
            assert wrapper.model.token_refiner.refiner_blocks[0].attn.processor is original_refiner
            assert adapter._VALID_SEQUENCE_LENGTH.get() is None
            for block in wrapper.model.transformer_blocks:
                assert block.attn.processor.attention.lengths == [(valid, valid, valid)]
            first = wrapper.model.transformer_blocks[0].attn.processor
            good_attention, first.attention = first.attention, InjectedFailureAttention()
            with pytest.raises(RuntimeError, match="symmetric injected"):
                with torch.no_grad(), adapter.ic_sequence_parallel_context(valid):
                    wrapper.model(**data)
            assert adapter._VALID_SEQUENCE_LENGTH.get() is None
            assert scope.sp_original_seq_len == 2 and scope.sp_padding_size == 1
            assert scope._sp_shard_depth == 3 and scope._sp_equal_pad_stack is outer_stack
            first.attention = good_attention
            with torch.no_grad(), adapter.ic_sequence_parallel_context(valid):
                retry = wrapper.model(**data)
            torch.testing.assert_close(retry.sample, actual.sample, rtol=0, atol=0)
            report = {
                "rank": rank,
                "world_size": world_size,
                "heads": 56,
                "valid_rows": valid,
                "padded_rows": position.shape[0],
                "max_abs_video": float((actual.sample - expected.sample).abs().max()),
                "max_abs_audio": float((actual.audio_sample - expected.audio_sample).abs().max()),
                "symmetric_injected_failure_recovery": True,
            }
            import json

            Path(output_directory, f"rank-{rank}.json").write_text(json.dumps(report), encoding="utf-8")
    finally:
        # Only the standalone test owns this group. Production owns no lifecycle.
        dist.destroy_process_group()


@pytest.mark.parametrize("world_size", [2, 8])
def test_real_gloo_collectives_and_actual_hooks_match_single_rank(tmp_path, world_size):
    if not dist.is_available() or not dist.is_gloo_available():
        pytest.skip("Gloo is not available")
    mp.spawn(_gloo_worker, args=(world_size, str(tmp_path / "rendezvous"), str(tmp_path)), nprocs=world_size, join=True)
    assert len(list(tmp_path.glob("rank-*.json"))) == world_size
