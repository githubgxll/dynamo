# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Real CPU Diffusers layout/audio tests; serving and GPU remain separate."""

from __future__ import annotations

import hashlib
import importlib.util
import sys
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from safetensors.torch import save_file
from torch import nn

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


@pytest.fixture(scope="module")
def processing():
    path = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion/models/minimax_h3/regenerate_ic_processing.py"
    spec = importlib.util.spec_from_file_location("_test_ic_processing", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    yield module
    sys.modules.pop(spec.name, None)


@pytest.mark.parametrize("frames,latent_t,audio_t", [(124, 37, 207), (360, 107, 600), (362, 107, 603)])
def test_real_duration_rules(processing, frames, latent_t, audio_t):
    assert processing.target_latent_shape(frames, 1440, 2560) == (24, latent_t, 90, 160)
    assert processing.audio_latent_length(frames) == audio_t
    pixels = torch.zeros(frames, 3, 2, 2)
    draft = processing.ICDraft(pixels, frames, 24.0)
    assert draft.num_frames == frames
    assert draft.pixels.shape[0] == frames
    assert draft.encode_num_frames == (124 if frames == 124 else 362)
    normalized = processing.normalize_ic_pixels(draft.pixels)
    assert normalized.shape == (1, 3, frames, 2, 2)
    torch.testing.assert_close(
        normalized[0, :, 0, 0, 0], -torch.tensor((0.485, 0.456, 0.406)) / torch.tensor((0.229, 0.224, 0.225))
    )


@pytest.mark.parametrize("frames", [True, False, 0, -1, 21, 24.0])
def test_bad_duration_fails(processing, frames):
    with pytest.raises(ValueError):
        processing.target_latent_shape(frames, 1440, 2560)


@pytest.mark.parametrize("shape", [(24, 2, 4, 6), (24, 107, 2, 4)])
def test_real_diffusers_patch_order_and_inverse(processing, shape):
    latent = torch.arange(np.prod(shape), dtype=torch.float32).reshape(shape)
    rows = processing.patch_rows(latent)
    torch.testing.assert_close(rows[0, 0], latent[:, 0, :2, :2].reshape(-1))
    torch.testing.assert_close(processing.unpatch_rows(rows, shape), latent, rtol=0, atol=0)
    with pytest.raises(ValueError):
        processing.unpatch_rows(rows[:, :-1], shape)


@pytest.mark.parametrize("frames", [124, 360, 362])
def test_real_packed_layout_and_row_times(processing, frames):
    _, temporal, _, _ = processing.target_latent_shape(frames, 1440, 2560)
    reference = torch.arange(24 * temporal * 2 * 4).float().reshape(24, temporal, 2, 4)
    prompt = processing.ICPromptConditioning(torch.ones(1, 5, 5120), torch.tensor([1, 0, 0, 1, 1]), 3)
    audio_t = processing.audio_latent_length(frames)
    silence = torch.arange(2 * audio_t * 32).float().reshape(1, 2 * audio_t, 32)
    packed = processing.build_ic_packed_inputs(reference, (24, temporal, 4, 8), prompt, silence, device="cpu")
    layout = packed.layout
    ref_rows, target_rows = temporal * 2, temporal * 8
    assert layout.num_condition_video_rows == ref_rows
    assert layout.num_condition_audio_rows == 0
    assert layout.position_ids.shape == (5 + ref_rows + 2 * audio_t + target_rows, 3)
    assert layout.position_ids.dtype == torch.float64
    torch.testing.assert_close(layout.video_indices[:ref_rows], torch.arange(5, 5 + ref_rows))
    torch.testing.assert_close(layout.audio_indices, torch.arange(5 + ref_rows, 5 + ref_rows + 2 * audio_t))
    torch.testing.assert_close(packed.audio_rows, silence)
    unique, inverse = layout.row_timesteps(0.5)
    times = unique[inverse]
    torch.testing.assert_close(times[:5], torch.full((5,), 0.5))
    torch.testing.assert_close(times[layout.video_indices[:ref_rows]], torch.full((ref_rows,), 0.999))
    torch.testing.assert_close(times[layout.video_indices[ref_rows:]], torch.full((target_rows,), 0.5))
    assert bool((times[layout.audio_indices] == 1).all())
    anchored = processing.fixed_reference_anchor(packed.reference_rows, torch.ones_like(packed.reference_rows))
    torch.testing.assert_close(anchored, packed.reference_rows * 0.999 + 0.001)


def test_packed_unique_times_feed_existing_hyperflow_endpoints(processing):
    path = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion/models/minimax_h3/regenerate_ic_transformer.py"
    spec = importlib.util.spec_from_file_location("_test_ic_endpoint_boundary", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
        prompt = processing.ICPromptConditioning(torch.ones(1, 3, 5120), torch.tensor([0, 1, 1]), 1)
        packed = processing.build_ic_packed_inputs(
            torch.ones(24, 2, 2, 2), (24, 2, 4, 4), prompt, torch.ones(1, 8, 32), device="cpu"
        )
        unique, inverse = packed.layout.row_timesteps(0.5)
        endpoints = module.hyperflow_endpoints(unique, 0.5, 0.25)[inverse]
        ref_count = packed.layout.num_condition_video_rows
        torch.testing.assert_close(endpoints[packed.layout.video_indices[:ref_count]], torch.full((ref_count,), 0.999))
        assert bool((endpoints[packed.layout.video_indices[ref_count:]] == 0.75).all())
        assert bool((endpoints[packed.layout.audio_indices] == 1).all())
    finally:
        sys.modules.pop(spec.name, None)


class TinyTokenizer:
    def __call__(self, text, *, add_special_tokens):
        assert add_special_tokens is False
        return {"input_ids": [ord(char) for char in text]}

    def convert_tokens_to_ids(self, token):
        return {"<|vision_start|>": 1000, "<|video_pad|>": 1001, "<|vision_end|>": 1002}[token]


class TinyVideoProcessor:
    temporal_patch_size = 2

    def __call__(self, *, videos, do_sample_frames, return_tensors):
        assert do_sample_frames is False and return_tensors == "pt"
        self.sampled = videos[0]
        blocks = (len(self.sampled) + 1) // 2
        return {"pixel_values_videos": torch.ones(blocks, 4), "video_grid_thw": torch.tensor([[blocks, 2, 2]])}


@pytest.mark.parametrize("frames,blocks,last_index", [(124, 6, 120), (360, 15, 348), (362, 16, 360)])
def test_qwen_presentation_sees_complete_real_timeline(processing, frames, blocks, last_index):
    video_processor = TinyVideoProcessor()
    processor = SimpleNamespace(image_processor=SimpleNamespace(merge_size=2), video_processor=video_processor)
    # Encode each frame index into red/green bytes; rescaling is lossless.
    pixels = torch.zeros(frames, 3, 1, 1)
    pixels[:, 0, 0, 0] = torch.arange(frames) % 256 / 255
    pixels[:, 1, 0, 0] = torch.arange(frames) // 256 / 255
    draft = processing.ICDraft(pixels, frames, 24.0)
    presentation = processing.prepare_video_reference(draft, processor, TinyTokenizer(), "最后一帧保持原场景")
    sampled = video_processor.sampled
    assert int(sampled[-1, 0, 0, 0]) + 256 * int(sampled[-1, 0, 0, 1]) == last_index
    assert len(sampled) == (frames + 11) // 12
    assert presentation.token_ids.count(1001) == blocks
    assert presentation.prompt == processing.IC_TASK + "\n\nScene description: 最后一帧保持原场景"
    assert presentation.token_ids[-len(presentation.prompt) :] == [ord(char) for char in presentation.prompt]
    assert bool((presentation.text_token_tags[presentation.drop_prefix_length :] == 1).all())


class Conditioner(nn.Module):
    def __init__(self, num_layers):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros(1))
        self.config = SimpleNamespace(text_config=SimpleNamespace(num_hidden_layers=num_layers))
        self.calls = 0
        self.model = self.run_model

    @property
    def dtype(self):
        return self.weight.dtype

    def run_model(self, **kwargs):
        self.calls += 1
        assert kwargs["use_cache"] is False
        assert kwargs["output_hidden_states"] is True
        assert kwargs["mm_token_type_ids"].dtype == torch.long
        count = kwargs["input_ids"].shape[1]
        return SimpleNamespace(hidden_states=[torch.full((1, count, 5120), float(index)) for index in range(52)])


def test_real_qwen_helper_reads_50_and_rejects_postnorm_truncation(processing):
    presentation = processing.ICPromptPresentation([1, 2, 3], torch.tensor([0, 1, 1]), {}, 1, "task")
    processor = SimpleNamespace(create_mm_token_type_ids=lambda ids: [[0] * len(ids[0])])
    encoder = Conditioner(51)
    result = processing.encode_tokens_first(encoder, processor, presentation, device="cpu")
    assert result.prompt_embeds.dtype == torch.bfloat16
    assert not result.prompt_embeds.is_inference()
    assert bool((result.prompt_embeds == 50).all())
    truncated = Conditioner(50)
    with pytest.raises(ValueError, match="post-norm"):
        processing.encode_tokens_first(truncated, processor, presentation, device="cpu")
    assert truncated.calls == 0


class InspectableAudioVAE(nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(1))
        self.config = SimpleNamespace(
            sampling_rate=32000, latent_channels=32, latents_mean=[2.0] * 32, latents_std=[2.0] * 32
        )
        self.hop_length = 800
        self.seen = None

    def encode(self, waveform, *, return_dict):
        assert return_dict is False
        assert bool((waveform == 0).all())
        assert waveform.shape[:2] == (2, 1)
        self.seen = waveform.shape
        encoded = (waveform.shape[-1] + 799) // 800
        latent = torch.arange(encoded).float()[None, None].expand(2, 32, -1).clone()
        latent[1] += 10000
        return (SimpleNamespace(mode=lambda: latent),)


@pytest.mark.parametrize("frames,audio_t", [(124, 207), (360, 600), (362, 603)])
def test_dynamic_silence_encodes_actual_waveform_and_crops_each_channel(processing, frames, audio_t):
    vae = InspectableAudioVAE()
    provider = processing.DiffusersSilenceProvider(vae)
    rows = provider.rows(frames, audio_t)
    assert vae.seen == (2, 1, round(frames / 24 * 32000))
    assert rows.shape == (1, 2 * audio_t, 32)
    assert rows.dtype == torch.float32 and rows.device.type == "cpu"
    assert not rows.is_inference()
    torch.testing.assert_close(rows[0, :audio_t, 0], (torch.arange(audio_t).float() - 2) / 2)
    torch.testing.assert_close(rows[0, audio_t:, 0], (torch.arange(audio_t).float() + 10000 - 2) / 2)
    with pytest.raises(ValueError, match="require"):
        provider.rows(frames, audio_t - 1)


def test_real_small_diffusers_audio_vae_encodes_full_duration(processing):
    from diffusers import AutoencoderKLMiniMaxH3Audio

    torch.manual_seed(11)
    vae = AutoencoderKLMiniMaxH3Audio(
        encoder_dim=2,
        latent_dim=32,
        latent_channels=32,
        num_attention_heads=1,
        decoder_dim=128,
        latents_mean=[0.1] * 32,
        latents_std=[1.5] * 32,
    ).eval()
    provider = processing.DiffusersSilenceProvider(vae)
    rows = provider.rows(362, 603)
    assert not rows.is_inference()
    with torch.inference_mode():
        posterior = vae.encode(torch.zeros(2, 1, round(362 / 24 * 32000)), return_dict=False)[0]
        expected = ((posterior.mode()[:, :, :603] - 0.1) / 1.5).transpose(1, 2).reshape(1, 1206, 32)
    torch.testing.assert_close(rows, expected, rtol=0, atol=0)
    assert bool(torch.isfinite(rows).all())
    assert bool((rows != 0).any())


def test_exact_asset_duration_hash_and_channel_order(processing, tmp_path):
    latent = torch.arange(2 * 32 * 207).float().reshape(2, 32, 207)
    path = tmp_path / "silence_124.safetensors"
    save_file({"audio_latents": latent}, str(path))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    asset = processing.SilenceAsset(path, digest, 124)
    provider = processing.HashVerifiedSilenceProvider({124: asset})
    rows = provider.rows(124, 207)
    torch.testing.assert_close(rows, latent.transpose(1, 2).reshape(1, 414, 32))
    with pytest.raises(ValueError, match="exact-duration"):
        provider.rows(362, 603)
    bad = processing.HashVerifiedSilenceProvider({124: processing.SilenceAsset(path, "0" * 64, 124)})
    with pytest.raises(ValueError, match="SHA256 mismatch"):
        bad.rows(124, 207)


def test_draft_reader_preserves_canvas_and_audio_metadata(processing, tmp_path):
    import av

    path = tmp_path / "draft.mkv"
    with av.open(str(path), "w") as output:
        stream = output.add_stream("ffv1", rate=24)
        stream.width, stream.height, stream.pix_fmt = 1280, 768, "bgr0"
        pixels = np.zeros((768, 1280, 3), dtype=np.uint8)
        for index in range(22):
            pixels[..., 0] = index
            frame = av.VideoFrame.from_ndarray(pixels, format="rgb24")
            for packet in stream.encode(frame):
                output.mux(packet)
        for packet in stream.encode():
            output.mux(packet)
    draft = processing.read_ic_draft(path)
    assert draft.num_frames == 22 and draft.pixels.shape == (22, 3, 768, 1280)
    assert draft.source_size == (768, 1280) and draft.resize_policy == "strict"
    assert draft.audio_from is None
    torch.testing.assert_close(draft.pixels[-1, 0, 0, 0], torch.tensor(21 / 255))
    with pytest.raises(ValueError, match="cropping requires"):
        processing.read_ic_draft(path, height=768, width=1344)
    with pytest.raises(ValueError, match="contains only"):
        processing.read_ic_draft(path, num_frames=124)


@pytest.mark.parametrize(
    "source_frames,source_fps,expected_frames",
    [(124, 24, 124), (360, 24, 360), (362, 24, 362), (450, 30, 360), (180, 12, 360)],
)
def test_real_long_media_timeline_with_small_canvas(
    processing, monkeypatch, tmp_path, source_frames, source_fps, expected_frames
):
    """Real long PyAV I/O, isolating the already-tested 768p canvas gate.

    The small raster keeps this CPU test suitable for ordinary CI hosts; it
    does not establish full-768p host memory or the final 2K media gate.
    """
    import av

    path = tmp_path / "long_with_audio.mkv"
    with av.open(str(path), "w") as output:
        stream = output.add_stream("ffv1", rate=source_fps)
        stream.width, stream.height, stream.pix_fmt = 64, 32, "bgr0"
        audio_stream = output.add_stream("pcm_s16le", rate=32000)
        audio_stream.layout = "mono"
        pixels = np.zeros((32, 64, 3), dtype=np.uint8)
        for index in range(source_frames):
            pixels[..., 0], pixels[..., 1] = index % 256, index // 256
            frame = av.VideoFrame.from_ndarray(pixels, format="rgb24")
            for packet in stream.encode(frame):
                output.mux(packet)
        for packet in stream.encode():
            output.mux(packet)
        audio = av.AudioFrame.from_ndarray(
            np.zeros((1, round(source_frames / source_fps * 32000)), dtype=np.int16), format="s16", layout="mono"
        )
        audio.sample_rate = 32000
        for packet in audio_stream.encode(audio):
            output.mux(packet)
        for packet in audio_stream.encode():
            output.mux(packet)
    monkeypatch.setattr(processing, "_validate_draft_canvas", lambda height, width: None)
    draft = processing.read_ic_draft(path)
    assert draft.num_frames == expected_frames
    assert draft.pixels.shape == (expected_frames, 3, 32, 64)
    assert draft.audio_from == path.resolve()
    assert draft.source_fps == source_fps
    recovered = (draft.pixels[:, 0, 0, 0] * 255).round() + 256 * (draft.pixels[:, 1, 0, 0] * 255).round()
    expected = torch.tensor([int(index * source_fps / 24) for index in range(expected_frames)]).float()
    torch.testing.assert_close(recovered, expected, rtol=0, atol=0)


def test_real_pts_gap_cannot_silently_compress_duration(processing, monkeypatch, tmp_path):
    import av

    path = tmp_path / "timestamp_gap.mkv"
    with av.open(str(path), "w") as output:
        stream = output.add_stream("ffv1", rate=24)
        stream.width, stream.height, stream.pix_fmt = 64, 32, "bgr0"
        for index in range(22):
            frame = av.VideoFrame.from_ndarray(np.zeros((32, 64, 3), dtype=np.uint8), format="rgb24")
            frame.pts = index if index < 11 else index + 24
            frame.time_base = Fraction(1, 24)
            for packet in stream.encode(frame):
                output.mux(packet)
        for packet in stream.encode():
            output.mux(packet)
    monkeypatch.setattr(processing, "_validate_draft_canvas", lambda height, width: None)
    with pytest.raises(ValueError, match="constant-frame-rate timestamps without gaps"):
        processing.read_ic_draft(path)
