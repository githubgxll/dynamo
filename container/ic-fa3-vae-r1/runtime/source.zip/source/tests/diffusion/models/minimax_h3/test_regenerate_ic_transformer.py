# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Real CPU tensor tests; these do not qualify GPU, SP, HSDP or video output."""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from types import SimpleNamespace

import pytest
import torch
import torch.nn.functional as F
from torch import nn

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


@pytest.fixture(scope="module")
def adapter_module():
    path = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion/models/minimax_h3/regenerate_ic_transformer.py"
    spec = importlib.util.spec_from_file_location("_test_h3_ic_transformer", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
        yield module
    finally:
        sys.modules.pop(spec.name, None)


class TinyTimeProjection(nn.Module):
    def forward(self, times):
        return torch.stack((times, times.square()), dim=-1)


class TinyTimeMLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear_1 = nn.Linear(2, 2)
        self.linear_2 = nn.Linear(2, 2)

    def forward(self, x):
        return self.linear_2(F.silu(self.linear_1(x)))


class TinyBlock(nn.Module):
    def __init__(self):
        super().__init__()
        self.attn = nn.Module()
        for name in ("to_q", "to_k", "to_v"):
            setattr(self.attn, name, nn.Linear(2, 2, bias=False, dtype=torch.bfloat16))
        self.attn.to_out = nn.ModuleList([nn.Linear(2, 2, bias=False, dtype=torch.bfloat16)])
        self.ff = nn.Module()
        gate = nn.Module()
        gate.proj = nn.Linear(2, 4, bias=False, dtype=torch.bfloat16)
        self.ff.net = nn.ModuleList([gate, nn.Identity(), nn.Linear(2, 2, bias=False, dtype=torch.bfloat16)])
        self.adaln_proj = nn.Module()
        self.adaln_proj.linear = nn.Linear(2, 2, dtype=torch.bfloat16)


class TinyTransformer(nn.Module):
    """Only the adapter's real Linear/timestep boundaries; no attention mock."""

    def __init__(self):
        super().__init__()
        self.time_proj = TinyTimeProjection()
        self.time_embedder = TinyTimeMLP()
        self.transformer_blocks = nn.ModuleList([TinyBlock()])
        self.barrier = None
        self.fail = False
        self.nested_call = None
        with torch.no_grad():
            self.transformer_blocks[0].attn.to_q.weight.fill_(1.0)

    def forward(self, x, *, timestep):
        if self.barrier is not None:
            self.barrier.wait(timeout=10)
        if self.fail:
            raise RuntimeError("controlled model failure")
        time = self.time_embedder(self.time_proj(timestep))
        if self.nested_call is not None:
            callback, self.nested_call = self.nested_call, None
            callback()
        block = self.transformer_blocks[0]
        return SimpleNamespace(time=time, curve=block.adaln_proj.linear(time), projection=block.attn.to_q(x))


def _metadata():
    return {
        "hyperflow": "true",
        "hyperflow_version": "1.0",
        "block_dtype": "bf16",
        "time_embedder_dtype": "fp32",
        "hyperflow_gate": "0.7",
        "lora_rank": "2",
        "lora_alpha": "2",
        "hyperflow_video_shift": "12",
        "hyperflow_sigmas": json.dumps([1.0, 0.875, 0.75, 0.625, 0.5, 0.375, 0.25, 0.125, 0.0]),
    }


def _add_pair(weights, name, in_features, out_features, *, prefix="transformer.", value=0.002):
    weights[prefix + name + ".lora_A.weight"] = torch.ones(2, in_features)
    weights[prefix + name + ".lora_B.weight"] = torch.full((out_features, 2), value)


def _hyperflow():
    weights = {}
    for target in ("attn.to_q", "attn.to_k", "attn.to_v", "attn.to_out.0", "ff.net.0.proj", "ff.net.2"):
        _add_pair(weights, "transformer_blocks.0." + target, 2, 4 if target == "ff.net.0.proj" else 2)
    for root, value in (("time_embedder", 0.01), ("endpoint_time_embedder", 0.02)):
        for linear in ("linear_1", "linear_2"):
            _add_pair(weights, root + "." + linear, 2, 2, value=value)
    return weights


def _sharp():
    weights = {}
    _add_pair(weights, "blocks.0.attn.qkv_proj", 2, 6, prefix="diffusion_model.")
    _add_pair(weights, "blocks.0.attn.out_proj", 2, 2, prefix="diffusion_model.")
    _add_pair(weights, "blocks.0.mlp.fc2", 2, 2, prefix="diffusion_model.")
    _add_pair(weights, "blocks.0.adaln_proj.linear", 8, 2, prefix="diffusion_model.", value=0.03)
    # The two halves deliberately differ, making the gate/value permutation observable.
    _add_pair(weights, "blocks.0.mlp.fc1", 2, 4, prefix="diffusion_model.", value=0.0)
    weights["diffusion_model.blocks.0.mlp.fc1.lora_B.weight"] = torch.tensor(
        [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0], [7.0, 8.0]]
    )
    return weights


def _table():
    positions = torch.arange(1025, dtype=torch.float32).unsqueeze(1) / 1024
    return positions * torch.arange(1, 9, dtype=torch.float32).unsqueeze(0)


def _ic(model):
    weights = {}
    for name in model._ic_targets():
        layer = model.model.get_submodule(name)
        _add_pair(weights, name, layer.in_features, layer.out_features, value=0.1)
    return weights


def _ready(module, *, strength=1.0):
    torch.manual_seed(3)
    model = module.MiniMaxH3ICTransformer(TinyTransformer())
    model.install_hyperflow(_hyperflow(), _metadata())
    model.install_sharp(_sharp(), _table(), strength=strength, rank=2)
    model.install_ic(_ic(model), rank=2, alpha=2, expected_modules=6)
    return model


def test_hyperflow_endpoint_copies_pre_adapter_base(adapter_module):
    torch.manual_seed(1)
    base = TinyTransformer()
    original = copy.deepcopy(base.time_embedder)
    model = adapter_module.MiniMaxH3ICTransformer(base)
    model.install_hyperflow(_hyperflow(), _metadata())
    endpoint = model.model.time_embedder.endpoint
    for name in ("linear_1", "linear_2"):
        expected = original.get_submodule(name).weight + 0.04
        torch.testing.assert_close(endpoint.get_submodule(name).weight, expected, atol=1e-7, rtol=0)
        torch.testing.assert_close(endpoint.get_submodule(name).bias, original.get_submodule(name).bias)
    # A second HyperFlow install cannot copy an already modified start branch.
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="current state"):
        model.install_hyperflow(_hyperflow(), _metadata())


def test_sequential_bf16_rounding_and_sharp_mlp_layout(adapter_module):
    base = TinyTransformer()
    mlp_before = base.transformer_blocks[0].ff.net[0].proj.weight.detach().clone()
    model = adapter_module.MiniMaxH3ICTransformer(base)
    model.install_hyperflow(_hyperflow(), _metadata())
    model.install_sharp(_sharp(), _table(), rank=2)
    q = model.model.transformer_blocks[0].attn.to_q.weight
    staged = (torch.ones(2, 2) + 0.004).bfloat16()
    expected = (staged.float() + 0.004).bfloat16()
    torch.testing.assert_close(q, expected, atol=0, rtol=0)
    assert not torch.equal(q, (torch.ones(2, 2) + 0.008).bfloat16())
    native_b = _sharp()["diffusion_model.blocks.0.mlp.fc1.lora_B.weight"]
    expected_b = torch.cat((native_b[2:], native_b[:2]))
    mlp_after_hyperflow = (mlp_before.float() + 0.004).bfloat16()
    mlp_expected = (mlp_after_hyperflow.float() + expected_b @ torch.ones(2, 2)).bfloat16()
    torch.testing.assert_close(model.model.transformer_blocks[0].ff.net[0].proj.weight, mlp_expected, atol=0, rtol=0)


@pytest.mark.parametrize("strength", [0.0, 1.0])
def test_forward_matches_explicit_two_time_curve_and_unmerged_math(adapter_module, strength):
    model = _ready(adapter_module, strength=strength)
    t, r = torch.tensor([0.0, 0.1234, 1.0]), torch.tensor([0.1, 0.5, 1.0])
    x = torch.tensor([[0.25, -0.5], [1.0, 0.25], [-1.0, 2.0]], dtype=torch.bfloat16)
    result = model(x, timestep=t, endpoint_timestep=r)
    embedder = model.model.time_embedder
    time = embedder.base(model.model.time_proj(t))
    expected_time = time + 0.7 * (embedder.endpoint(model.model.time_proj(r)) - time)
    torch.testing.assert_close(result.time, expected_time, atol=0, rtol=0)
    branch = model.model.transformer_blocks[0].adaln_proj.linear
    # This table is linear in time, so the independent closed-form value is exact within FP32 tolerance.
    coords = t[:, None] * torch.arange(1, 9, dtype=torch.float32)[None]
    expected_curve = branch.base(expected_time.bfloat16())
    delta = F.linear(F.linear(coords, branch.curve_a), branch.curve_b)
    expected_curve = expected_curve + delta.bfloat16() * strength
    torch.testing.assert_close(result.curve, expected_curve, atol=0.015625, rtol=0)
    q = model.model.transformer_blocks[0].attn.to_q
    expected_q = q.base(x) + F.linear(F.linear(x, q.lora_A.bfloat16()), q.lora_B.bfloat16())
    torch.testing.assert_close(result.projection, expected_q, atol=0, rtol=0)
    assert q.lora_A.dtype == q.lora_B.dtype == torch.float32
    model.validate_precision()
    assert model._evaluation.get() is None


def test_scope_restores_after_nested_calls_failure_and_parallel_threads(adapter_module):
    model = _ready(adapter_module)
    x = torch.ones(1, 2, dtype=torch.bfloat16)
    t, outer_r, inner_r = torch.tensor([0.2]), torch.tensor([0.8]), torch.tensor([0.5])
    expected = model(x, timestep=t, endpoint_timestep=outer_r)
    model.model.nested_call = lambda: model(x, timestep=t, endpoint_timestep=inner_r)
    nested = model(x, timestep=t, endpoint_timestep=outer_r)
    torch.testing.assert_close(nested.curve, expected.curve, atol=0, rtol=0)
    model.model.fail = True
    with pytest.raises(RuntimeError, match="controlled"):
        model(x, timestep=t, endpoint_timestep=outer_r)
    assert model._evaluation.get() is None
    model.model.fail = False
    expected_inner = model(x, timestep=t, endpoint_timestep=inner_r)
    model.model.barrier = Barrier(2)
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(model, x, timestep=t, endpoint_timestep=r) for r in (outer_r, inner_r)]
        outputs = [future.result(timeout=15) for future in futures]
    torch.testing.assert_close(outputs[0].time, expected.time, atol=0, rtol=0)
    torch.testing.assert_close(outputs[1].time, expected_inner.time, atol=0, rtol=0)
    assert model._evaluation.get() is None


def test_schedule_and_generated_endpoint_validation(adapter_module):
    metadata = _metadata()
    result = adapter_module.hyperflow_sigmas(metadata)
    raw = torch.tensor(json.loads(metadata["hyperflow_sigmas"]), dtype=torch.float32)
    torch.testing.assert_close(result, 12 * raw / (1 + 11 * raw), atol=0, rtol=0)
    times = torch.tensor([0.0, 0.2, 0.999, 1.0])
    endpoints = adapter_module.hyperflow_endpoints(times, 0.8, 0.5)
    torch.testing.assert_close(endpoints, torch.tensor([0.0, 0.5, 0.999, 1.0]), atol=1e-7, rtol=0)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="exactly one"):
        adapter_module.hyperflow_endpoints(torch.tensor([0.2, 0.2]), 0.8, 0.5)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="shift"):
        adapter_module.hyperflow_sigmas(metadata, shift=6)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="decrease"):
        adapter_module.hyperflow_sigmas(dict(metadata, hyperflow_sigmas=json.dumps([1.0] * 8 + [0.0])))


def test_strict_shape_duplicate_keys_and_order_are_rejected_before_mutation(adapter_module):
    model = adapter_module.MiniMaxH3ICTransformer(TinyTransformer())
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="requires sharp"):
        model.install_ic({}, rank=2, alpha=2, expected_modules=6)
    before = {key: value.detach().clone() for key, value in model.model.named_parameters()}
    broken = _hyperflow()
    broken["transformer.transformer_blocks.0.attn.to_q.lora_B.weight"] = torch.ones(3, 2)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="shape mismatch"):
        model.install_hyperflow(broken, _metadata())
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="duplicate"):
        model.install_hyperflow(list(_hyperflow().items()) * 2, _metadata())
    assert model._stage == "base"
    for key, value in model.model.named_parameters():
        torch.testing.assert_close(value, before[key], atol=0, rtol=0)
    model.install_hyperflow(_hyperflow(), _metadata())
    sharp = _sharp()
    sharp.pop("diffusion_model.blocks.0.adaln_proj.linear.lora_A.weight")
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="incomplete"):
        model.install_sharp(sharp, _table(), rank=2)
    assert model._stage == "hyperflow"


def test_ic_exact_target_coverage_and_fp32_masters(adapter_module):
    model = adapter_module.MiniMaxH3ICTransformer(TinyTransformer())
    model.install_hyperflow(_hyperflow(), _metadata())
    model.install_sharp(_sharp(), _table(), rank=2)
    weights = _ic(model)
    name = next(iter(weights))
    weights[name] = weights[name].bfloat16()
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="FP32"):
        model.install_ic(weights, rank=2, alpha=2, expected_modules=6)
    missing = _ic(model)
    missing.pop(next(iter(missing)))
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="incomplete"):
        model.install_ic(missing, rank=2, alpha=2, expected_modules=6)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="exactly 312"):
        model.install_ic(_ic(model), rank=2, alpha=2)
    model.install_ic(_ic(model), rank=2, alpha=2, expected_modules=6)
    model.to(dtype=torch.bfloat16)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="precision"):
        model.validate_precision()


def test_zero_sharp_skips_numerically_unused_updates(adapter_module):
    model = adapter_module.MiniMaxH3ICTransformer(TinyTransformer())
    model.install_hyperflow(_hyperflow(), _metadata())
    sharp = {key: torch.full_like(value, 1e30) for key, value in _sharp().items()}
    model.install_sharp(sharp, _table(), strength=0.0, rank=2)
    model.install_ic(_ic(model), rank=2, alpha=2, expected_modules=6)
    output = model(
        torch.ones(1, 2, dtype=torch.bfloat16), timestep=torch.tensor([0.2]), endpoint_timestep=torch.tensor([0.5])
    )
    assert bool(torch.isfinite(output.curve).all())
    assert bool(torch.isfinite(output.projection).all())


def test_fp16_base_and_merge_overflow_are_rejected(adapter_module):
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="checkpoint precision"):
        adapter_module.MiniMaxH3ICTransformer(TinyTransformer().half())
    model = adapter_module.MiniMaxH3ICTransformer(TinyTransformer())
    weights = _hyperflow()
    weights["transformer.transformer_blocks.0.attn.to_q.lora_A.weight"].fill_(1e30)
    weights["transformer.transformer_blocks.0.attn.to_q.lora_B.weight"].fill_(1e30)
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="overflowed"):
        model.install_hyperflow(weights, _metadata())
    # A failed mutation cannot later be mistaken for a ready model or retried over partially merged weights.
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="current state"):
        model.install_hyperflow(_hyperflow(), _metadata())


def test_no_endpoint_state_survives_invalid_or_unscoped_forward(adapter_module):
    model = _ready(adapter_module)
    x, t = torch.ones(1, 2, dtype=torch.bfloat16), torch.tensor([0.2])
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="match timestep"):
        model(x, timestep=t, endpoint_timestep=torch.tensor([0.5, 0.8]))
    with pytest.raises(adapter_module.MiniMaxH3ICTransformerError, match="not bound"):
        model.model.time_embedder(model.model.time_proj(t))
    assert model._evaluation.get() is None
    assert not model.supports_sequence_parallel


def test_real_diffusers_tiny_model_component_contract(adapter_module):
    from diffusers.models.transformers.transformer_minimax_h3 import MiniMaxH3Transformer3DModel

    base = MiniMaxH3Transformer3DModel(
        num_attention_heads=1,
        attention_head_dim=6,
        hidden_size=6,
        num_layers=1,
        num_refiner_layers=0,
        ffn_dim=4,
        in_channels=2,
        audio_in_channels=2,
        patch_size=(1, 1, 1),
        text_dim=4,
        freq_dim=4,
        time_embed_hidden_dim=6,
        time_embed_dim=4,
        rope_freq_dim=1,
    ).to(dtype=torch.bfloat16)
    for name in ("proj_in", "audio_proj_in", "time_embedder", "proj_out", "audio_proj_out"):
        base.get_submodule(name).float()
    model = adapter_module.MiniMaxH3ICTransformer(base)
    selected = [name for name, module in model.named_modules() if model._is_transformer_block(name, module)]
    assert selected == ["model.transformer_blocks.0"]
    assert len(model._ic_targets()) == 6
    assert model._hsdp_preserve_parameter_dtypes
    assert all(model.get_submodule(name) is not None for name in model._hsdp_ignored_modules)
    hf = {}
    names = model._ic_targets() | {
        root + "." + linear
        for root in ("time_embedder", "endpoint_time_embedder")
        for linear in ("linear_1", "linear_2")
    }
    for name in names:
        lookup = name.replace("endpoint_time_embedder.", "time_embedder.")
        layer = base.get_submodule(lookup)
        _add_pair(hf, name, layer.in_features, layer.out_features)
    sharp = {}
    block = base.transformer_blocks[0]
    for source, layer, rows in (
        ("attn.qkv_proj", block.attn.to_q, 3 * block.attn.to_q.out_features),
        ("attn.out_proj", block.attn.to_out[0], block.attn.to_out[0].out_features),
        ("mlp.fc1", block.ff.net[0].proj, block.ff.net[0].proj.out_features),
        ("mlp.fc2", block.ff.net[2], block.ff.net[2].out_features),
    ):
        _add_pair(sharp, "blocks.0." + source, layer.in_features, rows, prefix="diffusion_model.")
    _add_pair(sharp, "blocks.0.adaln_proj.linear", 8, block.adaln_proj.linear.out_features, prefix="diffusion_model.")
    model.install_hyperflow(hf, _metadata())
    model.install_sharp(sharp, _table(), rank=2)
    model.install_ic(_ic(model), rank=2, alpha=2, expected_modules=6)
    inputs = dict(
        hidden_states=torch.tensor([[[0.1, 0.2]]]),
        audio_hidden_states=torch.zeros(1, 1, 2),
        encoder_hidden_states=torch.tensor([[[0.3, 0.4, 0.5, 0.6]]]),
        timestep=torch.tensor([0.2, 1.0]),
        timestep_indices=torch.tensor([1, 0, 1]),
        token_tags=torch.tensor([1, 0, 2]),
        position_ids=torch.zeros(3, 3),
        video_indices=torch.tensor([1]),
        audio_indices=torch.tensor([2]),
        text_indices=torch.tensor([0]),
    )
    with torch.no_grad():
        output = model(**inputs, endpoint_timestep=torch.tensor([0.5, 1.0]))
    assert output.sample.shape == output.audio_sample.shape == (1, 1, 2)
    assert bool(torch.isfinite(output.sample).all()) and bool(torch.isfinite(output.audio_sample).all())
    model.validate_precision()
    assert model._evaluation.get() is None
