# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""IC metadata/asset checks; synthetic files here are not model weights."""

from __future__ import annotations

import importlib.util
import json
import sys
from collections.abc import Iterator
from pathlib import Path
from types import ModuleType

import pytest

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]

_BASE_REVISION = "42ed227ee7df40d41602854ae760620d6eb651fe"
_FA3_REVISION = "c0a7c25685c2339ebc71a2a2d824b02f93cc725b"
_COMPONENTS = {
    "lora": "lora/open_h3_regenerate_2k_ic_lora.safetensors",
    "lora_config": "lora/lora_config.json",
    "hyperflow": "lora/minimax_h3_hyperflow_8step_v1.0.safetensors",
    "sharp_lora": "lora/minimax_h3_lms_v1.0_r64.safetensors",
    "sharp_curve": "sharp/lms_curve.bin",
    "silence_audio": "assets/silence_audio_124f.safetensors",
    "latent_upsampler": "latent_upsampler/minimax_h3_latent_upscaler_3d_conv_v1_bf16.safetensors",
}


def _write_json(path: Path, document: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document), encoding="utf-8")


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def ic_bundle_module() -> Iterator[ModuleType]:
    # The parser is stdlib-only. Load its file without importing the parent
    # package, whose __init__ requires the full vLLM runtime even for CPU tests.
    path = Path(__file__).resolve().parents[4] / "vllm_omni/diffusion/models/minimax_h3/regenerate_ic.py"
    spec = importlib.util.spec_from_file_location("_test_h3_ic_bundle", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
        yield module
    finally:
        sys.modules.pop(spec.name, None)


@pytest.fixture
def bundle_root(tmp_path: Path) -> Path:
    """Tiny metadata and placeholder bytes for asset discovery, not inference."""
    root = tmp_path / "ic"
    config = {
        "name": "Open-H3-Regenerate-2K-IC",
        "base_model": "MiniMaxAI/MiniMax-H3",
        "base_model_revision": _BASE_REVISION,
        "base_component": "transformer_ref",
        "components": dict(
            _COMPONENTS,
            # These release descriptions are not required runtime paths.
            base_model="base_model/ (unmodified copy)",
            merged_lora="lora/merged.safetensors (made locally)",
            vae_fast="vae_fast/not-needed.safetensors",
        ),
        "draft": {"width": 1344, "height": 768, "fps": 24, "frames": 124},
        "sampler": {
            "default": "up3",
            "up3": {"steps": 3, "sigmas": [0.834942, 0.696852, 0.468753, 0.0]},
            "guidance_scale": 1.0,
            "sharp": 1.0,
        },
        "attention": {"fa3_hub_revision": _FA3_REVISION},
    }
    _write_json(root / "config.json", config)
    for value in _COMPONENTS.values():
        path = root / value
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"synthetic asset bytes, not model weights")
    _write_json(
        root / _COMPONENTS["lora_config"],
        {
            "base_model": f"MiniMaxAI/MiniMax-H3@{_BASE_REVISION} (transformer_ref, Diffusers layout)",
            "target_component": "transformer_ref",
            "rank": 384,
            "alpha": 384,
            "modules": 312,
            "dtype": "float32",
            "file": Path(_COMPONENTS["lora"]).name,
        },
    )
    _write_json(
        root / "base_model/transformer_ref/config.json",
        {
            "_class_name": "MiniMaxH3Transformer3DModel",
            "num_attention_heads": 56,
            "attention_head_dim": 128,
            "hidden_size": 5376,
            "num_layers": 50,
            "num_refiner_layers": 2,
            "in_channels": 24,
            "audio_in_channels": 32,
            "patch_size": [1, 2, 2],
            "text_dim": 5120,
        },
    )
    _write_json(
        root / "base_model/vae/config.json",
        {
            "_class_name": "AutoencoderKLMiniMaxH3",
            "in_channels": 3,
            "out_channels": 3,
            "latent_channels": 24,
            "clip_length": 17,
            "token_drop": 3,
            "spatial_downsample_factors": [2, 2, 2, 2, 1, 1],
            "temporal_downsample_factors": [1, 2, 2, 1, 1, 1],
            "latents_mean": [0.0] * 24,
            "latents_std": [1.0] * 24,
        },
    )
    _write_json(
        root / "base_model/text_encoder/config.json",
        {
            "model_type": "qwen3_vl",
            "architectures": ["Qwen3VLForConditionalGeneration"],
            "text_config": {"hidden_size": 5120, "num_hidden_layers": 64},
        },
    )
    for folder, filenames in (
        ("processor", ("preprocessor_config.json", "video_preprocessor_config.json", "chat_template.json")),
        ("tokenizer", ("tokenizer_config.json", "tokenizer.json", "vocab.json", "merges.txt")),
    ):
        for filename in filenames:
            path = root / "base_model" / folder / filename
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("{}", encoding="utf-8")
    for folder, stem in (
        ("transformer_ref", "diffusion_pytorch_model.safetensors"),
        ("vae", "diffusion_pytorch_model.safetensors"),
        ("text_encoder", "model.safetensors"),
    ):
        directory = root / "base_model" / folder
        (directory / stem).write_bytes(b"synthetic checkpoint bytes")
    return root


def test_reads_release_without_optional_fast_or_merged_assets(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    assert bundle.base_model_revision == _BASE_REVISION
    assert bundle.fa3_hub_revision == _FA3_REVISION
    assert bundle.transformer_path == bundle_root / "base_model/transformer_ref"
    assert bundle.vae_path == bundle_root / "base_model/vae"
    assert bundle.text_encoder_path == bundle_root / "base_model/text_encoder"
    assert bundle.processor_path == bundle_root / "base_model/processor"
    assert bundle.tokenizer_path == bundle_root / "base_model/tokenizer"
    assert bundle.silence_audio_path.name == "silence_audio_124f.safetensors"
    assert bundle.transformer_weight_files == (bundle.transformer_path / "diffusion_pytorch_model.safetensors",)
    bundle.validate_request()


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("name", "Open-H3-Regenerate-2K"),
        ("base_model", "other/H3"),
        ("base_model_revision", "main"),
        ("base_component", "transformer"),
    ],
)
def test_rejects_different_release(ic_bundle_module: ModuleType, bundle_root: Path, key: str, value: str) -> None:
    config = _read_json(bundle_root / "config.json")
    config[key] = value
    _write_json(bundle_root / "config.json", config)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match=key):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize("component", list(_COMPONENTS))
def test_requires_actual_component_file(ic_bundle_module: ModuleType, bundle_root: Path, component: str) -> None:
    (bundle_root / _COMPONENTS[component]).unlink()
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="missing or empty"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    "path", ["../outside.safetensors", "/outside.safetensors", "C:/outside.safetensors", "lora\\escape.safetensors", ""]
)
def test_component_cannot_escape_bundle(ic_bundle_module: ModuleType, bundle_root: Path, path: str) -> None:
    config = _read_json(bundle_root / "config.json")
    config["components"]["lora"] = path
    _write_json(bundle_root / "config.json", config)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="lora"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


def test_rejects_symlink_to_asset_outside_bundle(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    outside = bundle_root.parent / "outside.safetensors"
    outside.write_bytes(b"outside bytes")
    path = bundle_root / _COMPONENTS["lora"]
    path.unlink()
    try:
        path.symlink_to(outside)
    except OSError:
        pytest.skip("creating symlinks is unavailable")
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="outside"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


def test_accepts_only_caller_authorized_symlink_root(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    cache = bundle_root.parent / "approved-cache"
    cache.mkdir()
    target = cache / "blob"
    target.write_bytes(b"synthetic asset bytes")
    path = bundle_root / _COMPONENTS["lora"]
    path.unlink()
    try:
        path.symlink_to(target)
    except OSError:
        pytest.skip("creating symlinks is unavailable")
    config_path = bundle_root / "config.json"
    config = _read_json(config_path)
    config["trusted_asset_roots"] = [str(cache)]
    _write_json(config_path, config)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="outside"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    wrong_root = bundle_root.parent / "other-cache"
    wrong_root.mkdir()
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="outside"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(wrong_root,))
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(cache,))
    assert bundle.lora_path == target
    assert bundle.trusted_asset_roots == (cache,)


def test_indexed_weights_can_use_authorized_cache_root(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    cache = bundle_root.parent / "approved-cache"
    cache.mkdir()
    target = cache / "weight-blob"
    target.write_bytes(b"synthetic weight bytes")
    folder = bundle_root / "base_model/transformer_ref"
    logical_shard = folder / "cached-shard.safetensors"
    try:
        logical_shard.symlink_to(target)
    except OSError:
        pytest.skip("creating symlinks is unavailable")
    _write_json(folder / "diffusion_pytorch_model.safetensors.index.json", {"weight_map": {"a": logical_shard.name}})
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="outside"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(cache,))
    assert bundle.transformer_weight_files == (target,)


def test_lora_filename_contract_uses_logical_path(
    ic_bundle_module: ModuleType, bundle_root: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Exercise the post-resolution metadata contract on hosts without symlink
    # privilege. The separate real-symlink tests still qualify filesystem trust.
    cache = bundle_root.parent / "cache"
    cache.mkdir()
    target = cache / "content-addressed-blob"
    target.write_bytes(b"synthetic asset bytes")
    original = ic_bundle_module._required_file

    def resolve_asset(root: Path, value: object, *, name: str, trusted_asset_roots: tuple[Path, ...] = ()) -> Path:
        if name == "lora":
            assert value == _COMPONENTS["lora"]
            assert trusted_asset_roots == (cache,)
            return target
        return original(root, value, name=name, trusted_asset_roots=trusted_asset_roots)

    monkeypatch.setattr(ic_bundle_module, "_required_file", resolve_asset)
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(cache,))
    assert bundle.lora_path == target


def test_authorized_root_does_not_allow_parent_traversal(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    shared = bundle_root.parent / "shared"
    shared.mkdir()
    (shared / "lora.safetensors").write_bytes(b"synthetic bytes")
    path = bundle_root / "config.json"
    config = _read_json(path)
    config["components"]["lora"] = "../shared/lora.safetensors"
    _write_json(path, config)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="traversal"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(shared,))


@pytest.mark.parametrize("kind", ["missing", "file"])
def test_requires_existing_trusted_directories(ic_bundle_module: ModuleType, bundle_root: Path, kind: str) -> None:
    path = bundle_root.parent / "not-a-directory"
    if kind == "file":
        path.write_bytes(b"file")
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="existing directories"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root, trusted_asset_roots=(path,))


@pytest.mark.parametrize("document", ["not JSON", "[]"])
def test_rejects_bad_release_json(ic_bundle_module: ModuleType, bundle_root: Path, document: str) -> None:
    (bundle_root / "config.json").write_text(document, encoding="utf-8")
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    ("section", "key", "value"),
    [
        ("sampler", "default", "hf8"),
        ("sampler", "guidance_scale", 7.5),
        ("sampler", "guidance_scale", True),
        ("sampler", "sharp", 0.0),
        ("attention", "fa3_hub_revision", "main"),
    ],
)
def test_rejects_changed_release_recipe(
    ic_bundle_module: ModuleType, bundle_root: Path, section: str, key: str, value: object
) -> None:
    path = bundle_root / "config.json"
    document = _read_json(path)
    document[section][key] = value
    _write_json(path, document)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


def test_rejects_empty_checkpoint_file(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    path = bundle_root / "base_model/vae/diffusion_pytorch_model.safetensors"
    path.write_bytes(b"")
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="missing or empty"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


def test_checks_every_indexed_shard_and_deduplicates(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    folder = bundle_root / "base_model/transformer_ref"
    index = folder / "diffusion_pytorch_model.safetensors.index.json"
    _write_json(
        index, {"weight_map": {"a": "shard-1.safetensors", "b": "shard-1.safetensors", "c": "shard-2.safetensors"}}
    )
    (folder / "shard-1.safetensors").write_bytes(b"synthetic shard")
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match="shard-2"):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    (folder / "shard-2.safetensors").write_bytes(b"synthetic shard")
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    assert bundle.transformer_weight_files == (folder / "shard-1.safetensors", folder / "shard-2.safetensors")


@pytest.mark.parametrize("weight_map", [{}, {"a": "../outside.safetensors"}, {"a": None}])
def test_rejects_invalid_weight_index(ic_bundle_module: ModuleType, bundle_root: Path, weight_map: dict) -> None:
    index = bundle_root / "base_model/vae/diffusion_pytorch_model.safetensors.index.json"
    _write_json(index, {"weight_map": weight_map})
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("target_component", "transformer"),
        ("rank", 64),
        ("alpha", True),
        ("modules", 300),
        ("dtype", "bfloat16"),
        ("file", "other.safetensors"),
        ("base_model", "MiniMaxAI/MiniMax-H3@main"),
    ],
)
def test_rejects_incompatible_lora_metadata(
    ic_bundle_module: ModuleType, bundle_root: Path, key: str, value: object
) -> None:
    path = bundle_root / _COMPONENTS["lora_config"]
    document = _read_json(path)
    document[key] = value
    _write_json(path, document)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    ("key", "value"),
    [("num_layers", 49), ("num_attention_heads", 56.0), ("patch_size", [True, 2, 2]), ("in_channels", 16)],
)
def test_rejects_wrong_transformer_geometry(
    ic_bundle_module: ModuleType, bundle_root: Path, key: str, value: object
) -> None:
    path = bundle_root / "base_model/transformer_ref/config.json"
    document = _read_json(path)
    document[key] = value
    _write_json(path, document)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match=key):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("clip_length", 16),
        ("latents_std", [0.0] * 24),
        ("latents_mean", [0.0] * 16),
        ("spatial_downsample_factors", [2, 2, 2]),
    ],
)
def test_rejects_wrong_vae_contract(ic_bundle_module: ModuleType, bundle_root: Path, key: str, value: object) -> None:
    path = bundle_root / "base_model/vae/config.json"
    document = _read_json(path)
    document[key] = value
    _write_json(path, document)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError, match=key):
        ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)


@pytest.mark.parametrize(
    "arguments",
    [
        {"sampler": "hf8"},
        {"num_inference_steps": 4},
        {"num_inference_steps": True},
        {"guidance_scale": 7.5},
        {"guidance_scale": True},
        {"guidance_scale": float("nan")},
        {"sharp": 0.0},
        {"sharp": float("inf")},
    ],
)
def test_rejects_unqualified_request_recipe(ic_bundle_module: ModuleType, bundle_root: Path, arguments: dict) -> None:
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    with pytest.raises(ic_bundle_module.MiniMaxH3ICBundleError):
        bundle.validate_request(**arguments)


def test_accepts_explicit_qualified_recipe(ic_bundle_module: ModuleType, bundle_root: Path) -> None:
    bundle = ic_bundle_module.MiniMaxH3ICBundle.from_path(bundle_root)
    bundle.validate_request(sampler="up3", num_inference_steps=3, guidance_scale=1, sharp=1.0)
