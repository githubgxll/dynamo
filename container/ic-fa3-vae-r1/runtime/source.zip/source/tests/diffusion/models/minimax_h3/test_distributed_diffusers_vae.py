# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""CPU tensor contracts for H3 spatial VAE dispatch and owner-only output.

The small temporal oracle below follows Apache-2.0 Diffusers H3 VAE at
865e42151a86e911fd141b4e1504f87272c60ea8. These tests replace network layers
and collectives, not tensors. They do not establish NCCL or GPU qualification.
"""

from __future__ import annotations

import ast
import math
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


def _split_axis(length, tile, overlap, ratio):
    if length <= tile:
        return [0], [length], []
    count = math.ceil(length / tile)
    while tile * count - overlap * (count - 1) < length:
        count += 1
    overlaps = [overlap] * (count - 1)
    for i in range((tile * count - sum(overlaps) - length) // ratio):
        overlaps[i % len(overlaps)] += ratio
    starts = [0]
    for value in overlaps:
        starts.append(starts[-1] + tile - value)
    return starts, [tile] * count, overlaps


def _blend_reference(previous, current, overlap, dim):
    overlap = min(previous.shape[dim], current.shape[dim], overlap)
    weights = torch.arange(overlap, dtype=current.dtype, device=current.device) / overlap
    shape = [1] * current.ndim
    shape[dim] = overlap
    weights = weights.view(shape)
    head = [slice(None)] * current.ndim
    head[dim] = slice(0, overlap)
    tail = [slice(None)] * previous.ndim
    tail[dim] = slice(-overlap, None)
    mixed = previous[tuple(tail)] * (1 - weights) + current[tuple(head)] * weights
    rest = [slice(None)] * current.ndim
    rest[dim] = slice(overlap, None)
    return torch.cat((mixed, current[tuple(rest)]), dim)


class _ReferenceVae(torch.nn.Module):
    """Use the released tile geometry and deterministic tiny network operators."""

    def __init__(self):
        super().__init__()
        self.config = SimpleNamespace(
            clip_length=17,
            token_drop=3,
            latent_channels=2,
            latents_mean=(0.25, -0.5),
            latents_std=(2.0, 0.5),
        )
        self.spatial_compression_ratio = 2
        self.temporal_compression_ratio = 4
        self.tokens_chunk_size = 5
        self.token_overlap = 2
        self.frame_pre_padding = 3
        self.frame_overlap = 5
        self.use_tiling = True
        self.use_slicing = False
        self.tile_sample_min_height = 8
        self.tile_sample_min_width = 8
        self.tile_sample_min_overlap_height = 2
        self.tile_sample_min_overlap_width = 2
        self.anchor = torch.nn.Parameter(torch.zeros(()), requires_grad=False)
        self.quant_conv = torch.nn.Identity()
        self.post_quant_conv = torch.nn.Identity()

    @property
    def dtype(self):
        return self.anchor.dtype

    @property
    def device(self):
        return self.anchor.device

    def _split_tiles(self, length, tile_size, min_overlap):
        return _split_axis(length, tile_size, min_overlap, self.spatial_compression_ratio)

    @staticmethod
    def _blend(a, b, blend_extent, dim):
        return _blend_reference(a, b, blend_extent, dim)

    def _stitch_tiles(self, tiles, height_overlaps, width_overlaps):
        rows = []
        for i, row in enumerate(tiles):
            parts = []
            for j, value in enumerate(row):
                if i:
                    value = self._blend(tiles[i - 1][j], value, height_overlaps[i - 1], -2)
                if j:
                    value = self._blend(row[j - 1], value, width_overlaps[j - 1], -1)
                if i < len(tiles) - 1:
                    value = value[..., : -height_overlaps[i], :]
                if j < len(row) - 1:
                    value = value[..., :, : -width_overlaps[j]]
                parts.append(value)
            rows.append(torch.cat(parts, -1))
        return torch.cat(rows, -2)

    @staticmethod
    def encoder(x):
        # Posterior channels and nonlinear values detect ordering/crop errors.
        values = x[:, :2, ::4, ::2, ::2].float()
        return torch.cat((values, values.square() * 0.01), dim=1)

    @staticmethod
    def decoder(z):
        values = z[:, :1].float().repeat(1, 3, 1, 1, 1)
        return values.repeat_interleave(4, 2).repeat_interleave(2, 3).repeat_interleave(2, 4)

    def _encode_clip(self, value):
        return self._serial_clip(value, encode=True)

    def _decode_clip(self, value):
        return self._serial_clip(value, encode=False)

    def _serial_clip(self, value, *, encode):
        scale = 1 if encode else self.spatial_compression_ratio
        height, width = value.shape[-2] * scale, value.shape[-1] * scale
        ys, hs, yo = self._split_tiles(height, self.tile_sample_min_height, self.tile_sample_min_overlap_height)
        xs, ws, xo = self._split_tiles(width, self.tile_sample_min_width, self.tile_sample_min_overlap_width)
        operator = self.encoder if encode else self.decoder
        tiles = [
            [operator(value[..., y // scale : (y + h) // scale, x // scale : (x + w) // scale]) for x, w in zip(xs, ws)]
            for y, h in zip(ys, hs)
        ]
        output_scale = self.spatial_compression_ratio if encode else 1
        return self._stitch_tiles(tiles, [v // output_scale for v in yo], [v // output_scale for v in xo])

    def encode(self, value, return_dict=True):
        if value.shape[2] == 1:
            moments = self._encode_clip(value)
        else:
            padding = (-value.shape[2]) % self.config.clip_length
            if padding:
                value = torch.cat((value, value[:, :, -1:].repeat(1, 1, padding, 1, 1)), 2)
            moments = torch.cat([self._encode_clip(clip) for clip in value.split(self.config.clip_length, dim=2)], 2)[
                :, :, : -self.config.token_drop
            ]
        posterior = _Posterior(moments)
        self.last_posterior = posterior
        return SimpleNamespace(latent_dist=posterior) if return_dict else (posterior,)


class _Posterior:
    instances = []

    def __init__(self, moments):
        self.parameters = moments
        self.mean, logvar = moments.chunk(2, dim=1)
        self.std = (0.5 * logvar.clamp(-30, 20)).exp()
        self.sample_calls = 0
        self.instances.append(self)

    def sample(self, generator):
        self.sample_calls += 1
        epsilon = torch.randn(self.mean.shape, generator=generator, dtype=self.mean.dtype, device="cpu")
        return self.mean + self.std * epsilon.to(self.mean.device)


@dataclass
class _GridSpec:
    split_dims: tuple
    grid_shape: tuple
    tile_spec: dict = field(default_factory=dict)
    output_dtype: torch.dtype | None = None


@dataclass
class _TileTask:
    tile_id: int
    grid_coord: tuple
    tensor: torch.Tensor
    workload: int | float = 1


@dataclass
class _Operator:
    split: object
    exec: object
    merge: object


class _Executor:
    """Synchronous in-process transport emulator; no real collectives."""

    def __init__(self, rank=0, world_size=8):
        self.rank = rank
        self.world_size = world_size
        self.parallel_size = world_size
        self.parallel_mode = "tile"
        self.events = []
        self.dispatch_counts = []
        self.clip_calls = 0
        self.sync_value = None

    @contextmanager
    def _sync_errors(self, stage):
        self.events.append((stage, "enter"))
        try:
            yield
        except Exception:
            self.events.append((stage, "error"))
            raise
        else:
            self.events.append((stage, "exit"))

    def execute(self, value, operator, broadcast_result=True):
        assert broadcast_result is True
        self.clip_calls += 1
        tasks, spec = operator.split(value)
        loads = [0] * self.world_size
        counts = [0] * self.world_size
        for task in sorted(tasks, key=lambda item: item.workload, reverse=True):
            index = loads.index(min(loads))
            loads[index] += task.workload
            counts[index] += 1
        self.dispatch_counts = counts
        # Reverse transport arrival order must not change the original stitch order.
        outputs = {task.grid_coord: operator.exec(task) for task in reversed(tasks)}
        result = operator.merge(outputs, spec)
        assert result.dtype == spec.output_dtype
        return result

    def _sync_final_result(self, value, ndim, device, dtype):
        assert ndim == 5
        if self.rank == 0:
            self.sync_value = value
        assert self.sync_value is not None
        assert self.sync_value.device == device
        assert self.sync_value.dtype == dtype
        return self.sync_value

    def set_parallel_size(self, parallel_size, mode):
        self.parallel_size = parallel_size
        self.parallel_mode = mode


class _Mixin:
    def is_distributed_enabled(self):
        return self.distributed_executor.parallel_size > 1

    def set_parallel_size(self, parallel_size, mode):
        self.distributed_executor.set_parallel_size(parallel_size, mode)


@pytest.fixture(scope="module")
def adapter_type():
    """Load only adapter definitions, avoiding CUDA serving-stack imports.

    Network layers are intentionally replaced by _ReferenceVae above; Torch
    tensor math and the adapter's methods/decorators are the actual code.
    Import/placement/real distributed gates remain in the GPU acceptance plan.
    """
    root = Path(__file__).resolve().parents[4]
    source = root / "vllm_omni/diffusion/models/minimax_h3/distributed_diffusers_vae.py"
    parsed = ast.parse(source.read_text(encoding="utf-8"))
    definitions = [item for item in parsed.body if isinstance(item, (ast.ClassDef, ast.FunctionDef))]
    tree = ast.Module(
        body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *definitions],
        type_ignores=[],
    )
    namespace = {
        "torch": torch,
        "dist": SimpleNamespace(is_initialized=lambda: True),
        "nullcontext": nullcontext,
        "AutoencoderKLMiniMaxH3": _ReferenceVae,
        "DistributedVaeMixin": _Mixin,
        "DistributedOperator": _Operator,
        "GridSpec": _GridSpec,
        "TileTask": _TileTask,
        "DiagonalGaussianDistribution": _Posterior,
        "AutoencoderKLOutput": SimpleNamespace,
        "apply_forward_hook": lambda function: function,
    }
    exec(compile(ast.fix_missing_locations(tree), str(source), "exec"), namespace)
    return namespace["DistributedAutoencoderKLMiniMaxH3"]


@pytest.fixture
def vae(adapter_type):
    value = adapter_type()
    value.distributed_executor = _Executor()
    return value


@pytest.mark.parametrize("loading_info", [False, True])
@pytest.mark.parametrize("world_initialized", [False, True])
def test_from_pretrained_preserves_strict_loading_info_and_configures_the_model(
    adapter_type, monkeypatch, loading_info, world_initialized
):
    calls = []
    configured = {}
    model = SimpleNamespace(
        enable_tiling=lambda **kwargs: configured.update(tiling=kwargs),
        set_attention_backend=lambda backend: configured.update(backend=backend),
        init_distributed=lambda: configured.update(distributed=True),
    )
    info = {"missing_keys": [], "unexpected_keys": [], "mismatched_keys": [], "error_msgs": []}
    expected = (model, info) if loading_info else model

    def load(cls, *args, **kwargs):
        calls.append((cls, args, kwargs))
        return expected

    monkeypatch.setattr(_ReferenceVae, "from_pretrained", classmethod(load), raising=False)
    distributed_api = adapter_type.from_pretrained.__func__.__globals__["dist"]
    monkeypatch.setattr(distributed_api, "is_initialized", lambda: world_initialized)
    options = {"subfolder": "vae", "local_files_only": True}
    if loading_info:
        options["output_loading_info"] = True
    result = adapter_type.from_pretrained("published-h3-bundle", **options)

    assert result is expected
    if loading_info:
        assert result[0] is model and result[1] is info
    assert calls == [(adapter_type, ("published-h3-bundle",), {**options, "torch_dtype": torch.float32})]
    assert configured["tiling"] == {
        "tile_sample_min_height": 256,
        "tile_sample_min_width": 256,
        "tile_sample_min_overlap_height": 64,
        "tile_sample_min_overlap_width": 64,
    }
    assert configured["backend"] == "native"
    assert configured.get("distributed", False) is world_initialized


def test_from_pretrained_rejects_fp16_before_the_base_loader(adapter_type, monkeypatch):
    def must_not_load(cls, *args, **kwargs):
        pytest.fail("base loader was called before the VAE precision guard")

    monkeypatch.setattr(_ReferenceVae, "from_pretrained", classmethod(must_not_load), raising=False)
    with pytest.raises(ValueError, match="torch_dtype=torch.float32"):
        adapter_type.from_pretrained("published-h3-bundle", torch_dtype=torch.float16, output_loading_info=True)


def _decode_reference(vae, latent):
    """Serial Diffusers temporal loop, retaining the original GPU-style cat."""
    token_drop = vae.config.token_drop
    count = vae.tokens_chunk_size
    period = count * vae.temporal_compression_ratio
    pad = (-(latent.shape[2] + token_drop)) % count
    before_pad = latent.shape[2]
    if pad:
        latent = torch.cat((latent, latent[:, :, -1:].repeat(1, 1, pad, 1, 1)), 2)
    chunks = []
    overlap = None
    for index in range((before_pad + token_drop + pad) // count - int(token_drop > 0)):
        clip = vae._decode_clip(latent[:, :, index * count : index * count + count + vae.token_overlap])
        for j in range(int(token_drop > 0) + 1):
            part = clip[:, :, j * period : (j + 1) * period][:, :, vae.frame_pre_padding :]
            if j:
                overlap = part
            else:
                if overlap is not None:
                    part = vae._blend(overlap, part, vae.frame_overlap, -3)
                chunks.append(part)
    if overlap is not None:
        chunks.append(overlap)
    result = torch.cat(chunks, 2)
    if pad:
        tail = vae.config.clip_length % vae.temporal_compression_ratio
        crop = sum(
            tail if tail and (before_pad + k) % count == 0 else vae.temporal_compression_ratio for k in range(pad)
        )
        result = result[:, :, :-crop]
    return result


@pytest.mark.parametrize("encode", [True, False])
def test_spatial_tiles_match_original_stitch_even_when_arrivals_are_reversed(vae, encode):
    generator = torch.Generator().manual_seed(81)
    value = torch.randn((1, 2, 5, 16, 22), generator=generator)
    if not encode:
        value = value[..., ::2, ::2]
    serial = _ReferenceVae()._serial_clip(value, encode=encode)
    actual = vae._encode_clip(value) if encode else vae._decode_clip(value)
    torch.testing.assert_close(actual, serial, rtol=0, atol=0)
    assert actual.dtype == torch.float32
    counts = vae.distributed_executor.dispatch_counts
    assert sum(counts) % len(counts) != 0
    assert min(counts) > 0


def test_one_tile_keeps_empty_rank_assignments_valid(vae):
    value = torch.arange(2 * 5 * 4 * 4, dtype=torch.float32).view(1, 2, 5, 4, 4)
    result = vae._encode_clip(value)
    torch.testing.assert_close(result, _ReferenceVae()._encode_clip(value))
    assert vae.distributed_executor.dispatch_counts == [1, 0, 0, 0, 0, 0, 0, 0]


@pytest.mark.parametrize("frames,latent_frames", [(17, 2), (124, 37), (360, 107), (362, 107)])
def test_encode_samples_full_posterior_once_and_matches_cpu_rng(vae, frames, latent_frames):
    pixels = torch.linspace(-0.3, 0.7, 2 * frames * 8 * 8).reshape(1, 2, frames, 8, 8)
    reference_posterior = _ReferenceVae().encode(pixels, return_dict=False)[0]
    seed = 106
    sample = reference_posterior.sample(generator=torch.Generator().manual_seed(seed))
    mean = torch.tensor(vae.config.latents_mean).view(1, -1, 1, 1, 1)
    std = torch.tensor(vae.config.latents_std).view(1, -1, 1, 1, 1)
    expected = ((sample - mean) / std).bfloat16()
    actual = vae.encode_reference(pixels, generator=torch.Generator().manual_seed(seed))
    assert actual.shape[2] == latent_frames
    assert _Posterior.instances[-1].sample_calls == 1
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)


def test_nonowner_does_not_advance_posterior_generator(vae):
    pixels = torch.zeros(1, 2, 17, 8, 8)
    executor = vae.distributed_executor
    executor.rank = 3
    executor.sync_value = torch.ones(1, 2, 2, 4, 4, dtype=torch.bfloat16)
    generator = torch.Generator().manual_seed(14)
    before = generator.get_state().clone()
    actual = vae.encode_reference(pixels, generator=generator)
    assert _Posterior.instances[-1].sample_calls == 0
    assert torch.equal(generator.get_state(), before)
    assert actual is executor.sync_value


@pytest.mark.parametrize("latent_frames,frames", [(3, 9), (7, 22), (37, 124), (107, 362)])
def test_decode_owner_cpu_result_matches_released_temporal_arithmetic(vae, latent_frames, frames):
    latent = torch.linspace(-1.0, 1.0, 2 * latent_frames * 4 * 4).reshape(1, 2, latent_frames, 4, 4)
    expected = _decode_reference(_ReferenceVae(), latent)
    actual = vae.decode_to_cpu(latent)
    assert actual is not None
    assert actual.device.type == "cpu"
    assert actual.dtype == torch.float32
    assert actual.shape == (1, 3, frames, 8, 8)
    assert torch.isfinite(actual).all()
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)


def test_360_frame_contract_crops_only_the_canonical_tail(vae):
    latent = torch.arange(2 * 107 * 4 * 4, dtype=torch.float32).reshape(1, 2, 107, 4, 4)
    canonical = _decode_reference(_ReferenceVae(), latent)
    actual = vae.decode_to_cpu(latent, num_frames=360)
    assert actual.shape[2] == 360
    torch.testing.assert_close(actual, canonical[:, :, :360], rtol=0, atol=0)


def test_nonowner_finishes_every_clip_without_copying_or_assembling_output(vae, monkeypatch):
    vae.distributed_executor.rank = 4
    original_to = torch.Tensor.to

    def forbid_cpu_copy(value, *args, **kwargs):
        if kwargs.get("device") == "cpu" and kwargs.get("copy") is True:
            pytest.fail("non-owner accumulated a decoded CPU chunk")
        return original_to(value, *args, **kwargs)

    monkeypatch.setattr(torch.Tensor, "to", forbid_cpu_copy)
    assert vae.decode_to_cpu(torch.zeros(1, 2, 107, 4, 4), num_frames=362) is None
    assert vae.distributed_executor.clip_calls == 21
    assert ("CPU decode assembly", "exit") in vae.distributed_executor.events


def test_owner_retains_independent_cpu_chunks_instead_of_clip_views(vae, monkeypatch):
    copies = []
    original_to = torch.Tensor.to

    def record_cpu_copy(value, *args, **kwargs):
        result = original_to(value, *args, **kwargs)
        if kwargs.get("device") == "cpu" and kwargs.get("copy") is True:
            copies.append((value.data_ptr(), result.data_ptr(), result.device.type))
        return result

    monkeypatch.setattr(torch.Tensor, "to", record_cpu_copy)
    result = vae.decode_to_cpu(torch.zeros(1, 2, 107, 4, 4))
    assert result is not None
    assert len(copies) == 22  # 21 finalized chunks plus the last overlap.
    assert all(source != destination and device == "cpu" for source, destination, device in copies)


def test_decode_reference_undoes_normalization_in_fp32(vae, monkeypatch):
    normalized = torch.full((1, 2, 37, 4, 4), 0.5, dtype=torch.bfloat16)
    received = {}

    def capture(raw, *, num_frames):
        received["raw"] = raw
        received["num_frames"] = num_frames
        return None

    monkeypatch.setattr(vae, "decode_to_cpu", capture)
    assert vae.decode_reference_to_cpu(normalized, num_frames=124) is None
    expected = normalized.float() * torch.tensor([2.0, 0.5]).view(1, 2, 1, 1, 1)
    expected += torch.tensor([0.25, -0.5]).view(1, 2, 1, 1, 1)
    assert received["raw"].dtype == torch.float32
    assert received["num_frames"] == 124
    torch.testing.assert_close(received["raw"], expected, rtol=0, atol=0)


@pytest.mark.parametrize("frames", [0, 363, -1, 1.5, True, False])
def test_invalid_frame_request_is_rejected_before_any_clip_collective(vae, frames):
    with pytest.raises(ValueError, match="num_frames"):
        vae.decode_to_cpu(torch.zeros(1, 2, 107, 4, 4), num_frames=frames)
    assert vae.distributed_executor.clip_calls == 0
    assert ("CPU decode validation", "error") in vae.distributed_executor.events


@pytest.mark.parametrize("latent_frames", [1, 2])
def test_temporal_decoder_rejects_empty_clip_plans(vae, latent_frames):
    with pytest.raises(ValueError, match="too short"):
        vae.decode_to_cpu(torch.zeros(1, 2, latent_frames, 4, 4))
    assert vae.distributed_executor.clip_calls == 0


def test_owner_cpu_allocation_failure_stays_inside_error_agreement(vae, monkeypatch):
    original_to = torch.Tensor.to

    def fail_output_copy(value, *args, **kwargs):
        if kwargs.get("device") == "cpu" and kwargs.get("copy") is True:
            raise MemoryError("injected output allocation failure")
        return original_to(value, *args, **kwargs)

    monkeypatch.setattr(torch.Tensor, "to", fail_output_copy)
    with pytest.raises(MemoryError, match="injected output"):
        vae.decode_to_cpu(torch.zeros(1, 2, 37, 4, 4))
    assert ("CPU decode temporal output", "error") in vae.distributed_executor.events
    assert vae.distributed_executor.clip_calls == 1


def test_moments_assembly_failure_is_synchronized_after_last_clip(vae, monkeypatch):
    original_cat = torch.cat

    def fail_moments_cat(tensors, dim=0, **kwargs):
        values = tuple(tensors)
        if dim == 2 and values and values[0].shape[1] == 4:
            raise MemoryError("injected moments assembly failure")
        return original_cat(values, dim=dim, **kwargs)

    monkeypatch.setattr(torch, "cat", fail_moments_cat)
    with pytest.raises(MemoryError, match="injected moments"):
        vae.encode(torch.zeros(1, 2, 34, 8, 8), return_dict=False)
    assert vae.distributed_executor.clip_calls == 2
    assert ("encode moments assembly", "error") in vae.distributed_executor.events


def test_posterior_construction_failure_is_synchronized(vae, monkeypatch):
    def fail_posterior(_moments):
        raise MemoryError("injected posterior allocation failure")

    monkeypatch.setitem(type(vae).encode.__globals__, "DiagonalGaussianDistribution", fail_posterior)
    with pytest.raises(MemoryError, match="injected posterior"):
        vae.encode(torch.zeros(1, 2, 17, 8, 8), return_dict=False)
    assert ("encode posterior construction", "error") in vae.distributed_executor.events


def test_posterior_sample_failure_is_synchronized_before_latent_broadcast(vae, monkeypatch):
    def fail_sample(self, generator):
        raise MemoryError("injected posterior sample failure")

    monkeypatch.setattr(_Posterior, "sample", fail_sample)
    with pytest.raises(MemoryError, match="injected posterior sample"):
        vae.encode_reference(torch.zeros(1, 2, 17, 8, 8), generator=torch.Generator().manual_seed(12))
    assert ("reference posterior sampling", "error") in vae.distributed_executor.events
    assert vae.distributed_executor.sync_value is None


def test_reference_rejects_fp16_latent_before_encoding(vae):
    with pytest.raises(ValueError, match="dtype"):
        vae.encode_reference(
            torch.zeros(1, 2, 17, 8, 8), generator=torch.Generator().manual_seed(12), dtype=torch.float16
        )
    assert vae.distributed_executor.clip_calls == 0


@pytest.mark.parametrize("shape", [(2, 2, 37, 4, 4), (1, 2, 0, 4, 4), (2, 37, 4, 4)])
def test_reference_rejects_batch_or_empty_inputs_before_collectives(vae, shape):
    with pytest.raises(ValueError, match="one non-empty BCTHW"):
        vae.decode_to_cpu(torch.zeros(shape))
    assert vae.distributed_executor.clip_calls == 0


@pytest.mark.parametrize("size,mode", [(4, "tile"), (8, "batch")])
def test_parallel_contract_rejects_partial_world_or_batch_mode(vae, size, mode):
    with pytest.raises(ValueError):
        vae.set_parallel_size(size, mode)


def test_configured_parallelism_rejects_a_destroyed_world_instead_of_serial_fallback(vae, monkeypatch):
    distributed_api = type(vae).is_distributed_enabled.__globals__["dist"]
    monkeypatch.setattr(distributed_api, "is_initialized", lambda: False)
    with pytest.raises(RuntimeError, match="active Omni worker WORLD"):
        vae._encode_clip(torch.zeros(1, 2, 17, 8, 8))
    assert vae.distributed_executor.clip_calls == 0


def test_configured_parallelism_rejects_disabled_tiling_instead_of_serial_fallback(vae):
    vae.use_tiling = False
    with pytest.raises(ValueError, match="refusing serial fallback"):
        vae._decode_clip(torch.zeros(1, 2, 7, 4, 4))
    assert vae.distributed_executor.clip_calls == 0


def test_explicit_serial_reference_mode_does_not_require_tiling(vae):
    vae.distributed_executor.parallel_size = 1
    vae.use_tiling = False
    assert vae.is_distributed_enabled() is False


def test_per_rank_tile_work_observation_can_reset_without_device_sampling(vae):
    assert vae.get_tile_work_counts() == {"encode": 0, "decode": 0}
    task = _TileTask(0, (0, 0), torch.zeros(1, 2, 5, 4, 4))
    vae._encode_tile(task)
    vae._decode_tile(task)
    assert vae.get_tile_work_counts() == {"encode": 1, "decode": 1}
    observed = vae.get_tile_work_counts()
    observed["decode"] = 99
    assert vae.get_tile_work_counts()["decode"] == 1
    vae.reset_tile_work_counts()
    assert vae.get_tile_work_counts() == {"encode": 0, "decode": 0}
