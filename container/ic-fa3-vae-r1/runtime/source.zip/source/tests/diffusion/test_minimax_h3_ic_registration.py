# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Lightweight release selection plus real-Omni config gates when vLLM is installed.

Pure metadata tests run without vLLM. The optional integration tests import the
real config/registry and are skipped rather than replacing an engine with stubs.
"""

from __future__ import annotations

import ast
import importlib.util
import json
import logging
import sys
from pathlib import Path
from types import ModuleType

import pytest

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]

ROOT = Path(__file__).resolve().parents[2]
PIPELINE_CLASS = "MiniMaxH3RegenerateICPipeline"
RELEASE = {
    "name": "Open-H3-Regenerate-2K-IC",
    "base_model": "MiniMaxAI/MiniMax-H3",
    "base_model_revision": "42ed227ee7df40d41602854ae760620d6eb651fe",
    "base_component": "transformer_ref",
}
TRANSFORMER = {
    "_class_name": "MiniMaxH3Transformer3DModel",
    "num_attention_heads": 56,
    "attention_head_dim": 128,
    "hidden_size": 5376,
    "num_layers": 50,
    "in_channels": 24,
    "text_dim": 5120,
}


@pytest.fixture(scope="module")
def ic_metadata():
    folder = ROOT / "vllm_omni/model_extras"
    package = ModuleType("_test_ic_metadata_package")
    package.__path__ = [str(folder)]
    sys.modules[package.__name__] = package
    name = package.__name__ + ".minimax_h3_ic"
    spec = importlib.util.spec_from_file_location(name, folder / "minimax_h3_ic.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
        yield module
    finally:
        for key in list(sys.modules):
            if key == package.__name__ or key.startswith(package.__name__ + "."):
                sys.modules.pop(key, None)


def test_published_root_identity_without_hf_architecture_fields(ic_metadata):
    assert not set(RELEASE).intersection({"architectures", "model_type", "_class_name"})
    assert ic_metadata.is_minimax_h3_ic_config(RELEASE)
    assert ic_metadata.resolve_minimax_h3_ic_model_class(RELEASE) == PIPELINE_CLASS
    assert ic_metadata.resolve_minimax_h3_ic_model_class(RELEASE, model_class_name=PIPELINE_CLASS) == PIPELINE_CLASS


@pytest.mark.parametrize("field", list(RELEASE))
def test_every_release_identity_field_is_required(ic_metadata, field):
    config = {key: value for key, value in RELEASE.items() if key != field}
    assert not ic_metadata.is_minimax_h3_ic_config(config)
    with pytest.raises(ValueError, match="published root config identity"):
        ic_metadata.resolve_minimax_h3_ic_model_class(config, model_class_name=PIPELINE_CLASS)


@pytest.mark.parametrize(
    "config",
    [
        None,
        {},
        {"name": "Open-H3-Regenerate-2K"},
        {"_class_name": "MiniMaxH3ModularPipeline"},
        {"model_type": "ref2va"},
        {"model_type": "unknown"},
    ],
)
def test_ordinary_h3_standard_regenerate_and_unknown_are_not_ic(ic_metadata, config):
    assert not ic_metadata.is_minimax_h3_ic_config(config)
    assert ic_metadata.resolve_minimax_h3_ic_model_class(config) is None


def test_conflicting_explicit_pipeline_is_rejected(ic_metadata):
    with pytest.raises(ValueError, match="requires MiniMaxH3RegenerateICPipeline"):
        ic_metadata.resolve_minimax_h3_ic_model_class(RELEASE, model_class_name="MiniMaxH3Pipeline")
    with pytest.raises(ValueError, match="pinned Ref2VA base revision"):
        ic_metadata.resolve_minimax_h3_ic_model_class({**RELEASE, "base_model_revision": "different"})


def test_component_and_shared_defaults_are_lightweight(ic_metadata):
    assert ic_metadata.minimax_h3_ic_transformer_subfolder(model="any/local/path") == "base_model/transformer_ref"
    defaults = ic_metadata.get_minimax_h3_ic_video_generation_defaults({"source_video": "/draft.mp4"})
    assert defaults.cli_defaults() == {
        "height": 1440,
        "width": 2560,
        "num_frames": 1,
        "num_inference_steps": 3,
        "fps": 24.0,
        "guidance_scale": 1.0,
        "output": "minimax_h3_ic_output.mp4",
    }
    assert defaults.duration_seconds is None
    assert ic_metadata.MINIMAX_H3_IC_EXTRA_BODY_PARAMS == frozenset({"source_video", "regenerate_sampler", "sharp"})
    # This checks the actual lightweight module's import boundary. It does
    # not stand in for real registry/config initialization on the target stack.
    tree = ast.parse((ROOT / "vllm_omni/model_extras/minimax_h3_ic.py").read_text(encoding="utf-8"))
    imports = [node for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))]
    assert all(not (getattr(node, "module", "") or "").startswith(("torch", "diffusers", "vllm")) for node in imports)


def _literal_registry(name: str) -> dict:
    tree = ast.parse((ROOT / "vllm_omni/diffusion/registry.py").read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            return ast.literal_eval(node.value)
    raise AssertionError(f"missing registry {name}")


def test_static_lazy_registration_uses_actual_new_module():
    registry = _literal_registry("_DIFFUSION_MODELS")
    assert registry[PIPELINE_CLASS] == ("minimax_h3", "pipeline_minimax_h3_regenerate_ic", PIPELINE_CLASS)
    assert registry["MiniMaxH3Pipeline"] == ("minimax_h3", "pipeline_minimax_h3", "MiniMaxH3Pipeline")
    assert registry["MiniMaxH3ModularPipeline"] == ("minimax_h3", "pipeline_minimax_h3", "MiniMaxH3Pipeline")
    assert PIPELINE_CLASS not in _literal_registry("_DIFFUSION_POST_PROCESS_FUNCS")
    source = ROOT / "vllm_omni/diffusion/models/minimax_h3/pipeline_minimax_h3_regenerate_ic.py"
    assert any(
        isinstance(node, ast.ClassDef) and node.name == PIPELINE_CLASS for node in ast.parse(source.read_text()).body
    )


@pytest.fixture
def real_hf_classifier(ic_metadata, monkeypatch):
    """Import the real discovery module with metadata-I/O seams, not a fake engine."""
    logger = ModuleType("vllm.logger")
    logger.init_logger = logging.getLogger
    config_reader = ModuleType("vllm.transformers_utils.config")

    def read_local_json(filename, model, **kwargs):
        path = Path(model) / filename
        return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None

    config_reader.get_hf_file_to_dict = read_local_json
    monkeypatch.setitem(sys.modules, "vllm.logger", logger)
    monkeypatch.setitem(sys.modules, "vllm.transformers_utils.config", config_reader)
    monkeypatch.setitem(sys.modules, "vllm_omni.model_extras.minimax_h3_ic", ic_metadata)
    depth_name = "vllm_omni.diffusion.models.video_depth_anything.checkpoints"
    depth_spec = importlib.util.spec_from_file_location(
        depth_name, ROOT / "vllm_omni/diffusion/models/video_depth_anything/checkpoints.py"
    )
    assert depth_spec is not None and depth_spec.loader is not None
    depth_module = importlib.util.module_from_spec(depth_spec)
    monkeypatch.setitem(sys.modules, depth_name, depth_module)
    depth_spec.loader.exec_module(depth_module)
    name = "_test_real_hf_ic_classifier"
    spec = importlib.util.spec_from_file_location(name, ROOT / "vllm_omni/diffusion/utils/hf_utils.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, name, module)
    spec.loader.exec_module(module)

    def no_diffusers_index(model):
        raise OSError("local test fixture has no Diffusers index")

    monkeypatch.setattr(module, "load_diffusers_config", no_diffusers_index)
    return module


def test_actual_discovery_function_accepts_ic_root(real_hf_classifier, local_ic_config):
    assert real_hf_classifier._looks_like_minimax_h3_ic(str(local_ic_config))
    assert real_hf_classifier.is_diffusion_model(str(local_ic_config))


@pytest.mark.parametrize("signature", ["existing_diffusers_index", "ic_root"])
def test_existing_public_cache_clear_consumer_refreshes_discovery(real_hf_classifier, tmp_path, signature):
    # Existing callers clear this public cache before changing local metadata.
    # A separate helper cache must not keep an old negative IC result alive.
    discover = real_hf_classifier.is_diffusion_model
    discover.cache_clear()
    assert discover.cache_info().currsize == 0
    assert not discover(str(tmp_path))
    if signature == "ic_root":
        (tmp_path / "config.json").write_text(json.dumps(RELEASE), encoding="utf-8")
    else:
        (tmp_path / "model_index.json").write_text(
            json.dumps({"_class_name": "MiniMaxH3ModularPipeline", "_diffusers_version": "0.40.0"}), encoding="utf-8"
        )
    assert not discover(str(tmp_path))  # The existing top-level cache remains effective.
    discover.cache_clear()
    assert discover.cache_info().currsize == 0
    assert discover(str(tmp_path))


@pytest.mark.parametrize("name", ["model_index.json", "modular_model_index.json"])
def test_existing_diffusers_index_discovery_unchanged(real_hf_classifier, tmp_path, name):
    (tmp_path / name).write_text(
        json.dumps({"_class_name": "MiniMaxH3ModularPipeline", "_diffusers_version": "0.40.0"}), encoding="utf-8"
    )
    assert not real_hf_classifier._looks_like_minimax_h3_ic(str(tmp_path))
    assert real_hf_classifier.is_diffusion_model(str(tmp_path))


@pytest.mark.parametrize("config", [{"name": "Open-H3-Regenerate-2K"}, {"model_type": "unknown"}, {}])
def test_non_ic_unknown_root_not_classified_as_diffusion(real_hf_classifier, tmp_path, config):
    (tmp_path / "config.json").write_text(json.dumps(config), encoding="utf-8")
    assert not real_hf_classifier._looks_like_minimax_h3_ic(str(tmp_path))
    assert not real_hf_classifier.is_diffusion_model(str(tmp_path))


@pytest.fixture
def actual_diffusion_data():
    pytest.importorskip("vllm", reason="real Omni config/registry integration requires the actual vLLM runtime")
    from vllm_omni.diffusion import data

    return data


@pytest.fixture
def local_ic_config(tmp_path):
    (tmp_path / "config.json").write_text(json.dumps(RELEASE), encoding="utf-8")
    component = tmp_path / "base_model/transformer_ref"
    component.mkdir(parents=True)
    (component / "config.json").write_text(json.dumps(TRANSFORMER), encoding="utf-8")
    return tmp_path


@pytest.mark.parametrize("explicit", [False, True])
def test_actual_config_auto_and_explicit_ic(actual_diffusion_data, local_ic_config, explicit):
    config = actual_diffusion_data.OmniDiffusionConfig(
        model=str(local_ic_config), model_class_name=PIPELINE_CLASS if explicit else None
    )
    config.enrich_config()
    assert config.model_class_name == PIPELINE_CLASS
    assert config.tf_model_config.to_dict() == TRANSFORMER
    assert actual_diffusion_data.resolve_model_class_name(str(local_ic_config)) == PIPELINE_CLASS
    from vllm_omni.diffusion.io_support import get_dummy_run_num_frames
    from vllm_omni.diffusion.registry import DiffusionModelRegistry, get_diffusion_post_process_func
    from vllm_omni.model_extras import get_transformer_config_subfolder, get_video_generation_defaults

    assert PIPELINE_CLASS in DiffusionModelRegistry.get_supported_archs()
    pipeline_class = DiffusionModelRegistry._try_load_model_cls(PIPELINE_CLASS)
    assert pipeline_class is not None and pipeline_class.__name__ == PIPELINE_CLASS
    assert pipeline_class.__module__ == "vllm_omni.diffusion.models.minimax_h3.pipeline_minimax_h3_regenerate_ic"
    assert get_dummy_run_num_frames(PIPELINE_CLASS, False) == 0
    assert get_transformer_config_subfolder(PIPELINE_CLASS, model=str(local_ic_config)) == "base_model/transformer_ref"
    assert get_video_generation_defaults(PIPELINE_CLASS).num_inference_steps == 3
    assert get_diffusion_post_process_func(config) is None


def test_actual_ic_missing_nested_component_cannot_fallback_to_unet(actual_diffusion_data, tmp_path):
    (tmp_path / "config.json").write_text(json.dumps(RELEASE), encoding="utf-8")
    unet = tmp_path / "unet"
    unet.mkdir()
    (unet / "config.json").write_text(json.dumps(TRANSFORMER), encoding="utf-8")
    config = actual_diffusion_data.OmniDiffusionConfig(model=str(tmp_path), model_class_name=PIPELINE_CLASS)
    with pytest.raises(ValueError, match="missing base_model/transformer_ref"):
        config.enrich_config()


def test_actual_explicit_ic_requires_root_identity(actual_diffusion_data, local_ic_config):
    (local_ic_config / "config.json").write_text(json.dumps({"name": "unknown"}), encoding="utf-8")
    config = actual_diffusion_data.OmniDiffusionConfig(model=str(local_ic_config), model_class_name=PIPELINE_CLASS)
    with pytest.raises(ValueError, match="published root config identity"):
        config.enrich_config()


def test_actual_explicit_ic_rejects_generic_diffusers_loader(actual_diffusion_data, local_ic_config):
    config = actual_diffusion_data.OmniDiffusionConfig(
        model=str(local_ic_config), model_class_name=PIPELINE_CLASS, diffusion_load_format="diffusers"
    )
    with pytest.raises(ValueError, match="requires the native Omni default loader"):
        config.enrich_config()


def test_actual_unknown_root_keeps_previous_failure(actual_diffusion_data, tmp_path):
    (tmp_path / "config.json").write_text(json.dumps({"name": "unknown"}), encoding="utf-8")
    config = actual_diffusion_data.OmniDiffusionConfig(model=str(tmp_path))
    with pytest.raises((OSError, ValueError)):
        config.enrich_config()


@pytest.mark.parametrize("class_name", ["MiniMaxH3Pipeline", "MiniMaxH3ModularPipeline"])
def test_actual_existing_h3_index_still_resolves(actual_diffusion_data, tmp_path, class_name):
    (tmp_path / "model_index.json").write_text(json.dumps({"_class_name": class_name}), encoding="utf-8")
    component = tmp_path / "transformer"
    component.mkdir()
    (component / "config.json").write_text(json.dumps(TRANSFORMER), encoding="utf-8")
    config = actual_diffusion_data.OmniDiffusionConfig(model=str(tmp_path))
    config.enrich_config()
    assert config.model_class_name == class_name
    assert config.tf_model_config.to_dict() == TRANSFORMER
