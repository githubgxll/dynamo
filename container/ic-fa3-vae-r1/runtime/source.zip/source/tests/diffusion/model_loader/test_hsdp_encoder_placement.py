# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""CPU-only placement contracts shared by full and pre-sharded HSDP loads."""

from types import SimpleNamespace
from typing import ClassVar

import pytest
import torch
from torch import nn

from vllm_omni.diffusion.model_loader.diffusers_loader import DiffusersPipelineLoader
from vllm_omni.diffusion.offloader.module_collector import ModuleDiscovery
from vllm_omni.diffusion.offloader.offload_plan import OffloadPlan

pytestmark = [pytest.mark.core_model, pytest.mark.diffusion, pytest.mark.cpu]


class _Encoder(nn.Module):
    def __init__(self, *, loaded: bool = True) -> None:
        super().__init__()
        self.is_loaded = loaded
        if loaded:
            self.blocks = nn.ModuleList([nn.Linear(2, 2), nn.Linear(2, 2)])


class _StagedEncoder(_Encoder):
    def load_to_device(self) -> None:
        raise AssertionError("Loading weights must not activate the encoder stage")

    def offload_to_cpu(self) -> None:
        raise AssertionError("Loading weights must not install the offload lifecycle")


class _Pipeline(nn.Module):
    _dit_modules: ClassVar[list[str]] = ["transformer"]
    _encoder_modules: ClassVar[list[str]] = ["text_encoder", "image_encoder"]
    _vae_modules: ClassVar[list[str]] = ["vae"]
    _resident_modules: ClassVar[list[str]] = ["auxiliary"]

    def __init__(self, encoder: nn.Module, *, staged: bool = True) -> None:
        super().__init__()
        self.transformer = nn.Module()
        self.transformer.blocks = nn.ModuleList([nn.Linear(2, 2), nn.Linear(2, 2)])
        self.text_encoder = encoder
        self.image_encoder = nn.Linear(2, 2)
        self.vae = nn.Linear(2, 2)
        self.auxiliary = nn.Linear(2, 2)
        self._offload_plan = OffloadPlan(
            block_attrs={"transformer": ("blocks",)},
            encoder_component_types={"text_encoder": "text_encoder"},
            encoder_block_attrs={"text_encoder": ("blocks",)},
            on_demand_component_paths=frozenset({"text_encoder"}) if staged else frozenset(),
        )


def _loader(offload_config: dict[str, object] | None) -> DiffusersPipelineLoader:
    loader = object.__new__(DiffusersPipelineLoader)
    loader.od_config = SimpleNamespace(
        diffusion_offload_config=offload_config,
        parallel_config=SimpleNamespace(
            use_hsdp=True,
            hsdp_shard_size=8,
            hsdp_replicate_size=1,
            data_parallel_size=1,
            sequence_parallel_size=8,
        ),
        dlo_chunk_size_mb=64,
        pin_cpu_memory=False,
    )
    return loader


def _place_runtime_modules(loader: DiffusersPipelineLoader, pipeline: _Pipeline) -> None:
    # Meta is a CPU-available destination that lets the test observe an actual
    # tensor-device change without allocating accelerator memory or mocking .to.
    loader._move_non_hsdp_modules(pipeline, ModuleDiscovery.discover(pipeline), torch.device("meta"))


def test_selected_staged_encoder_stays_on_cpu_until_its_execution_stage() -> None:
    pipeline = _Pipeline(_StagedEncoder())
    loader = _loader({"mode": "layer", "components": ["text_encoder"]})

    _place_runtime_modules(loader, pipeline)

    assert all(parameter.device.type == "cpu" for parameter in pipeline.text_encoder.parameters())
    assert pipeline.image_encoder.weight.device.type == "meta"
    assert pipeline.vae.weight.device.type == "meta"
    assert pipeline.auxiliary.weight.device.type == "meta"


def test_selected_streamable_encoder_does_not_visit_the_device_in_full() -> None:
    pipeline = _Pipeline(_Encoder(), staged=False)

    _place_runtime_modules(_loader({"mode": "layer", "components": ["text_encoder"]}), pipeline)

    assert all(parameter.device.type == "cpu" for parameter in pipeline.text_encoder.parameters())
    assert pipeline.vae.weight.device.type == "meta"


@pytest.mark.parametrize(
    "offload_config",
    [None, {"mode": "module", "components": ["text_encoder"]}, {"mode": "layer", "components": ["dit"]}],
)
def test_unselected_and_non_layerwise_encoders_keep_the_existing_placement(
    offload_config: dict[str, object] | None,
) -> None:
    pipeline = _Pipeline(_StagedEncoder())

    _place_runtime_modules(_loader(offload_config), pipeline)

    assert all(parameter.device.type == "meta" for parameter in pipeline.text_encoder.parameters())
    assert pipeline.image_encoder.weight.device.type == "meta"
    assert pipeline.vae.weight.device.type == "meta"
    assert pipeline.auxiliary.weight.device.type == "meta"


def test_legacy_layerwise_selection_keeps_the_existing_placement() -> None:
    pipeline = _Pipeline(_StagedEncoder())
    loader = _loader(None)
    loader.od_config.enable_layerwise_offload = True

    _place_runtime_modules(loader, pipeline)

    assert all(parameter.device.type == "meta" for parameter in pipeline.text_encoder.parameters())


def test_unloaded_owner_stub_is_valid_without_local_block_attributes() -> None:
    pipeline = _Pipeline(_StagedEncoder(loaded=False))

    _place_runtime_modules(_loader({"mode": "layer", "components": ["text_encoder"]}), pipeline)

    assert list(pipeline.text_encoder.parameters()) == []
    assert pipeline.vae.weight.device.type == "meta"


def test_invalid_on_demand_lifecycle_fails_before_any_auxiliary_placement() -> None:
    pipeline = _Pipeline(_Encoder())

    with pytest.raises(ValueError, match="must implement load_to_device"):
        _place_runtime_modules(_loader({"mode": "layer", "components": ["text_encoder"]}), pipeline)

    assert pipeline.vae.weight.device.type == "cpu"
    assert pipeline.image_encoder.weight.device.type == "cpu"
    assert pipeline.auxiliary.weight.device.type == "cpu"
