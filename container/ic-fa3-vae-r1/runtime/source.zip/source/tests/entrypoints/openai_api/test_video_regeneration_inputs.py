# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Capability and input boundaries for maskless source-video regeneration."""

import asyncio
import io
from dataclasses import fields
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException, UploadFile

from vllm_omni.diffusion.model_metadata import DiffusionModelMetadata, get_diffusion_model_metadata
from vllm_omni.entrypoints.openai.serving_video import LatentEditInput, OmniOpenAIServingVideo
from vllm_omni.entrypoints.openai.video.generation import helpers

pytestmark = [pytest.mark.core_model, pytest.mark.cpu]


def _validate(handler, **inputs):
    values = {"source_video": None, "source_audio": None, "video_noise_mask": None, "audio_noise_mask": None}
    values.update(inputs)
    return helpers._validate_latent_edit_inputs(handler, **values)


def test_regeneration_metadata_does_not_advertise_unimplemented_h3_features():
    metadata = get_diffusion_model_metadata("MiniMaxH3RegenerateICPipeline")
    assert metadata.supports_video_regeneration
    assert metadata.final_output_type == "video"
    assert metadata.attention_mask_free
    assert not metadata.supports_latent_mask_editing
    assert not metadata.supports_latent_continuation
    assert not metadata.supports_timeline_guides
    assert not metadata.supports_multimodal_inputs
    assert not metadata.supports_mixed_reference_inputs
    assert metadata.supported_control_upload_types == ()
    assert not get_diffusion_model_metadata(None).supports_video_regeneration
    assert fields(DiffusionModelMetadata)[-1].name == "supports_video_regeneration"


@pytest.mark.parametrize("metadata", [(), (SimpleNamespace(),), (DiffusionModelMetadata(),)])
def test_regeneration_property_defaults_false_for_old_metadata_views(metadata):
    handler = object.__new__(OmniOpenAIServingVideo)
    handler._resolve_diffusion_metadata = lambda: (None, metadata)
    assert not handler.supports_video_regeneration


def test_ic_handler_does_not_enter_the_base_h3_control_branch():
    handler = object.__new__(OmniOpenAIServingVideo)
    handler._engine_client = SimpleNamespace(
        od_config=SimpleNamespace(model_class_name="MiniMaxH3RegenerateICPipeline")
    )
    handler._stage_configs = None
    assert handler.supports_video_regeneration
    assert not handler.supports_latent_mask_editing
    assert not handler.is_minimax_h3


@pytest.mark.parametrize("regenerate", [False, True])
def test_explicit_regeneration_capability_accepts_a_maskless_draft(regenerate):
    handler = SimpleNamespace(supports_video_regeneration=True, supports_latent_mask_editing=False)
    assert _validate(handler, source_video=object(), regenerate=regenerate)


def test_regeneration_capability_does_not_require_a_draft_at_this_boundary():
    assert not _validate(SimpleNamespace(supports_video_regeneration=True))


@pytest.mark.parametrize("source_video", [None, object()])
def test_regeneration_rejects_latent_audio_sources(source_video):
    handler = SimpleNamespace(supports_video_regeneration=True, supports_latent_mask_editing=False)
    with pytest.raises(HTTPException, match="source_audio is not supported") as error:
        _validate(handler, source_video=source_video, source_audio=object())
    assert error.value.status_code == 400


@pytest.mark.parametrize("mask_name", ["video_noise_mask", "audio_noise_mask"])
@pytest.mark.parametrize("mask", [0, []])
def test_regeneration_capability_does_not_enable_any_noise_mask(mask_name, mask):
    handler = SimpleNamespace(supports_video_regeneration=True, supports_latent_mask_editing=False)
    with pytest.raises(HTTPException, match="Latent-mask editing is not supported"):
        _validate(handler, source_video=object(), **{mask_name: mask})


def test_unknown_handler_does_not_accept_source_media():
    with pytest.raises(HTTPException, match="not supported"):
        _validate(SimpleNamespace(), source_video=object())


def test_legacy_h3_maskless_regenerate_still_requires_the_regenerate_flag():
    handler = SimpleNamespace(supports_latent_mask_editing=True)
    with pytest.raises(HTTPException, match="at least one"):
        _validate(handler, source_video=object())
    assert _validate(handler, source_video=object(), regenerate=True)


def test_legacy_h3_latent_audio_mask_contract_is_preserved():
    handler = SimpleNamespace(supports_latent_mask_editing=True)
    with pytest.raises(HTTPException, match="source_audio requires an audio_noise_mask"):
        _validate(handler, source_audio=object(), video_noise_mask=0)
    assert _validate(handler, source_audio=object(), audio_noise_mask=0)
    assert _validate(handler, source_video=object(), video_noise_mask=0)


def test_regeneration_source_uses_bounded_request_storage_and_cleanup(tmp_path, monkeypatch):
    monkeypatch.setattr(helpers.tempfile, "tempdir", str(tmp_path))
    upload = UploadFile(filename="draft.mp4", file=io.BytesIO(b"draft-video"))
    handler = SimpleNamespace(supports_video_regeneration=True)
    assert _validate(handler, source_video=upload)
    path = asyncio.run(helpers._persist_latent_edit_source(upload, field_name="source_video"))
    assert Path(path).read_bytes() == b"draft-video"
    try:
        helpers._cleanup_video_references(
            None,
            None,
            SimpleNamespace(_control_reference_paths=[]),
            LatentEditInput(source_video=path, cleanup_paths=(path,)),
        )
        assert not Path(path).exists()
    finally:
        Path(path).unlink(missing_ok=True)
        asyncio.run(upload.close())


def test_regeneration_source_keeps_existing_upload_format_validation():
    upload = UploadFile(filename="draft.webm", file=io.BytesIO(b"video"))
    try:
        with pytest.raises(HTTPException, match="MP4 or MOV"):
            asyncio.run(helpers._persist_latent_edit_source(upload, field_name="source_video"))
    finally:
        asyncio.run(upload.close())
