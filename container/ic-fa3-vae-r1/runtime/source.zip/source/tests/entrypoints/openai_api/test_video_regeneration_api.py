# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Real video routes with the existing fake engine, without model inference."""

from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from tests.entrypoints.openai_api.test_video_server import FakeAsyncOmni
from vllm_omni.entrypoints.openai.api_server import router
from vllm_omni.entrypoints.openai.serving_video import OmniOpenAIServingVideo
from vllm_omni.entrypoints.openai.storage import LocalStorageManager
from vllm_omni.entrypoints.openai.stores import AsyncDictStore
from vllm_omni.entrypoints.openai.video.generation import helpers

pytestmark = [pytest.mark.core_model, pytest.mark.cpu]


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "vllm_omni.entrypoints.openai.serving_video._encode_video_bytes", lambda *args, **kwargs: b"video"
    )
    monkeypatch.setattr(helpers, "VIDEO_STORE", AsyncDictStore())
    monkeypatch.setattr(helpers, "STORAGE_MANAGER", LocalStorageManager(storage_path=str(tmp_path / "storage")))
    engine = FakeAsyncOmni()
    engine.model_class_name = "MiniMaxH3RegenerateICPipeline"
    handler = OmniOpenAIServingVideo.for_diffusion(engine, model_name="ic-test")
    app = FastAPI()
    app.state.api_server_count = 1
    app.include_router(router)
    app.state.openai_serving_video = handler
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        handler.shutdown()


def test_maskless_ic_draft_reaches_the_engine_as_request_owned_media(client):
    response = client.post(
        "/v1/videos/sync",
        data={"prompt": "Preserve this shot.", "extra_params": '{"sharp": 1}'},
        files=[("source_video", ("draft.mp4", b"draft-video", "video/mp4"))],
    )
    assert response.status_code == 200
    engine = client.app.state.openai_serving_video._engine_client
    assert engine.captured_latent_edit_source_bytes == {"source_video": b"draft-video"}
    media = engine.captured_prompt["multi_modal_data"]
    assert set(media) == {"source_video"}
    assert not Path(media["source_video"]).exists()
    extra = engine.captured_sampling_params_list[0].extra_args
    assert extra["sharp"] == 1
    assert "source_video" not in extra
    assert "latent_cache_key" not in extra


@pytest.mark.parametrize("field", ["source_audio", "video_noise_mask", "audio_noise_mask"])
def test_ic_rejects_latent_edit_fields_before_engine_submission(client, field):
    upload = (
        ("source.wav", b"audio", "audio/wav") if field == "source_audio" else ("mask.json", b"0", "application/json")
    )
    response = client.post(
        "/v1/videos/sync",
        data={"prompt": "Preserve this shot."},
        files=[("source_video", ("draft.mp4", b"draft-video", "video/mp4")), (field, upload)],
    )
    assert response.status_code == 400
    engine = client.app.state.openai_serving_video._engine_client
    assert engine.captured_prompt is None
