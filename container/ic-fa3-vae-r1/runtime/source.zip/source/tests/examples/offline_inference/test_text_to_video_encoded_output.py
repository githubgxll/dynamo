# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

"""Exercise the shared runner's actual output path without loading an engine."""

from __future__ import annotations

import ast
import sys
from argparse import Namespace
from pathlib import Path
from types import ModuleType

import numpy as np
import pytest
import torch

pytestmark = [pytest.mark.core_model, pytest.mark.cpu]

RUNNER = Path(__file__).resolve().parents[3] / "examples/offline_inference/text_to_video/text_to_video.py"


@pytest.fixture
def output_boundary(monkeypatch):
    """Compile the real main() output block; only engine setup is excluded."""
    tree = ast.parse(RUNNER.read_text(encoding="utf-8"))
    main = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "main")
    start = next(
        index
        for index, item in enumerate(main.body)
        if isinstance(item, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "audio" for target in item.targets)
    )
    nodes = main.body[start:]
    end = next(
        index
        for index, item in enumerate(nodes)
        if isinstance(item, ast.If) and isinstance(item.test, ast.Name) and item.test.id == "profiler_enabled"
    )
    code = compile(ast.Module(body=nodes[:end], type_ignores=[]), str(RUNNER), "exec")
    normalized = next(
        item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "_normalize_float_tensor"
    )
    helper = compile(ast.Module(body=[normalized], type_ignores=[]), str(RUNNER), "exec")
    exported = []

    def export(frames, output, *, fps):
        exported.append((frames, fps))
        Path(output).write_bytes(b"exported-raw-frames")

    utilities = ModuleType("diffusers.utils")
    utilities.export_to_video = export
    diffusers = ModuleType("diffusers")
    diffusers.utils = utilities
    monkeypatch.setitem(sys.modules, "diffusers", diffusers)
    monkeypatch.setitem(sys.modules, "diffusers.utils", utilities)

    class RequestOutput:
        pass

    def execute(value, output):
        context = {
            "frames": value,
            "args": Namespace(output=str(output), fps=24, audio_sample_rate=32000),
            "Path": Path,
            "np": np,
            "torch": torch,
            "OmniRequestOutput": RequestOutput,
            "output_tensor_range": "zero_to_one",
        }
        exec(helper, context)
        exec(code, context)
        return exported

    return execute


@pytest.mark.parametrize("container_type", [bytes, bytearray, memoryview])
@pytest.mark.parametrize("wrapped", [False, True])
def test_encoded_video_is_saved_without_rgb_conversion(output_boundary, tmp_path, container_type, wrapped):
    # Byte identity also preserves the soundtrack already muxed by a pipeline.
    original = b"\x00\x00\x00\x18ftypmp42\x00complete-video-and-audio-container"
    payload = container_type(original)
    value = [{"video": [payload], "audio": [None]}] if wrapped else payload
    output = tmp_path / "nested/output.mp4"
    exported = output_boundary(value, output)
    assert output.read_bytes() == original
    assert exported == []


def test_raw_video_still_uses_frame_export(output_boundary, tmp_path):
    frames = np.full((2, 16, 16, 3), 128, dtype=np.uint8)
    output = tmp_path / "raw.mp4"
    exported = output_boundary(frames, output)
    assert output.read_bytes() == b"exported-raw-frames"
    assert len(exported) == 1
    actual, fps = exported[0]
    assert fps == 24
    np.testing.assert_allclose(np.stack(actual), frames.astype(np.float32) / 255)


def test_missing_video_still_fails(output_boundary, tmp_path):
    with pytest.raises(ValueError, match="No video frames"):
        output_boundary(None, tmp_path / "missing.mp4")
